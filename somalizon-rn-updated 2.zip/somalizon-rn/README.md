# 🛍️ Somalizon — React Native (Expo)

## Qaabka Mashruuca
```
somalizon-rn/
├── App.js
├── app.json
├── package.json
├── src/
│   ├── constants/
│   │   └── Design.js          ← Colors, Shadows, Border Radius
│   ├── contexts/
│   │   ├── AuthContext.js     ← Login/session
│   │   ├── CartContext.js     ← Global cart state
│   │   ├── NotifContext.js    ← Notifications
│   │   ├── RealtimeContext.js ← Real-time sync (products/stores/chat/orders)
│   │   └── ThemeContext.js    ← Orange+White theme
│   ├── components/
│   │   ├── AppHeader.js       ← Shared header
│   │   ├── Buttons.js         ← PrimaryBtn, SecondaryBtn, GhostBtn
│   │   ├── ImageViewer.js     ← Full-screen image
│   │   ├── LocationModal.js   ← Address picker modal
│   │   └── Toast.js           ← Global toast
│   ├── navigation/
│   │   ├── RootNavigator.js   ← All 30 screens registered
│   │   └── MainTabs.js        ← Custom orange tab bar
│   └── screens/ (30 screens)
│       ├── SplashScreen.js
│       ├── OnboardingScreen.js
│       ├── LoginScreen.js
│       ├── SignupScreen.js
│       ├── HomeScreen.js
│       ├── ShopsScreen.js
│       ├── WatchScreen.js
│       ├── XariirScreen.js
│       ├── ProfileScreen.js
│       ├── DashboardScreen.js
│       ├── ProductDetailScreen.js
│       ├── StoreDetailScreen.js
│       ├── ChatRoomScreen.js
│       ├── CallScreen.js
│       ├── UserProfileScreen.js
│       ├── AsxaabtaScreen.js
│       ├── ReviewsPageScreen.js
│       ├── WishlistScreen.js
│       ├── AddProductScreen.js
│       ├── EditProductScreen.js
│       ├── VideoManagerScreen.js
│       ├── UploadVideoScreen.js
│       ├── CommentsScreen.js
│       ├── WatchSearchScreen.js
│       ├── ProfileVideoViewerScreen.js
│       ├── CartScreen.js
│       ├── OrdersHistoryScreen.js
│       ├── NotificationsScreen.js
│       ├── SettingsScreen.js
│       └── SearchScreen.js
```

## Bilowga

### 1. Geli Supabase Credentials
Fur `src/lib/supabase.js`:
```js
const SUPABASE_URL = 'https://YOUR-PROJECT.supabase.co';
const SUPABASE_ANON_KEY = 'YOUR-ANON-KEY';
```

### 2. Install
```bash
npm install
```

### 3. Bilow
```bash
npx expo start
```

## Design System
- **Primary:** `#FF6B00` (Orange)
- **Background:** `#F5F5F5` (Gray-cad)
- **Cards:** `#FFFFFF` (Pure White)
- **Text:** `#111111`
- **Theme:** Orange + White (always light)

## Supabase Tables
profiles, products, stores, orders, reviews, chats, messages,
follows, videos, video_interactions, comments, notifications, calls, call_candidates

## Wixii Cusub (Fixes)

### 1. Toast/Alert feedback (la hagaajiyay)
Isticmaal `useToast()` (`src/components/Toast.js`) ayaa hadda si dhab ah loogu isticmaalayaa 15+ screen — login, signup, checkout, add/edit product, chat, video upload, iyo kuwo kale. Hore ayay ahayd `console.log(...)` oo user-ku uusan wax arki jirin.

### 2. Push Notifications (qayb cusub)
- `src/contexts/NotifContext.js` hadda wuxuu leeyahay `registerForPush(uid)` — wuxuu codsan doonaa fasax, soo qaadan doonaa Expo push token, kaydin doonaana `profiles.push_token`.
- Waxaad u baahan tahay:
  1. **Add column**: `alter table profiles add column push_token text;` (Supabase SQL editor)
  2. **EAS project id**: ku beddel `app.json` → `extra.eas.projectId` ee kaaga ah (`eas init` haddii aanad lahayn)
  3. **Development build**: push tokens dhab ah kama shaqeeyaan Expo Go — u baahan tahay `eas build --profile development`
  4. **Dirista dhabta ah**: waxaan ku daray `supabase/functions/send-push/index.ts` — Edge Function u dirta push user kale. Deploy: `supabase functions deploy send-push`, kadibna ku xidh Database Webhook (Supabase Dashboard → Database → Webhooks) oo INSERT ah `orders`/`messages` si loo wado marka dalab ama fariin cusub timaado.
