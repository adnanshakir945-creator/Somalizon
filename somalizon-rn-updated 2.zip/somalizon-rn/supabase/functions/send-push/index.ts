// supabase/functions/send-push/index.ts
//
// This is the missing "other half" of push notifications: the app now saves
// each user's Expo push token to profiles.push_token (see NotifContext.js),
// but only a server can actually push a notification to someone else's phone.
//
// Deploy with:
//   supabase functions deploy send-push
//
// Then call it (e.g. from a Database Webhook on INSERT into `orders` or
// `messages`) with a JSON body like:
//   { "toUid": "the-recipient-profile-id", "title": "Dalab Cusub!", "body": "...", "data": {} }
//
// Docs: https://supabase.com/docs/guides/functions
//       https://docs.expo.dev/push-notifications/sending-notifications/

import { createClient } from 'jsr:@supabase/supabase-js@2';

const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

Deno.serve(async (req) => {
  try {
    const { toUid, title, body, data } = await req.json();
    if (!toUid || !title) {
      return new Response(JSON.stringify({ error: 'toUid and title are required' }), { status: 400 });
    }

    const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
    const { data: profile, error } = await supabase
      .from('profiles')
      .select('push_token')
      .eq('id', toUid)
      .maybeSingle();

    if (error || !profile?.push_token) {
      return new Response(JSON.stringify({ skipped: true, reason: 'no push_token for this user' }), { status: 200 });
    }

    const resp = await fetch('https://exp.host/--/api/v2/push/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({
        to: profile.push_token,
        title,
        body: body || '',
        data: data || {},
        sound: 'default',
      }),
    });
    const result = await resp.json();

    return new Response(JSON.stringify(result), { status: 200, headers: { 'Content-Type': 'application/json' } });
  } catch (e) {
    return new Response(JSON.stringify({ error: String(e) }), { status: 500 });
  }
});
