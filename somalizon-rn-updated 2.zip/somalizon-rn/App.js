import React, { useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import { Audio } from 'expo-av';
import { AuthProvider, useAuth } from './src/contexts/AuthContext';
import { CartProvider } from './src/contexts/CartContext';
import { ThemeProvider, useTheme } from './src/contexts/ThemeContext';
import { NotifProvider, useNotifs } from './src/contexts/NotifContext';
import { RealtimeProvider } from './src/contexts/RealtimeContext';
import { ToastProvider } from './src/components/Toast';
import RootNavigator from './src/navigation/RootNavigator';

function AppInner() {
  const { isDark } = useTheme();
  const { profile } = useAuth();
  const { registerForPush } = useNotifs();

  useEffect(() => {
    Audio.setAudioModeAsync({ playsInSilentModeIOS: true }).catch(() => {});
  }, []);

  // Once we know who's logged in, ask for push permission and save the token.
  useEffect(() => {
    if (profile?.id) registerForPush(profile.id);
  }, [profile?.id]);

  return (
    <ToastProvider>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <RootNavigator />
    </ToastProvider>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <CartProvider>
          <NotifProvider>
            <RealtimeProvider>
              <AppInner />
            </RealtimeProvider>
          </NotifProvider>
        </CartProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
