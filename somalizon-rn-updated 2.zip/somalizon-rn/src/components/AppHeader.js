import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { COLORS, SHADOWS, R } from '../constants/Design';

const P = COLORS.primary;

export default function AppHeader({ title, onBack, right, subtitle, large = false }) {
  return (
    <View style={styles.header}>
      <View style={styles.left}>
        {onBack && (
          <TouchableOpacity style={styles.backBtn} onPress={onBack}>
            <Text style={styles.backIco}>‹</Text>
          </TouchableOpacity>
        )}
        <View>
          {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
          <Text style={[styles.title, large && styles.titleLarge]}>{title}</Text>
        </View>
      </View>
      {right && <View style={styles.right}>{right}</View>}
    </View>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: 16, paddingTop: 52, paddingBottom: 14,
    backgroundColor: COLORS.white, borderBottomWidth: 1, borderBottomColor: COLORS.border,
  },
  left: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  backBtn: {
    width: 38, height: 38, borderRadius: R.md,
    backgroundColor: COLORS.primaryPale, alignItems: 'center', justifyContent: 'center',
  },
  backIco: { color: P, fontSize: 28, fontWeight: '700', lineHeight: 32 },
  subtitle: { fontSize: 11, color: COLORS.text3, fontWeight: '500', marginBottom: 1 },
  title: { fontSize: 17, fontWeight: '800', color: COLORS.text, letterSpacing: -0.3 },
  titleLarge: { fontSize: 22 },
  right: { flexDirection: 'row', alignItems: 'center', gap: 8 },
});
