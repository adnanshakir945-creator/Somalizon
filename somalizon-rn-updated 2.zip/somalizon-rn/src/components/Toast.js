import React, { useEffect, useRef } from 'react';
import { Animated, Text, StyleSheet, Dimensions } from 'react-native';

const { width: W } = Dimensions.get('window');

export function Toast({ message, type = 'success', visible, onHide }) {
  const opacity = useRef(new Animated.Value(0)).current;
  const translateY = useRef(new Animated.Value(-20)).current;

  useEffect(() => {
    if (visible) {
      Animated.parallel([
        Animated.timing(opacity, { toValue: 1, duration: 250, useNativeDriver: true }),
        Animated.timing(translateY, { toValue: 0, duration: 250, useNativeDriver: true }),
      ]).start();
      const timer = setTimeout(() => {
        Animated.parallel([
          Animated.timing(opacity, { toValue: 0, duration: 250, useNativeDriver: true }),
          Animated.timing(translateY, { toValue: -20, duration: 250, useNativeDriver: true }),
        ]).start(() => onHide?.());
      }, 2500);
      return () => clearTimeout(timer);
    }
  }, [visible]);

  if (!visible && opacity.__getValue() === 0) return null;

  const bgColor = type === 'error' ? '#ef4444' : type === 'info' ? '#3b82f6' : '#22c55e';

  return (
    <Animated.View style={[styles.toast, { backgroundColor: bgColor, opacity, transform: [{ translateY }] }]}>
      <Text style={styles.toastTxt}>{message}</Text>
    </Animated.View>
  );
}

// Context-based global toast
import React2, { createContext, useContext, useState, useCallback } from 'react';
const ToastCtx = createContext(null);

export function ToastProvider({ children }) {
  const [toast, setToast] = useState({ visible: false, message: '', type: 'success' });

  const showToast = useCallback((message, type = 'success') => {
    setToast({ visible: true, message, type });
  }, []);

  return (
    <ToastCtx.Provider value={showToast}>
      {children}
      <Toast
        message={toast.message}
        type={toast.type}
        visible={toast.visible}
        onHide={() => setToast(t => ({ ...t, visible: false }))}
      />
    </ToastCtx.Provider>
  );
}

export const useToast = () => useContext(ToastCtx);

const styles = StyleSheet.create({
  toast: {
    position: 'absolute', top: 60, alignSelf: 'center',
    paddingHorizontal: 20, paddingVertical: 12, borderRadius: 24,
    maxWidth: W - 40, zIndex: 9999,
    shadowColor: '#000', shadowOpacity: 0.2, shadowRadius: 8, elevation: 8,
  },
  toastTxt: { color: '#fff', fontWeight: '700', fontSize: 14, textAlign: 'center' },
});
