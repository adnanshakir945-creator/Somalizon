import React, { useEffect, useState } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  ActivityIndicator, RefreshControl, Image,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';

const ORANGE = '#FF6B00';

export default function AsxaabtaScreen({ navigation }) {
  const { profile } = useAuth();
  const { theme } = useTheme();
  const [tab, setTab] = useState('followers');
  const [followers, setFollowers] = useState([]);
  const [following, setFollowing] = useState([]);
  const [followingEmails, setFollowingEmails] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { loadAll(); }, [profile]);

  async function loadAll() {
    if (!profile?.email) { setLoading(false); return; }
    setLoading(true);
    const [followersRes, followingRes] = await Promise.all([
      supabase.from('follows').select('user_email').eq('seller_email', profile.email),
      supabase.from('follows').select('seller_email').eq('user_email', profile.email),
    ]);

    const followerEmails = (followersRes.data || []).map(r => r.user_email);
    const followingEmailsList = (followingRes.data || []).map(r => r.seller_email);
    setFollowingEmails(new Set(followingEmailsList));

    // Load profiles
    const [followerProfs, followingProfs] = await Promise.all([
      followerEmails.length ? supabase.from('profiles').select('*').in('email', followerEmails) : { data: [] },
      followingEmailsList.length ? supabase.from('profiles').select('*').in('email', followingEmailsList) : { data: [] },
    ]);
    setFollowers(followerProfs.data || []);
    setFollowing(followingProfs.data || []);
    setLoading(false);
  }

  async function toggleFollow(email) {
    const isFollowing = followingEmails.has(email);
    const updated = new Set(followingEmails);
    if (isFollowing) {
      updated.delete(email);
      await supabase.from('follows').delete().eq('user_email', profile.email).eq('seller_email', email);
    } else {
      updated.add(email);
      await supabase.from('follows').upsert({ user_email: profile.email, seller_email: email });
    }
    setFollowingEmails(updated);
  }

  const onRefresh = async () => { setRefreshing(true); await loadAll(); setRefreshing(false); };

  function renderUser({ item: u }) {
    const isMe = u.email === profile?.email;
    const isFollowing = followingEmails.has(u.email);
    return (
      <TouchableOpacity
        style={[styles.userRow, { backgroundColor: theme.card, borderBottomColor: theme.border }]}
        onPress={() => navigation.navigate('UserProfile', { email: u.email, name: u.name })}
      >
        {u.profile_image
          ? <Image source={{ uri: u.profile_image }} style={styles.avatar} />
          : <View style={[styles.avatarDefault, { backgroundColor: ORANGE }]}>
              <Text style={styles.avatarTxt}>{(u.name?.[0] || '?').toUpperCase()}</Text>
            </View>
        }
        <View style={{ flex: 1 }}>
          <Text style={[styles.userName, { color: theme.text }]}>{u.name || u.email.split('@')[0]}</Text>
          <Text style={[styles.userType, { color: theme.text2 }]}>{u.user_type === 'seller' ? '🏪 Ganacsade' : '🛍️ Macmiil'}</Text>
        </View>
        {!isMe && (
          <TouchableOpacity
            style={[styles.followBtn, isFollowing && styles.followingBtn]}
            onPress={() => toggleFollow(u.email)}
          >
            <Text style={[styles.followBtnTxt, isFollowing && { color: '#22c55e' }]}>
              {isFollowing ? '✓ Following' : '+ Follow'}
            </Text>
          </TouchableOpacity>
        )}
      </TouchableOpacity>
    );
  }

  const data = tab === 'followers' ? followers : following;

  return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Text style={styles.back}>←</Text></TouchableOpacity>
        <Text style={[styles.title, { color: theme.text }]}>👥 Asxaabta</Text>
        <View style={{ width: 30 }} />
      </View>

      <View style={[styles.tabs, { backgroundColor: theme.card, borderBottomColor: theme.border }]}>
        {[
          { key: 'followers', label: `Kuso Racay (${followers.length})` },
          { key: 'following', label: `Aad Racday (${following.length})` },
        ].map(({ key, label }) => (
          <TouchableOpacity key={key} style={[styles.tab, tab === key && styles.tabOn]} onPress={() => setTab(key)}>
            <Text style={[styles.tabTxt, { color: tab === key ? ORANGE : theme.text2 }]}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {loading ? <ActivityIndicator color={ORANGE} style={{ marginTop: 30 }} /> : (
        <FlatList
          data={data}
          keyExtractor={u => u.email}
          renderItem={renderUser}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={ORANGE} />}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={{ fontSize: 44, marginBottom: 12 }}>👥</Text>
              <Text style={[styles.emptyTxt, { color: theme.text2 }]}>
                {tab === 'followers' ? 'Wali cidna kuguma raacin' : 'Wali cidna kuguma raacin'}
              </Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52, borderBottomWidth: 1 },
  back: { fontSize: 24, color: ORANGE },
  title: { fontSize: 17, fontWeight: '700' },
  tabs: { flexDirection: 'row', borderBottomWidth: 1 },
  tab: { flex: 1, padding: 13, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabOn: { borderBottomColor: ORANGE },
  tabTxt: { fontWeight: '600', fontSize: 13 },
  userRow: { flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1 },
  avatar: { width: 46, height: 46, borderRadius: 23, marginRight: 12 },
  avatarDefault: { width: 46, height: 46, borderRadius: 23, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  avatarTxt: { color: '#fff', fontWeight: '700', fontSize: 18 },
  userName: { fontWeight: '700', fontSize: 14, marginBottom: 2 },
  userType: { fontSize: 12 },
  followBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 20, borderWidth: 1.5, borderColor: ORANGE },
  followingBtn: { borderColor: '#22c55e' },
  followBtnTxt: { color: ORANGE, fontWeight: '700', fontSize: 13 },
  empty: { alignItems: 'center', marginTop: 60 },
  emptyTxt: { fontSize: 14 },
});
