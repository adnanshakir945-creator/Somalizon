import React, { useEffect, useState, useRef } from 'react';
import { View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, ActivityIndicator, Alert, Image } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { COLORS, SHADOWS, R } from '../constants/Design';
import ImageViewer from '../components/ImageViewer';
import { useToast } from '../components/Toast';

// Audio stub - voice recording needs development build
const Audio = {
  requestPermissionsAsync: async () => ({ status: 'denied' }),
  setAudioModeAsync: async () => {},
  Recording: { createAsync: async () => { throw new Error('needs dev build'); }, Presets: {} },
};

const P = COLORS.primary;

function makeChatId(a, b) { return [a, b].map(e => e.toLowerCase().trim()).sort().join('__'); }
function fmtTime(iso) { if (!iso) return ''; const d = new Date(iso); return d.getHours().toString().padStart(2,'0')+':'+d.getMinutes().toString().padStart(2,'0'); }

export default function ChatRoomScreen({ route, navigation }) {
  const { chat, otherName, otherEmail: routeEmail } = route.params;
  const { profile } = useAuth();
  const showToast = useToast();
  const [messages, setMessages] = useState([]);
  const [text, setText]         = useState('');
  const [loading, setLoading]   = useState(true);
  const [sending, setSending]   = useState(false);
  const [recording, setRecording] = useState(null);
  const [isRecording, setIsRecording] = useState(false);
  const [viewerImg, setViewerImg] = useState(null);
  const listRef    = useRef(null);
  const channelRef = useRef(null);

  const myEmail    = profile?.email?.toLowerCase().trim() || '';
  const participants = chat?.participantEmails || chat?.participants || [];
  const otherEmail   = routeEmail || participants.find(e => e !== myEmail) || '';
  const chatId       = chat?.id || makeChatId(myEmail, otherEmail);

  useEffect(() => {
    loadMessages();
    channelRef.current = supabase.channel('msgs-' + chatId)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'messages', filter: 'chat_id=eq.' + chatId }, loadMessages)
      .subscribe();
    return () => { if (channelRef.current) supabase.removeChannel(channelRef.current); };
  }, [chatId]);

  async function loadMessages() {
    const { data } = await supabase.from('messages').select('*').eq('chat_id', chatId).order('created_at', { ascending: true });
    setMessages(data || []); setLoading(false);
    setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
  }

  async function sendMsg(msgText, type = 'text', extra = {}) {
    if (!msgText.trim() && type === 'text') return;
    setSending(true);
    await supabase.from('messages').insert({ chat_id: chatId, senderEmail: myEmail, senderName: profile?.name || myEmail.split('@')[0], type, t: msgText, time: fmtTime(new Date().toISOString()), ...extra });
    await supabase.from('chats').upsert({ id: chatId, participantEmails: [myEmail, otherEmail], participants: [myEmail, otherEmail], lastMessage: type === 'text' ? msgText : type === 'image' ? '📷 Sawir' : '🎙️ Codsi', lastSenderEmail: myEmail, lastTime: new Date().toISOString() });
    setSending(false); setText('');
    setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
  }

  async function sendImage() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { showToast('Fasax gallery', 'error'); return; }
    const res = await ImagePicker.launchImageLibraryAsync({ quality: 0.7, base64: true });
    if (res.canceled || !res.assets?.length) return;
    const asset = res.assets[0];
    const ext   = asset.uri.split('.').pop() || 'jpg';
    const path  = `chats/${chatId}_${Date.now()}.${ext}`;
    const bytes = Uint8Array.from(atob(asset.base64), c => c.charCodeAt(0));
    const { error } = await supabase.storage.from('chat-images').upload(path, bytes, { contentType: `image/${ext}`, upsert: false });
    if (error) { showToast(error.message, 'error'); return; }
    const { data: urlData } = supabase.storage.from('chat-images').getPublicUrl(path);
    await sendMsg('📷 Sawir', 'image', { img: urlData.publicUrl });
  }

  async function toggleRecord() {
    if (isRecording) {
      setIsRecording(false);
      if (recording) {
        await recording.stopAndUnloadAsync();
        const uri = recording.getURI();
        setRecording(null);
        if (uri) await sendMsg('🎙️ Codsi', 'voice', { voiceUri: uri });
      }
    } else {
      try {
        await Audio.requestPermissionsAsync();
        await Audio.setAudioModeAsync({ allowsRecordingIOS: true, playsInSilentModeIOS: true });
        const { recording: rec } = await Audio.Recording.createAsync(Audio.RecordingOptionsPresets.HIGH_QUALITY);
        setRecording(rec); setIsRecording(true);
      } catch { showToast('Makarafoon-ka lama furi karin', 'error'); }
    }
  }

  function BubbleMsg({ m }) {
    const isMe = m.senderEmail === myEmail;
    return (
      <View style={[styles.bubble, isMe ? styles.bubbleMe : styles.bubbleOther]}>
        {!isMe && <View style={styles.bubbleAvatar}><Text style={styles.bubbleAvatarTxt}>{(otherName?.[0]||'?').toUpperCase()}</Text></View>}
        <View style={[styles.bubbleBody, isMe ? styles.bubbleBodyMe : styles.bubbleBodyOther]}>
          {m.type === 'image' && m.img
            ? <TouchableOpacity onPress={() => setViewerImg(m.img)}>
                <Image source={{ uri: m.img }} style={styles.bubbleImg} resizeMode="cover" />
              </TouchableOpacity>
            : m.type === 'voice'
            ? <Text style={[styles.bubbleTxt, isMe && styles.bubbleTxtMe]}>🎙️ Codsi</Text>
            : <Text style={[styles.bubbleTxt, isMe && styles.bubbleTxtMe]}>{m.t || m.text}</Text>
          }
          <Text style={[styles.bubbleTime, isMe && styles.bubbleTimeMe]}>{m.time || fmtTime(m.created_at)}</Text>
        </View>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView style={styles.wrap} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backTxt}>←</Text>
        </TouchableOpacity>
        <View style={styles.headerAvatar}>
          <Text style={styles.headerAvatarTxt}>{(otherName?.[0]||'?').toUpperCase()}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.headerName}>{otherName || otherEmail.split('@')[0]}</Text>
          <Text style={styles.headerStatus}>🟢 Online</Text>
        </View>
        <View style={styles.headerActions}>
          <TouchableOpacity style={styles.headerBtn} onPress={() => navigation.navigate('Call', { otherEmail, otherName, isIncoming: false })}>
            <Text style={{ fontSize: 18 }}>📞</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.headerBtn} onPress={() => navigation.navigate('UserProfile', { email: otherEmail, name: otherName })}>
            <Text style={{ fontSize: 18 }}>👤</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Messages */}
      {loading
        ? <ActivityIndicator color={P} style={{ flex: 1 }} />
        : <FlatList
            ref={listRef}
            data={messages} keyExtractor={m => String(m.id)}
            contentContainerStyle={{ padding: 16, paddingBottom: 8 }}
            onContentSizeChange={() => listRef.current?.scrollToEnd({ animated: true })}
            renderItem={({ item }) => <BubbleMsg m={item} />}
            style={{ backgroundColor: COLORS.bg }}
            ListEmptyComponent={
              <View style={styles.empty}>
                <Text style={{ fontSize: 46, marginBottom: 10 }}>💬</Text>
                <Text style={styles.emptyTxt}>Fariin kuma jirto weli</Text>
                <Text style={styles.emptyHint}>Ku bilow xariirka! 👋</Text>
              </View>
            }
          />
      }

      {/* Input bar */}
      <View style={styles.inputBar}>
        <TouchableOpacity style={styles.actionBtn} onPress={sendImage}>
          <Text style={{ fontSize: 20 }}>📷</Text>
        </TouchableOpacity>
        <TextInput
          style={styles.input} placeholder="Fariin qor..."
          placeholderTextColor={COLORS.text3} value={text}
          onChangeText={setText} multiline maxLength={1000}
        />
        <TouchableOpacity
          style={[styles.actionBtn, isRecording && styles.actionBtnRecording]}
          onPress={toggleRecord}
        >
          <Text style={{ fontSize: 20 }}>{isRecording ? '⏹️' : '🎙️'}</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.sendBtn, (!text.trim() || sending) && styles.sendBtnDis]}
          onPress={() => sendMsg(text)} disabled={!text.trim() || sending}
        >
          {sending ? <ActivityIndicator color="#fff" size="small" /> : <Text style={styles.sendIco}>➤</Text>}
        </TouchableOpacity>
      </View>

      <ImageViewer uri={viewerImg} visible={!!viewerImg} onClose={() => setViewerImg(null)} />
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#fff' },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12, paddingTop: 52, paddingBottom: 12, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: COLORS.border, gap: 10 },
  backBtn: { width: 36, height: 36, borderRadius: 11, backgroundColor: COLORS.primaryPale, alignItems: 'center', justifyContent: 'center' },
  backTxt: { color: P, fontSize: 22, fontWeight: '700', lineHeight: 26 },
  headerAvatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: P, alignItems: 'center', justifyContent: 'center' },
  headerAvatarTxt: { color: '#fff', fontWeight: '800', fontSize: 16 },
  headerName: { fontWeight: '800', fontSize: 15, color: COLORS.text },
  headerStatus: { fontSize: 11, color: COLORS.success, fontWeight: '600' },
  headerActions: { flexDirection: 'row', gap: 6 },
  headerBtn: { width: 36, height: 36, borderRadius: 11, backgroundColor: COLORS.input, alignItems: 'center', justifyContent: 'center' },
  bubble: { flexDirection: 'row', marginBottom: 10, alignItems: 'flex-end' },
  bubbleMe: { justifyContent: 'flex-end' },
  bubbleOther: { justifyContent: 'flex-start' },
  bubbleAvatar: { width: 28, height: 28, borderRadius: 14, backgroundColor: COLORS.primaryPale, alignItems: 'center', justifyContent: 'center', marginRight: 6 },
  bubbleAvatarTxt: { color: P, fontSize: 12, fontWeight: '800' },
  bubbleBody: { maxWidth: '75%', borderRadius: 18, padding: 10, paddingHorizontal: 14 },
  bubbleBodyMe: { backgroundColor: P, borderBottomRightRadius: 4 },
  bubbleBodyOther: { backgroundColor: COLORS.input, borderBottomLeftRadius: 4 },
  bubbleImg: { width: 200, height: 150, borderRadius: 12 },
  bubbleTxt: { fontSize: 14, color: COLORS.text, lineHeight: 20 },
  bubbleTxtMe: { color: '#fff' },
  bubbleTime: { fontSize: 10, color: COLORS.text3, marginTop: 4, textAlign: 'right' },
  bubbleTimeMe: { color: 'rgba(255,255,255,0.7)' },
  empty: { alignItems: 'center', marginTop: 80 },
  emptyTxt: { fontSize: 16, fontWeight: '700', color: COLORS.text, marginBottom: 4 },
  emptyHint: { color: COLORS.text2, fontSize: 13 },
  inputBar: { flexDirection: 'row', alignItems: 'flex-end', padding: 10, backgroundColor: '#fff', borderTopWidth: 1, borderTopColor: COLORS.border, gap: 8 },
  actionBtn: { width: 40, height: 40, borderRadius: R.md, backgroundColor: COLORS.input, alignItems: 'center', justifyContent: 'center' },
  actionBtnRecording: { backgroundColor: '#FFE5E5' },
  input: { flex: 1, borderWidth: 1.5, borderColor: COLORS.inputBorder, borderRadius: R.xl, paddingHorizontal: 14, paddingVertical: 10, fontSize: 14, color: COLORS.text, maxHeight: 120, backgroundColor: COLORS.input },
  sendBtn: { width: 42, height: 42, borderRadius: 21, backgroundColor: P, alignItems: 'center', justifyContent: 'center', ...SHADOWS.orange },
  sendBtnDis: { backgroundColor: COLORS.text3, shadowOpacity: 0 },
  sendIco: { color: '#fff', fontSize: 16 },
});
