import React, { useRef, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Dimensions, Animated } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { COLORS, SHADOWS, R } from '../constants/Design';
import { PrimaryBtn } from '../components/Buttons';

const { width: W } = Dimensions.get('window');
const P = COLORS.primary;

const SLIDES = [
  { id: '1', emoji: '🛍️', title: 'Ku Soo Dhawaaw\nSomalizon!', desc: 'Suuqa Online-ka ugu weyn Soomaaliya. Alaab kasta oo aad rabto waxaad ka heli kartaa halkan.', bg: P, textColor: '#fff', subColor: 'rgba(255,255,255,0.8)' },
  { id: '2', emoji: '💳', title: 'EVC & Zaad\nLa Bixiso', desc: 'Lacag bixin fudud oo amaan ah. EVC Plus, Zaad, iyo eDahab ayaa la qaataa.', bg: '#FFF0E6', textColor: COLORS.text, subColor: COLORS.text2 },
  { id: '3', emoji: '🚀', title: 'Iibi &\nGanacsado', desc: 'Ganacsade ah? Dukaan u fur, alaab geli, oo macaamilo kala hadal si toos ah.', bg: '#FFF8F4', textColor: COLORS.text, subColor: COLORS.text2 },
];

export default function OnboardingScreen({ onDone }) {
  const [idx, setIdx] = useState(0);
  const ref = useRef(null);
  const scrollX = useRef(new Animated.Value(0)).current;

  async function finish() { await AsyncStorage.setItem('onboarded', '1'); onDone(); }
  function next() {
    if (idx < SLIDES.length - 1) { ref.current?.scrollToIndex({ index: idx + 1, animated: true }); setIdx(idx + 1); }
    else finish();
  }

  const s = SLIDES[idx];

  return (
    <View style={[styles.wrap, { backgroundColor: s.bg }]}>
      <FlatList
        ref={ref} data={SLIDES} horizontal pagingEnabled
        showsHorizontalScrollIndicator={false}
        keyExtractor={s => s.id}
        onMomentumScrollEnd={e => setIdx(Math.round(e.nativeEvent.contentOffset.x / W))}
        renderItem={({ item }) => (
          <View style={[styles.slide, { backgroundColor: item.bg, width: W }]}>
            <View style={[styles.emojiBox, { backgroundColor: item.bg === P ? 'rgba(255,255,255,0.2)' : COLORS.primaryPale }]}>
              <Text style={styles.emoji}>{item.emoji}</Text>
            </View>
            <Text style={[styles.title, { color: item.textColor }]}>{item.title}</Text>
            <Text style={[styles.desc, { color: item.subColor }]}>{item.desc}</Text>
          </View>
        )}
      />

      <View style={[styles.footer, { backgroundColor: s.bg }]}>
        {/* Dots */}
        <View style={styles.dots}>
          {SLIDES.map((_, i) => (
            <View key={i} style={[styles.dot,
              { backgroundColor: i === idx ? (s.bg === P ? '#fff' : P) : (s.bg === P ? 'rgba(255,255,255,0.3)' : COLORS.border),
                width: i === idx ? 24 : 8 }
            ]} />
          ))}
        </View>

        <View style={styles.btnRow}>
          {idx < SLIDES.length - 1 && (
            <TouchableOpacity onPress={finish} style={styles.skipBtn}>
              <Text style={[styles.skipTxt, { color: s.bg === P ? 'rgba(255,255,255,0.7)' : COLORS.text3 }]}>Bood</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            style={[styles.nextBtn, { backgroundColor: s.bg === P ? '#fff' : P }, s.bg !== P && SHADOWS.orange]}
            onPress={next}
          >
            <Text style={[styles.nextTxt, { color: s.bg === P ? P : '#fff' }]}>
              {idx === SLIDES.length - 1 ? '🚀 Bilow' : 'Xiga →'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  slide: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 36 },
  emojiBox: { width: 140, height: 140, borderRadius: 44, alignItems: 'center', justifyContent: 'center', marginBottom: 36 },
  emoji: { fontSize: 72 },
  title: { fontSize: 32, fontWeight: '900', textAlign: 'center', lineHeight: 38, marginBottom: 16, letterSpacing: -0.5 },
  desc: { fontSize: 16, textAlign: 'center', lineHeight: 24 },
  footer: { paddingHorizontal: 28, paddingBottom: 48, paddingTop: 20 },
  dots: { flexDirection: 'row', justifyContent: 'center', gap: 7, marginBottom: 28 },
  dot: { height: 8, borderRadius: 4 },
  btnRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 14 },
  skipBtn: { padding: 12 },
  skipTxt: { fontSize: 15, fontWeight: '600' },
  nextBtn: { paddingHorizontal: 32, paddingVertical: 16, borderRadius: R.full },
  nextTxt: { fontWeight: '800', fontSize: 16 },
});
