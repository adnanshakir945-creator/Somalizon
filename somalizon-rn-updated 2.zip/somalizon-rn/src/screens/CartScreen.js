import React, { useState } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  TextInput, Alert, ActivityIndicator, ScrollView,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import LocationModal from '../components/LocationModal';
import { useToast } from '../components/Toast';

const ORANGE = '#FF6B00';
const PAY_METHODS = [
  { id: 'evc', label: 'EVC Plus', emoji: '💳', placeholder: '063XXXXXXX' },
  { id: 'zaad', label: 'Zaad', emoji: '📱', placeholder: '063XXXXXXX' },
  { id: 'edahab', label: 'eDahab', emoji: '💰', placeholder: '09XXXXXXXX' },
  { id: 'kash', label: 'Kash', emoji: '💵', placeholder: '' },
];

export default function CartScreen({ navigation }) {
  const { cart, changeQty, removeFromCart, clearCart, totalPrice } = useCart();
  const { profile } = useAuth();
  const { theme } = useTheme();
  const showToast = useToast();
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [payMethod, setPayMethod] = useState('evc');
  const [payNumber, setPayNumber] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [step, setStep] = useState('cart'); // 'cart' | 'checkout'
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [savedAddress, setSavedAddress] = useState(null);

  async function placeOrder() {
    const addr = savedAddress;
    if (!addr?.phone || !addr?.city) { setShowLocationModal(true); return; }
    if (!profile) { showToast('Marka hore soo gal', 'error'); return; }
    setSubmitting(true);

    const promises = cart.map(item =>
      supabase.from('orders').insert({
        prodId: item.id, prodName: item.name, prodEmoji: item.emoji || '📦',
        qty: item.qty, totalPrice: item.price * item.qty,
        buyerName: profile.name, buyerEmail: profile.email,
        sellerEmail: item.sellerEmail, sellerName: item.seller,
        phone: addr.phone, address: `${addr.city}, ${addr.district || ''} ${addr.details || ''}`.trim(),
        payMethod, payNumber: payNumber.trim(),
        status: 'La Diray',
      })
    );

    const results = await Promise.all(promises);
    const anyError = results.find(r => r.error);
    setSubmitting(false);

    if (anyError) { showToast(anyError.error.message, 'error'); return; }
    const orderedCount = cart.length;
    const orderedTotal = totalPrice;
    clearCart();
    showToast(`✅ Codsiga La Diray! ${orderedCount} alaab — Sh.So ${orderedTotal.toLocaleString()}`, 'success');
    navigation.goBack();
  }

  if (cart.length === 0) return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Text style={styles.back}>←</Text></TouchableOpacity>
        <Text style={[styles.title, { color: theme.text }]}>🛒 Kaydiyaha</Text>
        <View style={{ width: 30 }} />
      </View>
      <View style={styles.empty}>
        <Text style={{ fontSize: 60, marginBottom: 16 }}>🛒</Text>
        <Text style={[styles.emptyTxt, { color: theme.text2 }]}>Kaydiyaha waa madhan yahay</Text>
        <TouchableOpacity style={styles.shopBtn} onPress={() => navigation.navigate('Home')}>
          <Text style={styles.shopBtnTxt}>🛍️ Alaab Raadi</Text>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header }]}>
        <TouchableOpacity onPress={() => step === 'checkout' ? setStep('cart') : navigation.goBack()}>
          <Text style={styles.back}>←</Text>
        </TouchableOpacity>
        <Text style={[styles.title, { color: theme.text }]}>{step === 'cart' ? '🛒 Kaydiyaha' : '💳 Bixi'}</Text>
        <View style={{ width: 30 }} />
      </View>

      {step === 'cart' ? (
        <>
          <FlatList
            data={cart} keyExtractor={c => String(c.id)}
            contentContainerStyle={{ padding: 14 }}
            renderItem={({ item: c }) => (
              <View style={[styles.cartItem, { backgroundColor: theme.card }]}>
                <Text style={{ fontSize: 36, marginRight: 12 }}>{c.emoji || '📦'}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.itemName, { color: theme.text }]} numberOfLines={1}>{c.name}</Text>
                  <Text style={styles.itemPrice}>Sh.So {(c.price * c.qty).toLocaleString()}</Text>
                </View>
                <View style={styles.qtyRow}>
                  <TouchableOpacity style={styles.qtyBtn} onPress={() => changeQty(c.id, -1)}><Text style={styles.qtyTxt}>−</Text></TouchableOpacity>
                  <Text style={[styles.qtyNum, { color: theme.text }]}>{c.qty}</Text>
                  <TouchableOpacity style={styles.qtyBtn} onPress={() => changeQty(c.id, 1)}><Text style={styles.qtyTxt}>+</Text></TouchableOpacity>
                </View>
                <TouchableOpacity onPress={() => removeFromCart(c.id)} style={{ marginLeft: 8 }}><Text style={{ fontSize: 18 }}>🗑️</Text></TouchableOpacity>
              </View>
            )}
          />
          <View style={[styles.footer, { backgroundColor: theme.card }]}>
            <Text style={[styles.total, { color: theme.text }]}>Wadarta: <Text style={{ color: ORANGE }}>Sh.So {totalPrice.toLocaleString()}</Text></Text>
            <TouchableOpacity style={styles.checkoutBtn} onPress={() => setStep('checkout')}>
              <Text style={styles.checkoutBtnTxt}>Bixi Hadda →</Text>
            </TouchableOpacity>
          </View>
        </>
      ) : (
        <ScrollView contentContainerStyle={{ padding: 16 }}>
          {/* Address section */}
          <TouchableOpacity
            style={[styles.addrBox, { backgroundColor: theme.card, borderColor: savedAddress ? '#22c55e' : ORANGE }]}
            onPress={() => setShowLocationModal(true)}
          >
            {savedAddress ? (
              <View>
                <Text style={[styles.addrTitle, { color: theme.text }]}>📍 {savedAddress.city}, {savedAddress.district}</Text>
                <Text style={[styles.addrSub, { color: theme.text2 }]}>📞 {savedAddress.phone} · {savedAddress.details}</Text>
                <Text style={styles.addrChange}>Beddel ✏️</Text>
              </View>
            ) : (
              <Text style={styles.addrPlaceholder}>📍 Cinwaanka Geli (riix halkan)</Text>
            )}
          </TouchableOpacity>

          <LocationModal
            visible={showLocationModal}
            onClose={() => setShowLocationModal(false)}
            onSave={addr => setSavedAddress(addr)}
            initialData={savedAddress || {}}
          />
          <Text style={[styles.label, { color: theme.text }]}>Habka Lacag Bixinta</Text>
          <View style={styles.payRow}>
            {PAY_METHODS.map(p => (
              <TouchableOpacity key={p.id} style={[styles.payChip, payMethod === p.id && styles.payChipOn]} onPress={() => setPayMethod(p.id)}>
                <Text style={{ fontSize: 20 }}>{p.emoji}</Text>
                <Text style={[styles.payChipTxt, payMethod === p.id && { color: '#fff' }]}>{p.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {payMethod !== 'kash' && (
            <>
              <Text style={[styles.label, { color: theme.text }]}>Lambarka {PAY_METHODS.find(p => p.id === payMethod)?.label}</Text>
              <TextInput
                style={[styles.input, { backgroundColor: theme.input, color: theme.inputText }]}
                placeholder={PAY_METHODS.find(p => p.id === payMethod)?.placeholder}
                placeholderTextColor="#999" keyboardType="phone-pad"
                value={payNumber} onChangeText={setPayNumber}
              />
            </>
          )}

          <Text style={[styles.label, { color: theme.text }]}>📞 Lambarka Lacag Bixinta</Text>
          <View style={[styles.summary, { backgroundColor: theme.card }]}>
            <Text style={[styles.summaryTitle, { color: theme.text }]}>Koobidda Dalabka</Text>
            {cart.map(c => (
              <View key={c.id} style={styles.summaryRow}>
                <Text style={{ color: theme.text2 }}>{c.emoji} {c.name} x{c.qty}</Text>
                <Text style={{ color: theme.text, fontWeight: '600' }}>Sh.So {(c.price * c.qty).toLocaleString()}</Text>
              </View>
            ))}
            <View style={[styles.summaryRow, { borderTopWidth: 1, borderTopColor: theme.border, marginTop: 8, paddingTop: 8 }]}>
              <Text style={{ color: theme.text, fontWeight: '700' }}>Wadarta</Text>
              <Text style={{ color: ORANGE, fontWeight: '800', fontSize: 16 }}>Sh.So {totalPrice.toLocaleString()}</Text>
            </View>
          </View>

          <TouchableOpacity style={styles.orderBtn} onPress={placeOrder} disabled={submitting}>
            {submitting ? <ActivityIndicator color="#fff" /> : <Text style={styles.orderBtnTxt}>✅ Xaqiiji Dalabka</Text>}
          </TouchableOpacity>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52 },
  back: { fontSize: 24, color: ORANGE },
  title: { fontSize: 17, fontWeight: '700' },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyTxt: { fontSize: 15, marginBottom: 20 },
  shopBtn: { backgroundColor: ORANGE, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 14 },
  shopBtnTxt: { color: '#fff', fontWeight: '700' },
  addrBox: { borderWidth: 2, borderRadius: 14, padding: 14, marginBottom: 14 },
  addrTitle: { fontWeight: '700', fontSize: 14, marginBottom: 3 },
  addrSub: { fontSize: 12, marginBottom: 3 },
  addrChange: { color: ORANGE, fontSize: 12, fontWeight: '600' },
  addrPlaceholder: { color: ORANGE, fontWeight: '600', fontSize: 14, textAlign: 'center' },
  cartItem: { flexDirection: 'row', alignItems: 'center', borderRadius: 14, padding: 12, marginBottom: 10 },
  itemName: { fontWeight: '700', fontSize: 14, marginBottom: 3 },
  itemPrice: { color: ORANGE, fontWeight: '600' },
  qtyRow: { flexDirection: 'row', alignItems: 'center' },
  qtyBtn: { backgroundColor: '#f0f0f0', width: 30, height: 30, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  qtyTxt: { fontSize: 18, fontWeight: '600', color: '#333' },
  qtyNum: { marginHorizontal: 10, fontSize: 15, fontWeight: '700' },
  footer: { padding: 16, borderTopWidth: 1, borderTopColor: '#f0f0f0' },
  total: { fontWeight: '700', fontSize: 15, marginBottom: 12 },
  checkoutBtn: { backgroundColor: ORANGE, padding: 16, borderRadius: 14, alignItems: 'center' },
  checkoutBtnTxt: { color: '#fff', fontWeight: '800', fontSize: 15 },
  label: { fontWeight: '700', fontSize: 13, marginBottom: 8, marginTop: 4 },
  input: { borderRadius: 12, padding: 13, marginBottom: 14, fontSize: 14 },
  payRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 },
  payChip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 12, backgroundColor: '#f0f0f0' },
  payChipOn: { backgroundColor: ORANGE },
  payChipTxt: { fontWeight: '600', color: '#555', fontSize: 13 },
  summary: { borderRadius: 14, padding: 14, marginBottom: 16 },
  summaryTitle: { fontWeight: '700', fontSize: 14, marginBottom: 10 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4 },
  orderBtn: { backgroundColor: '#22c55e', padding: 16, borderRadius: 14, alignItems: 'center', marginBottom: 30 },
  orderBtnTxt: { color: '#fff', fontWeight: '800', fontSize: 15 },
});
