import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, ActivityIndicator, Alert, ScrollView, Dimensions } from 'react-native';
import { supabase } from '../lib/supabase';
import { COLORS, SHADOWS, R } from '../constants/Design';
import { PrimaryBtn } from '../components/Buttons';
import { useToast } from '../components/Toast';

const { width: W } = Dimensions.get('window');
const P = COLORS.primary;

export default function SignupScreen({ navigation }) {
  const [name, setName]   = useState('');
  const [shop, setShop]   = useState('');
  const [email, setEmail] = useState('');
  const [pass, setPass]   = useState('');
  const [loading, setLoading] = useState(false);
  const showToast = useToast();

  async function handleRegister() {
    if (!name || !shop || !email || !pass) { showToast('Dhammaan buuxi', 'error'); return; }
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({ email: email.trim(), password: pass, options: { data: { name, user_type: 'seller', shop_name: shop } } });
    if (error) { showToast(error.message, 'error'); setLoading(false); return; }
    const uid = data.user?.id;
    if (uid) {
      await supabase.from('profiles').upsert({ id: uid, email: email.trim().toLowerCase(), name, user_type: 'seller', shop_name: shop });
      await supabase.from('stores').upsert({ id: uid, name: shop, sellerName: name, sellerEmail: email.trim(), sellerUid: uid, emoji: '🏪', store_desc: 'Kusoo dhawaada ' + shop, rating: 5.0, followers: 0, verified: false });
    }
    showToast('Account la sameeyay! Hadda gal email iyo passwordkaaga.', 'success');
    setLoading(false);
    navigation.navigate('Login');
  }

  const FIELDS = [
    { label: 'Magacaaga', val: name, set: setName, ph: 'Magaca Dhabta ah', icon: '👤' },
    { label: 'Magaca Dukaanka', val: shop, set: setShop, ph: 'Somali Store...', icon: '🏪' },
    { label: 'Email', val: email, set: setEmail, ph: 'email@example.com', icon: '✉️', caps: 'none', kb: 'email-address' },
    { label: 'Password', val: pass, set: setPass, ph: '••••••••', icon: '🔒', sec: true },
  ];

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: '#fff' }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        {/* Orange top */}
        <View style={styles.topBand}>
          <View style={styles.waveBg} />
          <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
            <Text style={styles.backTxt}>←</Text>
          </TouchableOpacity>
          <View style={styles.logoBox}><Text style={{ fontSize: 34 }}>🏪</Text></View>
          <Text style={styles.topTitle}>Ganacsade Cusub</Text>
          <Text style={styles.topSub}>Account samee si aad alaab u iibiyo</Text>
        </View>

        <View style={{ padding: 24 }}>
          {FIELDS.map(f => (
            <View key={f.label} style={{ marginBottom: 16 }}>
              <Text style={styles.label}>{f.label}</Text>
              <View style={styles.inputWrap}>
                <Text style={styles.inputIcon}>{f.icon}</Text>
                <TextInput
                  style={styles.input} placeholder={f.ph}
                  placeholderTextColor={COLORS.text3}
                  autoCapitalize={f.caps || 'words'} keyboardType={f.kb || 'default'}
                  secureTextEntry={f.sec || false} value={f.val} onChangeText={f.set}
                />
              </View>
            </View>
          ))}

          <PrimaryBtn label="🚀  Account Samee" onPress={handleRegister} loading={loading} style={{ marginTop: 8 }} />

          <TouchableOpacity style={styles.loginRow} onPress={() => navigation.navigate('Login')}>
            <Text style={styles.loginTxt}>Horey account u leedahay? <Text style={{ color: P, fontWeight: '800' }}>Soo gal →</Text></Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  topBand: { backgroundColor: P, paddingTop: 54, paddingBottom: 32, alignItems: 'center', borderBottomLeftRadius: 32, borderBottomRightRadius: 32, overflow: 'hidden', marginBottom: 8 },
  waveBg: { position: 'absolute', width: W * 1.2, height: W * 1.2, borderRadius: W * 0.6, backgroundColor: 'rgba(255,255,255,0.08)', top: -W * 0.5, left: -W * 0.1 },
  backBtn: { position: 'absolute', top: 54, left: 20, width: 38, height: 38, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  backTxt: { color: '#fff', fontSize: 22, fontWeight: '700', lineHeight: 26 },
  logoBox: { width: 72, height: 72, borderRadius: 22, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', marginBottom: 12, ...SHADOWS.card },
  topTitle: { fontSize: 26, fontWeight: '900', color: '#fff', letterSpacing: -0.3 },
  topSub: { color: 'rgba(255,255,255,0.75)', fontSize: 13, marginTop: 4 },
  label: { fontSize: 13, fontWeight: '700', color: COLORS.text, marginBottom: 6 },
  inputWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.input, borderRadius: R.lg, borderWidth: 1.5, borderColor: COLORS.inputBorder, paddingHorizontal: 14 },
  inputIcon: { fontSize: 18, marginRight: 10 },
  input: { flex: 1, paddingVertical: 14, fontSize: 15, color: COLORS.text },
  loginRow: { alignItems: 'center', marginTop: 16 },
  loginTxt: { color: COLORS.text2, fontSize: 14 },
});
