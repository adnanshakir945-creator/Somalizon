import React, { useEffect, useState } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  ActivityIndicator, RefreshControl,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';

const ORANGE = '#FF6B00';
const TABS = [
  { key: 'given', label: '⭐ Qiimayntayda' },
  { key: 'received', label: '📦 Alaabta Qiimayn' },
  { key: 'likes', label: '❤️ Jecelaanka' },
];

export default function ReviewsPageScreen({ navigation }) {
  const { profile } = useAuth();
  const { theme } = useTheme();
  const [tab, setTab] = useState('given');
  const [given, setGiven] = useState([]);
  const [received, setReceived] = useState([]);
  const [likes, setLikes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { loadAll(); }, [profile]);

  async function loadAll() {
    if (!profile?.email) { setLoading(false); return; }
    setLoading(true);
    const [givenRes, receivedRes, likesRes] = await Promise.all([
      supabase.from('reviews').select('*').eq('buyerEmail', profile.email).order('created_at', { ascending: false }),
      supabase.from('reviews').select('*').eq('sellerEmail', profile.email).order('created_at', { ascending: false }),
      supabase.from('video_interactions').select('*').eq('user_email', profile.email).eq('type', 'like').order('created_at', { ascending: false }),
    ]);
    setGiven(givenRes.data || []);
    setReceived(receivedRes.data || []);
    setLikes(likesRes.data || []);
    setLoading(false);
  }

  const currentData = tab === 'given' ? given : tab === 'received' ? received : likes;

  function renderItem({ item: r }) {
    if (tab === 'likes') return (
      <View style={[styles.card, { backgroundColor: theme.card }]}>
        <Text style={[styles.prodName, { color: theme.text }]}>❤️ Video La Jecel Yahay</Text>
        <Text style={[styles.reviewTxt, { color: theme.text2 }]}>Video ID: {r.video_id}</Text>
      </View>
    );
    return (
      <TouchableOpacity
        style={[styles.card, { backgroundColor: theme.card }]}
        onPress={() => navigation.navigate('ProductDetail', { product: { id: r.prodId, name: r.prod, storeId: r.storeId } })}
      >
        <View style={styles.cardTop}>
          <View style={{ flex: 1 }}>
            <Text style={[styles.prodName, { color: theme.text }]}>{r.prod || 'Alaab'}</Text>
            <Text style={[styles.reviewer, { color: theme.text2 }]}>{tab === 'given' ? ('👤 ' + r.buyerName) : ('🏪 ' + (r.sellerName || 'Ganacsade'))}</Text>
          </View>
          <Text style={styles.stars}>{'⭐'.repeat(r.stars || 0)}</Text>
        </View>
        <Text style={[styles.reviewTxt, { color: theme.text2 }]}>{r.text}</Text>
        <Text style={styles.time}>{new Date(r.created_at).toLocaleDateString('so-SO')}</Text>
      </TouchableOpacity>
    );
  }

  return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Text style={styles.back}>←</Text></TouchableOpacity>
        <Text style={[styles.title, { color: theme.text }]}>📊 Qiimayntayda</Text>
        <View style={{ width: 30 }} />
      </View>

      <View style={[styles.tabs, { backgroundColor: theme.card, borderBottomColor: theme.border }]}>
        {TABS.map(t => (
          <TouchableOpacity key={t.key} style={[styles.tab, tab === t.key && styles.tabOn]} onPress={() => setTab(t.key)}>
            <Text style={[styles.tabTxt, { color: tab === t.key ? ORANGE : theme.text2 }]}>{t.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {loading ? <ActivityIndicator color={ORANGE} style={{ marginTop: 40 }} /> : (
        <FlatList
          data={currentData} keyExtractor={(_, i) => String(i)}
          contentContainerStyle={{ padding: 14 }}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await loadAll(); setRefreshing(false); }} tintColor={ORANGE} />}
          renderItem={renderItem}
          ListEmptyComponent={<View style={styles.empty}><Text style={[styles.emptyTxt, { color: theme.text2 }]}>Wax ma jiraan weli</Text></View>}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52, borderBottomWidth: 1 },
  back: { fontSize: 24, color: ORANGE },
  title: { fontSize: 17, fontWeight: '700' },
  tabs: { flexDirection: 'row', borderBottomWidth: 1 },
  tab: { flex: 1, paddingVertical: 13, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabOn: { borderBottomColor: ORANGE },
  tabTxt: { fontSize: 12, fontWeight: '600' },
  card: { borderRadius: 14, padding: 14, marginBottom: 10 },
  cardTop: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 8 },
  prodName: { fontWeight: '700', fontSize: 14, marginBottom: 2 },
  reviewer: { fontSize: 12 },
  stars: { fontSize: 13 },
  reviewTxt: { fontSize: 13, lineHeight: 18, marginBottom: 6 },
  time: { fontSize: 11, color: '#aaa' },
  empty: { alignItems: 'center', marginTop: 60 },
  emptyTxt: { fontSize: 15 },
});
