import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, Dimensions } from 'react-native';
import { COLORS } from '../constants/Design';

const { width: W } = Dimensions.get('window');
const P = COLORS.primary;

export default function SplashScreen({ onDone }) {
  const logoScale   = useRef(new Animated.Value(0.4)).current;
  const logoOpacity = useRef(new Animated.Value(0)).current;
  const tagOpacity  = useRef(new Animated.Value(0)).current;
  const progress    = useRef(new Animated.Value(0)).current;
  const bgOpacity   = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.sequence([
      Animated.timing(bgOpacity, { toValue: 1, duration: 200, useNativeDriver: true }),
      Animated.parallel([
        Animated.spring(logoScale,   { toValue: 1, tension: 70, friction: 7, useNativeDriver: true }),
        Animated.timing(logoOpacity, { toValue: 1, duration: 400, useNativeDriver: true }),
      ]),
      Animated.timing(tagOpacity,  { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.timing(progress,    { toValue: W * 0.55, duration: 1600, useNativeDriver: false }),
    ]).start(() => setTimeout(onDone, 200));
  }, []);

  return (
    <Animated.View style={[styles.wrap, { opacity: bgOpacity }]}>
      {/* Orange circle glow behind logo */}
      <View style={styles.glow} />

      <Animated.View style={[styles.center, { transform: [{ scale: logoScale }], opacity: logoOpacity }]}>
        <View style={styles.logoBox}>
          <Text style={styles.logoEmoji}>🛍️</Text>
        </View>
        <Text style={styles.title}>
          Somali<Text style={styles.titleOrange}>zon</Text>
        </Text>
      </Animated.View>

      <Animated.Text style={[styles.tag, { opacity: tagOpacity }]}>
        SUUQA ONLINE-KA SOOMAALIYA
      </Animated.Text>

      {/* Progress bar */}
      <View style={styles.barTrack}>
        <Animated.View style={[styles.barFill, { width: progress }]} />
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  glow: {
    position: 'absolute', width: 280, height: 280, borderRadius: 140,
    backgroundColor: COLORS.primaryPale, top: '25%',
  },
  center: { alignItems: 'center', marginBottom: 16 },
  logoBox: {
    width: 96, height: 96, borderRadius: 30,
    backgroundColor: P, alignItems: 'center', justifyContent: 'center',
    marginBottom: 18,
    shadowColor: P, shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4, shadowRadius: 20, elevation: 12,
  },
  logoEmoji: { fontSize: 46 },
  title: { fontSize: 38, fontWeight: '900', color: COLORS.text, letterSpacing: -1 },
  titleOrange: { color: P },
  tag: { color: COLORS.text3, fontSize: 11, letterSpacing: 3, marginTop: 8, marginBottom: 50 },
  barTrack: { width: W * 0.55, height: 4, backgroundColor: COLORS.border, borderRadius: 2, overflow: 'hidden' },
  barFill: { height: 4, backgroundColor: P, borderRadius: 2 },
});
