import React, { useEffect, useState } from 'react';
import {
  View, Text, ScrollView, FlatList, TouchableOpacity, StyleSheet,
  ActivityIndicator, Linking, Alert,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { useToast } from '../components/Toast';

const ORANGE = '#FF6B00';

export default function StoreDetailScreen({ route, navigation }) {
  const { store } = route.params;
  const { profile } = useAuth();
  const { theme } = useTheme();
  const showToast = useToast();
  const [products, setProducts] = useState([]);
  const [followed, setFollowed] = useState(false);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('products');

  useEffect(() => { loadData(); }, []);

  async function loadData() {
    setLoading(true);
    const [prodsRes, followRes] = await Promise.all([
      supabase.from('products').select('*').eq('storeId', store.id).order('created_at', { ascending: false }),
      profile?.email
        ? supabase.from('follows').select('id').eq('user_email', profile.email).eq('seller_email', store.sellerEmail).maybeSingle()
        : Promise.resolve({ data: null }),
    ]);
    setProducts(prodsRes.data || []);
    setFollowed(!!followRes.data);
    setLoading(false);
  }

  async function toggleFollow() {
    if (!profile?.email) return;
    if (followed) {
      await supabase.from('follows').delete().eq('user_email', profile.email).eq('seller_email', store.sellerEmail);
      setFollowed(false);
    } else {
      await supabase.from('follows').upsert({ user_email: profile.email, seller_email: store.sellerEmail });
      setFollowed(true);
    }
  }

  function openChat() {
    if (!profile?.email) return;
    const chatId = [profile.email.toLowerCase(), store.sellerEmail.toLowerCase()].sort().join('__');
    navigation.navigate('ChatRoom', {
      chat: { id: chatId, participantEmails: [profile.email, store.sellerEmail] },
      otherName: store.sellerName || store.name,
      otherEmail: store.sellerEmail,
    });
  }

  function openWA() {
    const num = store.whatsapp || store.phone;
    if (!num) { showToast('Ganacsadahan WhatsApp lambar ma laha', 'error'); return; }
    const clean = num.replace(/\D/g, '');
    const url = `whatsapp://send?phone=${clean}&text=Salaan%2C%20alaabyadaaga%20ayaan%20weydiiyay`;
    Linking.openURL(url).catch(() => showToast('WhatsApp lama furi karin', 'error'));
  }

  function openPhone() {
    const num = store.phone || store.sellerPhone;
    if (!num) { showToast('Ganacsadahan lambarka telefoonka ma laha', 'error'); return; }
    Linking.openURL(`tel:${num}`).catch(() => showToast('Telefoon lama furi karin', 'error'));
  }

  return (
    <View style={styles.wrap}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Text style={styles.backTxt}>←</Text>
        </TouchableOpacity>
        <View style={styles.storeEmoji}><Text style={{ fontSize: 32 }}>{store.emoji || '🏪'}</Text></View>
        <View style={{ flex: 1 }}>
          <Text style={styles.storeName}>{store.name}{store.verified ? ' ✓' : ''}</Text>
          <Text style={styles.storeMeta}>⭐ {store.rating || 5} · 👥 {(store.followers || 0).toLocaleString()}</Text>
        </View>
      </View>

      {/* Desc + Actions */}
      <View style={styles.actionsWrap}>
        {store.store_desc || store.desc ? (
          <Text style={styles.storeDesc}>{store.store_desc || store.desc}</Text>
        ) : null}
        <View style={styles.actionRow}>
          <TouchableOpacity style={[styles.followBtn, followed && styles.followedBtn]} onPress={toggleFollow}>
            <Text style={styles.followTxt}>{followed ? '✓ Following' : '+ Follow'}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.chatBtn} onPress={openChat}>
            <Text style={styles.chatTxt}>💬 Xariir</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.waBtn} onPress={openWA}>
            <Text style={{ fontSize: 20 }}>📲</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.phoneBtn} onPress={openPhone}>
            <Text style={{ fontSize: 20 }}>📞</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Tabs */}
      <View style={styles.tabs}>
        {[{ key: 'products', label: '🛍️ Alaabta' }, { key: 'info', label: 'ℹ️ Macluumaad' }].map(({ key, label }) => (
          <TouchableOpacity key={key} style={[styles.tab, tab === key && styles.tabOn]} onPress={() => setTab(key)}>
            <Text style={[styles.tabTxt, tab === key && styles.tabTxtOn]}>{label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      {loading ? <ActivityIndicator color={ORANGE} style={{ marginTop: 40 }} /> : (
        <ScrollView contentContainerStyle={{ padding: 14 }}>
          {tab === 'products' && (
            products.length === 0
              ? <Text style={styles.empty}>Alaab ma gelisid weli 🛍️</Text>
              : (
                <View style={styles.grid}>
                  {products.map((p, i) => (
                    <TouchableOpacity key={p.id} style={styles.prodCard} onPress={() => navigation.navigate('ProductDetail', { product: p })}>
                      <View style={styles.prodImg}><Text style={{ fontSize: 36 }}>{p.emoji || '📦'}</Text></View>
                      <Text style={styles.prodName} numberOfLines={2}>{p.name}</Text>
                      <Text style={styles.prodPrice}>Sh.So {(p.price || 0).toLocaleString()}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              )
          )}
          {tab === 'info' && (
            <View style={styles.infoBlock}>
              <Row label="Magaca Dukaanka" val={store.name} />
              <Row label="Ganacsadaha" val={store.sellerName} />
              <Row label="Email" val={store.sellerEmail} />
              <Row label="Qiimaha" val={`⭐ ${store.rating || 5}`} />
              <Row label="Raaciyayaasha" val={(store.followers || 0).toLocaleString()} />
              {store.verified && <Row label="Xaaladda" val="✓ La Xaqiijiyay" />}
            </View>
          )}
        </ScrollView>
      )}
    </View>
  );
}

function Row({ label, val }) {
  return (
    <View style={rowStyles.row}>
      <Text style={rowStyles.label}>{label}</Text>
      <Text style={rowStyles.val}>{val}</Text>
    </View>
  );
}
const rowStyles = StyleSheet.create({
  row: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  label: { color: '#888', fontSize: 13 },
  val: { fontWeight: '600', color: '#222', fontSize: 13 },
});

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#f5f7fa' },
  header: { flexDirection: 'row', alignItems: 'center', padding: 14, paddingTop: 52, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#f0f0f0', gap: 10 },
  backBtn: { padding: 4 },
  backTxt: { fontSize: 22, color: ORANGE },
  storeEmoji: { width: 52, height: 52, borderRadius: 14, backgroundColor: '#f8f8f8', alignItems: 'center', justifyContent: 'center' },
  storeName: { fontWeight: '800', fontSize: 16, color: '#111', marginBottom: 2 },
  storeMeta: { color: '#888', fontSize: 12 },
  actionsWrap: { backgroundColor: '#fff', padding: 14, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  storeDesc: { color: '#555', fontSize: 13, marginBottom: 12, lineHeight: 18 },
  actionRow: { flexDirection: 'row', gap: 10 },
  followBtn: { flex: 1, backgroundColor: ORANGE, padding: 12, borderRadius: 12, alignItems: 'center' },
  followedBtn: { backgroundColor: '#22c55e' },
  followTxt: { color: '#fff', fontWeight: '700' },
  chatBtn: { flex: 1, backgroundColor: '#f0f0f0', padding: 12, borderRadius: 12, alignItems: 'center' },
  chatTxt: { fontWeight: '700', color: '#333' },
  waBtn: { backgroundColor: '#25D366', width: 46, height: 46, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  phoneBtn: { backgroundColor: '#3b82f6', width: 46, height: 46, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  tabs: { flexDirection: 'row', backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  tab: { flex: 1, padding: 14, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabOn: { borderBottomColor: ORANGE },
  tabTxt: { fontWeight: '600', color: '#888', fontSize: 13 },
  tabTxtOn: { color: ORANGE },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  prodCard: { width: '47%', backgroundColor: '#fff', borderRadius: 12, overflow: 'hidden', shadowColor: '#000', shadowOpacity: 0.05, shadowRadius: 4, elevation: 1 },
  prodImg: { height: 110, backgroundColor: '#f8f8f8', alignItems: 'center', justifyContent: 'center' },
  prodName: { fontWeight: '700', fontSize: 12, color: '#111', padding: 8, paddingBottom: 2 },
  prodPrice: { color: ORANGE, fontWeight: '600', fontSize: 12, paddingHorizontal: 8, paddingBottom: 10 },
  empty: { textAlign: 'center', color: '#aaa', marginTop: 60, fontSize: 15 },
  infoBlock: { backgroundColor: '#fff', borderRadius: 14, padding: 14 },
});
