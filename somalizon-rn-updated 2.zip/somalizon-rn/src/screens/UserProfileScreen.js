import React, { useEffect, useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Image, ActivityIndicator } from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { COLORS, SHADOWS, R } from '../constants/Design';
import { PrimaryBtn, GhostBtn } from '../components/Buttons';

const P = COLORS.primary;

export default function UserProfileScreen({ route, navigation }) {
  const { email, name } = route.params;
  const { profile }     = useAuth();
  const [userProf, setUserProf] = useState(null);
  const [videos, setVideos]     = useState([]);
  const [followed, setFollowed] = useState(false);
  const [loading, setLoading]   = useState(true);

  useEffect(() => { loadData(); }, [email]);

  async function loadData() {
    setLoading(true);
    const [profRes, followRes, videosRes] = await Promise.all([
      supabase.from('profiles').select('*').eq('email', email).maybeSingle(),
      profile?.email ? supabase.from('follows').select('id').eq('user_email', profile.email).eq('seller_email', email).maybeSingle() : Promise.resolve({ data: null }),
      supabase.from('videos').select('*').eq('userEmail', email).order('created_at', { ascending: false }).limit(6),
    ]);
    setUserProf(profRes.data);
    setFollowed(!!followRes.data);
    setVideos(videosRes.data || []);
    setLoading(false);
  }

  async function toggleFollow() {
    if (!profile?.email) return;
    if (followed) {
      await supabase.from('follows').delete().eq('user_email', profile.email).eq('seller_email', email);
      setFollowed(false);
    } else {
      await supabase.from('follows').upsert({ user_email: profile.email, seller_email: email });
      setFollowed(true);
    }
  }

  function openChat() {
    if (!profile?.email) return;
    const chatId = [profile.email.toLowerCase(), email.toLowerCase()].sort().join('__');
    navigation.navigate('ChatRoom', { chat: { id: chatId, participantEmails: [profile.email, email] }, otherName: displayName, otherEmail: email });
  }

  if (loading) return <View style={styles.center}><ActivityIndicator color={P} size="large" /></View>;

  const displayName = userProf?.name || name || email.split('@')[0];
  const isSeller    = userProf?.user_type === 'seller';
  const isMe        = profile?.email?.toLowerCase() === email.toLowerCase();

  return (
    <ScrollView style={styles.wrap} showsVerticalScrollIndicator={false}>
      {/* Orange header */}
      <View style={styles.headerBand}>
        <View style={styles.waveBg} />
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Text style={styles.backTxt}>←</Text>
        </TouchableOpacity>
        {userProf?.profile_image
          ? <Image source={{ uri: userProf.profile_image }} style={styles.avatar} />
          : <View style={styles.avatarDefault}><Text style={styles.avatarTxt}>{displayName[0]?.toUpperCase() || '?'}</Text></View>
        }
        <Text style={styles.userName}>{displayName}</Text>
        {isSeller && userProf?.shop_name && <Text style={styles.shopName}>🏪 {userProf.shop_name}</Text>}
        <Text style={styles.userEmail}>{email}</Text>
        <View style={[styles.typeBadge, { backgroundColor: isSeller ? 'rgba(255,255,255,0.25)' : 'rgba(255,255,255,0.15)' }]}>
          <Text style={styles.typeTxt}>{isSeller ? '🏪 Ganacsade' : '🛍️ Macmiil'}</Text>
        </View>
      </View>

      {/* Action buttons */}
      {!isMe && (
        <View style={styles.actionRow}>
          <TouchableOpacity style={[styles.followBtn, followed && styles.followedBtn, SHADOWS.orange]} onPress={toggleFollow}>
            <Text style={styles.followTxt}>{followed ? '✓ Following' : '+ Follow'}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.msgBtn, SHADOWS.sm]} onPress={openChat}>
            <Text style={styles.msgTxt}>💬 Xariir</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Videos grid */}
      {videos.length > 0 && (
        <View style={styles.section}>
          <View style={styles.secHeader}>
            <Text style={styles.secTitle}>🎬 Videohiisa ({videos.length})</Text>
          </View>
          <View style={styles.videosGrid}>
            {videos.map((v, i) => (
              <TouchableOpacity
                key={v.id} style={styles.videoThumb}
                onPress={() => navigation.navigate('ProfileVideoViewer', { userEmail: email, userName: displayName, startIndex: i })}
              >
                <View style={styles.videoPlaceholder}>
                  <Text style={{ fontSize: 28 }}>▶️</Text>
                </View>
                <Text style={styles.videoDesc} numberOfLines={1}>{v.desc}</Text>
                <Text style={styles.videoMeta}>❤️ {v.likes || 0} · 💬 {v.comments || 0}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>
      )}

      {/* Info */}
      <View style={styles.section}>
        <Text style={styles.secTitle}>ℹ️ Macluumaad</Text>
        {[
          ['Nooca', isSeller ? '🏪 Ganacsade' : '🛍️ Macmiil'],
          isSeller && userProf?.shop_name ? ['Dukaanka', userProf.shop_name] : null,
        ].filter(Boolean).map(([label, val]) => (
          <View key={label} style={styles.infoRow}>
            <Text style={styles.infoLabel}>{label}</Text>
            <Text style={styles.infoVal}>{val}</Text>
          </View>
        ))}
      </View>
      <View style={{ height: 24 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff' },
  headerBand: { backgroundColor: P, paddingTop: 54, paddingBottom: 28, alignItems: 'center', borderBottomLeftRadius: 32, borderBottomRightRadius: 32, overflow: 'hidden', marginBottom: 16 },
  waveBg: { position: 'absolute', width: 320, height: 320, borderRadius: 160, backgroundColor: 'rgba(255,255,255,0.08)', top: -80, right: -40 },
  backBtn: { position: 'absolute', top: 54, left: 16, width: 38, height: 38, borderRadius: 13, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  backTxt: { color: '#fff', fontSize: 22, fontWeight: '700', lineHeight: 26 },
  avatar: { width: 88, height: 88, borderRadius: 28, marginBottom: 12, borderWidth: 3, borderColor: 'rgba(255,255,255,0.4)' },
  avatarDefault: { width: 88, height: 88, borderRadius: 28, backgroundColor: 'rgba(255,255,255,0.25)', alignItems: 'center', justifyContent: 'center', marginBottom: 12, borderWidth: 3, borderColor: 'rgba(255,255,255,0.4)' },
  avatarTxt: { color: '#fff', fontSize: 36, fontWeight: '900' },
  userName: { fontSize: 22, fontWeight: '900', color: '#fff', letterSpacing: -0.3, marginBottom: 4 },
  shopName: { color: 'rgba(255,255,255,0.8)', fontSize: 13, marginBottom: 4 },
  userEmail: { color: 'rgba(255,255,255,0.65)', fontSize: 12, marginBottom: 10 },
  typeBadge: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: R.full },
  typeTxt: { color: '#fff', fontWeight: '700', fontSize: 13 },
  actionRow: { flexDirection: 'row', gap: 12, paddingHorizontal: 16, marginBottom: 16 },
  followBtn: { flex: 1, backgroundColor: P, padding: 14, borderRadius: R.xl, alignItems: 'center' },
  followedBtn: { backgroundColor: COLORS.success },
  followTxt: { color: '#fff', fontWeight: '800', fontSize: 14 },
  msgBtn: { flex: 1, backgroundColor: '#fff', padding: 14, borderRadius: R.xl, alignItems: 'center' },
  msgTxt: { fontWeight: '700', color: COLORS.text, fontSize: 14 },
  section: { backgroundColor: '#fff', marginHorizontal: 16, borderRadius: R.xl, padding: 16, marginBottom: 12, ...SHADOWS.card },
  secHeader: { marginBottom: 12 },
  secTitle: { fontWeight: '800', fontSize: 15, color: COLORS.text },
  videosGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  videoThumb: { width: (COLORS.card ? 100 : 100), flex: 1, minWidth: '30%' },
  videoPlaceholder: { height: 90, backgroundColor: COLORS.primaryPale, borderRadius: R.lg, alignItems: 'center', justifyContent: 'center', marginBottom: 5 },
  videoDesc: { fontSize: 11, color: COLORS.text2, fontWeight: '600', marginBottom: 2 },
  videoMeta: { fontSize: 10, color: COLORS.text3 },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10, borderTopWidth: 1, borderTopColor: COLORS.border },
  infoLabel: { color: COLORS.text2, fontSize: 13 },
  infoVal: { fontWeight: '700', color: COLORS.text, fontSize: 13 },
});
