import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { useRealtime } from '../contexts/RealtimeContext';
import { COLORS, SHADOWS, R } from '../constants/Design';

import HomeScreen      from '../screens/HomeScreen';
import ShopsScreen     from '../screens/ShopsScreen';
import WatchScreen     from '../screens/WatchScreen';
import XariirScreen    from '../screens/XariirScreen';
import ProfileScreen   from '../screens/ProfileScreen';
import DashboardScreen from '../screens/DashboardScreen';

const Tab = createBottomTabNavigator();
const P = COLORS.primary;

const TAB_ICONS = {
  Home:      { active: '🏠', label: 'Guriga' },
  Shops:     { active: '🏪', label: 'Dukaannada' },
  Watch:     { active: '🎬', label: 'Daawasho' },
  Xariir:    { active: '💬', label: 'Xariir' },
  Profile:   { active: '👤', label: 'Profile' },
  Dashboard: { active: '📊', label: 'Dashboard' },
};

function TabBar({ state, descriptors, navigation }) {
  return (
    <View style={styles.tabBar}>
      {state.routes.map((route, index) => {
        const { options } = descriptors[route.key];
        const isFocused = state.index === index;
        const icon = TAB_ICONS[route.name];
        const badge = options.tabBarBadge;

        return (
          <TouchableOpacity
            key={route.key}
            style={styles.tabItem}
            onPress={() => { if (!isFocused) navigation.navigate(route.name); }}
            activeOpacity={0.7}
          >
            <View style={[styles.tabIconWrap, isFocused && styles.tabIconWrapActive]}>
              <Text style={[styles.tabIcon, isFocused && styles.tabIconActive]}>
                {icon?.active || '●'}
              </Text>
              {badge > 0 && (
                <View style={styles.badge}>
                  <Text style={styles.badgeTxt}>{badge > 99 ? '99+' : badge}</Text>
                </View>
              )}
            </View>
            <Text style={[styles.tabLabel, isFocused && styles.tabLabelActive]}>
              {icon?.label || route.name}
            </Text>
          </TouchableOpacity>
        );
      })}
    </View>
  );
}

export default function MainTabs() {
  const { profile } = useAuth();
  const { totalQty } = useCart();
  const { chatUnread } = useRealtime();
  const isSeller = profile?.user_type === 'seller';

  return (
    <Tab.Navigator
      tabBar={props => <TabBar {...props} />}
      screenOptions={{ headerShown: false }}
    >
      <Tab.Screen name="Home"   component={HomeScreen}   options={{ tabBarBadge: totalQty > 0 ? totalQty : 0 }} />
      <Tab.Screen name="Shops"  component={ShopsScreen}  options={{ tabBarBadge: 0 }} />
      <Tab.Screen name="Watch"  component={WatchScreen}  options={{ tabBarBadge: 0 }} />
      <Tab.Screen name="Xariir" component={XariirScreen} options={{ tabBarBadge: chatUnread > 0 ? chatUnread : 0 }} />
      {isSeller
        ? <Tab.Screen name="Dashboard" component={DashboardScreen} options={{ tabBarBadge: 0 }} />
        : <Tab.Screen name="Profile"   component={ProfileScreen}   options={{ tabBarBadge: 0 }} />
      }
    </Tab.Navigator>
  );
}

const styles = StyleSheet.create({
  tabBar: {
    flexDirection: 'row', backgroundColor: '#fff', paddingBottom: 24, paddingTop: 10,
    borderTopWidth: 1, borderTopColor: COLORS.border,
    shadowColor: '#000', shadowOffset: { width: 0, height: -3 },
    shadowOpacity: 0.06, shadowRadius: 12, elevation: 12,
  },
  tabItem: { flex: 1, alignItems: 'center', gap: 4 },
  tabIconWrap: { width: 46, height: 30, alignItems: 'center', justifyContent: 'center', borderRadius: R.full, position: 'relative' },
  tabIconWrapActive: { backgroundColor: COLORS.primaryPale },
  tabIcon: { fontSize: 20 },
  tabIconActive: { },
  tabLabel: { fontSize: 10, fontWeight: '600', color: COLORS.text3 },
  tabLabelActive: { color: P, fontWeight: '800' },
  badge: {
    position: 'absolute', top: -4, right: -4,
    backgroundColor: COLORS.error, borderRadius: R.full,
    minWidth: 16, height: 16, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 3, borderWidth: 1.5, borderColor: '#fff',
  },
  badgeTxt: { color: '#fff', fontSize: 8, fontWeight: '900' },
});
