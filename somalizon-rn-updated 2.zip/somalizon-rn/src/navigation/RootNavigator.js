import React, { useEffect, useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../contexts/AuthContext';
import { navigationRef } from './navigationRef';

// Auth
import SplashScreen     from '../screens/SplashScreen';
import LoginScreen      from '../screens/LoginScreen';
import SignupScreen     from '../screens/SignupScreen';
import OnboardingScreen from '../screens/OnboardingScreen';

// Main
import MainTabs                from './MainTabs';
import ProfileScreen           from '../screens/ProfileScreen';
import DashboardScreen         from '../screens/DashboardScreen';

// Products
import ProductDetailScreen     from '../screens/ProductDetailScreen';
import AddProductScreen        from '../screens/AddProductScreen';
import EditProductScreen       from '../screens/EditProductScreen';

// Stores
import StoreDetailScreen       from '../screens/StoreDetailScreen';

// Chat & Calls
import ChatRoomScreen          from '../screens/ChatRoomScreen';
import CallScreen              from '../screens/CallScreen';

// Social
import UserProfileScreen       from '../screens/UserProfileScreen';
import AsxaabtaScreen          from '../screens/AsxaabtaScreen';
import ReviewsPageScreen       from '../screens/ReviewsPageScreen';
import WishlistScreen          from '../screens/WishlistScreen';

// Watch
import UploadVideoScreen       from '../screens/UploadVideoScreen';
import VideoManagerScreen      from '../screens/VideoManagerScreen';
import CommentsScreen          from '../screens/CommentsScreen';
import WatchSearchScreen       from '../screens/WatchSearchScreen';
import ProfileVideoViewerScreen from '../screens/ProfileVideoViewerScreen';

// Orders & Cart
import CartScreen              from '../screens/CartScreen';
import OrdersHistoryScreen     from '../screens/OrdersHistoryScreen';

// Utils
import NotificationsScreen     from '../screens/NotificationsScreen';
import SettingsScreen          from '../screens/SettingsScreen';
import SearchScreen            from '../screens/SearchScreen';

const Stack = createNativeStackNavigator();
const NO_HEADER = { headerShown: false };
const SLIDE = { headerShown: false, animation: 'slide_from_right' };
const FADE = { headerShown: false, animation: 'fade' };

export default function RootNavigator() {
  const { session, loading } = useAuth();
  const [showSplash, setShowSplash] = useState(true);
  const [onboarded, setOnboarded] = useState(null);

  useEffect(() => {
    AsyncStorage.getItem('onboarded').then(v => setOnboarded(v === '1'));
  }, []);

  if (loading || onboarded === null) return null;
  if (showSplash) return <SplashScreen onDone={() => setShowSplash(false)} />;

  return (
    <NavigationContainer ref={navigationRef}>
      <Stack.Navigator screenOptions={NO_HEADER}>

        {/* ── Onboarding (first launch) ── */}
        {!onboarded && (
          <Stack.Screen name="Onboarding" options={FADE}>
            {() => <OnboardingScreen onDone={() => setOnboarded(true)} />}
          </Stack.Screen>
        )}

        {/* ── Auth flow ── */}
        {!session ? (
          <>
            <Stack.Screen name="Login"  component={LoginScreen}  options={FADE} />
            <Stack.Screen name="Signup" component={SignupScreen} options={SLIDE} />
          </>
        ) : (
          <>
            {/* ── Main tabs ── */}
            <Stack.Screen name="MainTabs"  component={MainTabs}       options={NO_HEADER} />
            <Stack.Screen name="Profile"   component={ProfileScreen}  options={SLIDE} />
            <Stack.Screen name="Dashboard" component={DashboardScreen} options={SLIDE} />

            {/* ── Products ── */}
            <Stack.Screen name="ProductDetail" component={ProductDetailScreen} options={SLIDE} />
            <Stack.Screen name="AddProduct"    component={AddProductScreen}    options={SLIDE} />
            <Stack.Screen name="EditProduct"   component={EditProductScreen}   options={SLIDE} />

            {/* ── Stores ── */}
            <Stack.Screen name="StoreDetail" component={StoreDetailScreen} options={SLIDE} />

            {/* ── Chat & Calls ── */}
            <Stack.Screen name="ChatRoom" component={ChatRoomScreen} options={SLIDE} />
            <Stack.Screen name="Call"     component={CallScreen}     options={FADE}  />

            {/* ── Social ── */}
            <Stack.Screen name="UserProfile"  component={UserProfileScreen}  options={SLIDE} />
            <Stack.Screen name="Asxaabta"     component={AsxaabtaScreen}     options={SLIDE} />
            <Stack.Screen name="ReviewsPage"  component={ReviewsPageScreen}  options={SLIDE} />
            <Stack.Screen name="Wishlist"     component={WishlistScreen}     options={SLIDE} />

            {/* ── Watch ── */}
            <Stack.Screen name="UploadVideo"         component={UploadVideoScreen}        options={SLIDE} />
            <Stack.Screen name="VideoManager"        component={VideoManagerScreen}       options={SLIDE} />
            <Stack.Screen name="Comments"            component={CommentsScreen}           options={SLIDE} />
            <Stack.Screen name="WatchSearch"         component={WatchSearchScreen}        options={FADE}  />
            <Stack.Screen name="ProfileVideoViewer"  component={ProfileVideoViewerScreen} options={FADE}  />

            {/* ── Orders & Cart ── */}
            <Stack.Screen name="Cart"          component={CartScreen}          options={SLIDE} />
            <Stack.Screen name="OrdersHistory" component={OrdersHistoryScreen} options={SLIDE} />

            {/* ── Utils ── */}
            <Stack.Screen name="Notifications" component={NotificationsScreen} options={SLIDE} />
            <Stack.Screen name="Settings"      component={SettingsScreen}      options={SLIDE} />
            <Stack.Screen name="Search"        component={SearchScreen}        options={FADE}  />
          </>
        )}
      </Stack.Navigator>
    </NavigationContainer>
  );
}
