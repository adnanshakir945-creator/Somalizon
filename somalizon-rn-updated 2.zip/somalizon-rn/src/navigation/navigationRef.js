import { createNavigationContainerRef } from '@react-navigation/native';

// Lets code outside the navigator (e.g. RealtimeContext, listening for incoming
// calls) trigger navigation — RootNavigator attaches this ref to its
// NavigationContainer.
export const navigationRef = createNavigationContainerRef();

export function navigate(name, params) {
  if (navigationRef.isReady()) {
    navigationRef.navigate(name, params);
  }
}
