import React, { createContext, useContext, useState } from 'react';

const CartContext = createContext(null);

export function CartProvider({ children }) {
  const [cart, setCart] = useState([]);

  function addToCart(prod) {
    setCart(prev => {
      const exists = prev.find(c => c.id === prod.id);
      if (exists) return prev.map(c => c.id === prod.id ? { ...c, qty: c.qty + 1 } : c);
      return [...prev, { ...prod, qty: 1 }];
    });
  }

  function removeFromCart(prodId) {
    setCart(prev => prev.filter(c => c.id !== prodId));
  }

  function changeQty(prodId, delta) {
    setCart(prev => prev
      .map(c => c.id === prodId ? { ...c, qty: c.qty + delta } : c)
      .filter(c => c.qty > 0)
    );
  }

  function clearCart() { setCart([]); }

  const totalQty = cart.reduce((a, c) => a + c.qty, 0);
  const totalPrice = cart.reduce((a, c) => a + (c.price * c.qty), 0);

  return (
    <CartContext.Provider value={{ cart, addToCart, removeFromCart, changeQty, clearCart, totalQty, totalPrice }}>
      {children}
    </CartContext.Provider>
  );
}

export const useCart = () => useContext(CartContext);
