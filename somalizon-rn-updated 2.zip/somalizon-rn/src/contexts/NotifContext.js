import React, { createContext, useContext, useEffect, useState } from 'react';
import { Platform } from 'react-native';
import * as Notifications from 'expo-notifications';
import Constants from 'expo-constants';
import { supabase } from '../lib/supabase';

const NotifContext = createContext(null);

// Foreground notifications should still show a banner/sound while the app is open.
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

export function NotifProvider({ children }) {
  const [notifs, setNotifs] = useState([]);
  const [unread, setUnread] = useState(0);

  async function loadNotifs(uid) {
    if (!uid) return;
    const { data } = await supabase.from('notifications').select('*').eq('toUid', uid).order('created_at', { ascending: false }).limit(50);
    setNotifs(data || []);
    setUnread((data || []).filter(n => !n.read).length);
  }

  function subscribeNotifs(uid) {
    if (!uid) return null;
    return supabase.channel('notifs-' + uid)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: 'toUid=eq.' + uid }, () => loadNotifs(uid))
      .subscribe();
  }

  async function markRead(notifId, uid) {
    await supabase.from('notifications').update({ read: true }).eq('id', notifId);
    await loadNotifs(uid);
  }

  async function markAll(uid) {
    await supabase.from('notifications').update({ read: true }).eq('toUid', uid).eq('read', false);
    await loadNotifs(uid);
  }

  // Ask for permission, grab an Expo push token, and save it on the profile row
  // so a server-side function (e.g. a Supabase Edge Function) can send that user
  // a real push notification later (new order, new message, etc).
  // NOTE: this needs a real device + a development/production build — it will
  // silently no-op on web and won't return a usable token inside Expo Go.
  async function registerForPush(uid) {
    if (!uid || Platform.OS === 'web') return null;
    try {
      const { status: existing } = await Notifications.getPermissionsAsync();
      let status = existing;
      if (status !== 'granted') {
        const req = await Notifications.requestPermissionsAsync();
        status = req.status;
      }
      if (status !== 'granted') return null;

      if (Platform.OS === 'android') {
        await Notifications.setNotificationChannelAsync('default', {
          name: 'default',
          importance: Notifications.AndroidImportance.DEFAULT,
        });
      }

      const projectId = Constants.expoConfig?.extra?.eas?.projectId;
      const tokenResp = await Notifications.getExpoPushTokenAsync(projectId ? { projectId } : undefined);
      const token = tokenResp?.data;
      if (token) {
        await supabase.from('profiles').update({ push_token: token }).eq('id', uid);
      }
      return token || null;
    } catch (e) {
      console.log('⚠️ Push registration failed:', e?.message || e);
      return null;
    }
  }

  return (
    <NotifContext.Provider value={{ notifs, unread, loadNotifs, subscribeNotifs, markRead, markAll, registerForPush }}>
      {children}
    </NotifContext.Provider>
  );
}

export const useNotifs = () => useContext(NotifContext);
