import React, { createContext, useContext, useState } from 'react';
import { COLORS } from '../constants/Design';

const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const [isDark, setIsDark] = useState(false); // Default: WHITE
  const theme = COLORS.light; // Always orange & white
  return (
    <ThemeContext.Provider value={{ isDark, toggleDark: () => setIsDark(d => !d), theme, C: COLORS }}>
      {children}
    </ThemeContext.Provider>
  );
}

export const useTheme = () => useContext(ThemeContext);
