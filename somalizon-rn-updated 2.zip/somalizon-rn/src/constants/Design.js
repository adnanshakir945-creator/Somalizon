export const COLORS = {
  primary: '#FF6B00',
  primaryLight: '#FF8533',
  primaryDark: '#E55A00',
  primaryPale: '#FFF0E6',

  white: '#FFFFFF',
  bg: '#F5F5F5',       // Gray-cad nadiif ah
  surface: '#FFFFFF',
  card: '#FFFFFF',
  cardAlt: '#FFF6F0',  // Card orange-tinted

  text: '#111111',     // Madow cad
  text2: '#666666',
  text3: '#AAAAAA',
  border: '#EEEEEE',
  input: '#F8F8F8',
  inputBorder: '#E8E8E8',

  success: '#00A86B',
  error: '#E53935',
  warn: '#F59E0B',

  // Used by screens via theme
  dark: {
    bg: '#F5F5F5', surface: '#FFFFFF', card: '#FFFFFF', cardElevated: '#FFF6F0',
    border: '#EEEEEE', text: '#111111', text2: '#666666', text3: '#AAAAAA',
    input: '#F8F8F8', inputBorder: '#E8E8E8', tabBar: '#FFFFFF',
    success: '#00A86B', error: '#E53935',
  },
  light: {
    bg: '#F5F5F5', surface: '#FFFFFF', card: '#FFFFFF', cardElevated: '#FFF6F0',
    border: '#EEEEEE', text: '#111111', text2: '#666666', text3: '#AAAAAA',
    input: '#F8F8F8', inputBorder: '#E8E8E8', tabBar: '#FFFFFF',
    success: '#00A86B', error: '#E53935',
  },
};

export const SHADOWS = {
  card: { shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 10, elevation: 4 },
  orange: { shadowColor: '#FF6B00', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.4, shadowRadius: 12, elevation: 8 },
  sm: { shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 },
};

export const R = { xs: 6, sm: 8, md: 12, lg: 16, xl: 20, xxl: 28, full: 999 };
