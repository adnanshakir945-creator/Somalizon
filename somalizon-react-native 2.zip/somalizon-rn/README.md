# 🛍️ Somalizon — React Native (Expo)

## Qaabka Mashruuca
```
somalizon-rn/
├── App.js
├── app.json
├── package.json
├── src/
│   ├── constants/
│   │   └── Design.js          ← Colors, Shadows, Border Radius
│   ├── contexts/
│   │   ├── AuthContext.js     ← Login/session
│   │   ├── CartContext.js     ← Global cart state
│   │   ├── NotifContext.js    ← Notifications
│   │   ├── RealtimeContext.js ← Real-time sync (products/stores/chat/orders)
│   │   └── ThemeContext.js    ← Orange+White theme
│   ├── components/
│   │   ├── AppHeader.js       ← Shared header
│   │   ├── Buttons.js         ← PrimaryBtn, SecondaryBtn, GhostBtn
│   │   ├── ImageViewer.js     ← Full-screen image
│   │   ├── LocationModal.js   ← Address picker modal
│   │   └── Toast.js           ← Global toast
│   ├── navigation/
│   │   ├── RootNavigator.js   ← All 30 screens registered
│   │   └── MainTabs.js        ← Custom orange tab bar
│   └── screens/ (30 screens)
│       ├── SplashScreen.js
│       ├── OnboardingScreen.js
│       ├── LoginScreen.js
│       ├── SignupScreen.js
│       ├── HomeScreen.js
│       ├── ShopsScreen.js
│       ├── WatchScreen.js
│       ├── XariirScreen.js
│       ├── ProfileScreen.js
│       ├── DashboardScreen.js
│       ├── ProductDetailScreen.js
│       ├── StoreDetailScreen.js
│       ├── ChatRoomScreen.js
│       ├── CallScreen.js
│       ├── UserProfileScreen.js
│       ├── AsxaabtaScreen.js
│       ├── ReviewsPageScreen.js
│       ├── WishlistScreen.js
│       ├── AddProductScreen.js
│       ├── EditProductScreen.js
│       ├── VideoManagerScreen.js
│       ├── UploadVideoScreen.js
│       ├── CommentsScreen.js
│       ├── WatchSearchScreen.js
│       ├── ProfileVideoViewerScreen.js
│       ├── CartScreen.js
│       ├── OrdersHistoryScreen.js
│       ├── NotificationsScreen.js
│       ├── SettingsScreen.js
│       └── SearchScreen.js
```

## Bilowga

### 1. Geli Supabase Credentials
Fur `src/lib/supabase.js`:
```js
const SUPABASE_URL = 'https://YOUR-PROJECT.supabase.co';
const SUPABASE_ANON_KEY = 'YOUR-ANON-KEY';
```

### 2. Install
```bash
npm install
```

### 3. Bilow
```bash
npx expo start
```

## Design System
- **Primary:** `#FF6B00` (Orange)
- **Background:** `#F5F5F5` (Gray-cad)
- **Cards:** `#FFFFFF` (Pure White)
- **Text:** `#111111`
- **Theme:** Orange + White (always light)

## Supabase Tables
profiles, products, stores, orders, reviews, chats, messages,
follows, videos, video_interactions, comments, notifications, calls, call_candidates
