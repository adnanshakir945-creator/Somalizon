import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';

const RealtimeCtx = createContext(null);

export function RealtimeProvider({ children }) {
  const { profile } = useAuth();
  const [products, setProducts] = useState([]);
  const [stores, setStores] = useState([]);
  const [chatUnread, setChatUnread] = useState(0);
  const [newOrder, setNewOrder] = useState(null); // seller gets notified
  const channels = useRef([]);

  useEffect(() => {
    startProductSync();
    startStoreSync();
    if (profile?.email) {
      startChatSync(profile.email);
      if (profile.user_type === 'seller') startSellerOrderSync(profile.email);
    }
    return () => channels.current.forEach(c => supabase.removeChannel(c));
  }, [profile?.email]);

  // ─── Products real-time ─────────────────────────────────
  async function startProductSync() {
    const { data } = await supabase.from('products').select('*').order('created_at', { ascending: false });
    setProducts(data || []);

    const ch = supabase.channel('global-products')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'products' }, ({ new: row }) => {
        setProducts(prev => [row, ...prev]);
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'products' }, ({ new: row }) => {
        setProducts(prev => prev.map(p => p.id === row.id ? row : p));
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'products' }, ({ old: row }) => {
        setProducts(prev => prev.filter(p => p.id !== row.id));
      })
      .subscribe();
    channels.current.push(ch);
  }

  // ─── Stores real-time ────────────────────────────────────
  async function startStoreSync() {
    const { data } = await supabase.from('stores').select('*').order('followers', { ascending: false });
    setStores(data || []);

    const ch = supabase.channel('global-stores')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'stores' }, () => {
        supabase.from('stores').select('*').order('followers', { ascending: false })
          .then(({ data }) => setStores(data || []));
      })
      .subscribe();
    channels.current.push(ch);
  }

  // ─── Chat unread count real-time ────────────────────────
  function startChatSync(email) {
    const myEmail = email.toLowerCase().trim();
    const ch = supabase.channel('global-chats-' + myEmail)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'chats' }, ({ new: row }) => {
        const participants = row.participantEmails || [];
        if (!participants.includes(myEmail)) return;
        if (row.lastSenderEmail !== myEmail) {
          setChatUnread(prev => prev + 1);
        }
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, ({ new: row }) => {
        if (row.senderEmail !== myEmail) {
          setChatUnread(prev => prev + 1);
        }
      })
      .subscribe();
    channels.current.push(ch);
  }

  // ─── Seller order alerts real-time ──────────────────────
  function startSellerOrderSync(email) {
    const ch = supabase.channel('seller-orders-' + email)
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'orders',
        filter: `sellerEmail=eq.${email}`,
      }, ({ new: row }) => {
        setNewOrder(row);
      })
      .subscribe();
    channels.current.push(ch);
  }

  function clearChatUnread() { setChatUnread(0); }
  function clearNewOrder() { setNewOrder(null); }

  return (
    <RealtimeCtx.Provider value={{
      products, stores, chatUnread, newOrder,
      clearChatUnread, clearNewOrder,
    }}>
      {children}
    </RealtimeCtx.Provider>
  );
}

export const useRealtime = () => useContext(RealtimeCtx);
