import React, { createContext, useContext, useEffect, useState } from 'react';
import { supabase } from '../lib/supabase';

const NotifContext = createContext(null);

export function NotifProvider({ children }) {
  const [notifs, setNotifs] = useState([]);
  const [unread, setUnread] = useState(0);

  async function loadNotifs(uid) {
    if (!uid) return;
    const { data } = await supabase.from('notifications').select('*').eq('toUid', uid).order('created_at', { ascending: false }).limit(50);
    setNotifs(data || []);
    setUnread((data || []).filter(n => !n.read).length);
  }

  function subscribeNotifs(uid) {
    if (!uid) return null;
    return supabase.channel('notifs-' + uid)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'notifications', filter: 'toUid=eq.' + uid }, () => loadNotifs(uid))
      .subscribe();
  }

  async function markRead(notifId, uid) {
    await supabase.from('notifications').update({ read: true }).eq('id', notifId);
    await loadNotifs(uid);
  }

  async function markAll(uid) {
    await supabase.from('notifications').update({ read: true }).eq('toUid', uid).eq('read', false);
    await loadNotifs(uid);
  }

  return (
    <NotifContext.Provider value={{ notifs, unread, loadNotifs, subscribeNotifs, markRead, markAll }}>
      {children}
    </NotifContext.Provider>
  );
}

export const useNotifs = () => useContext(NotifContext);
