import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  ActivityIndicator, RefreshControl, Alert,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';

const ORANGE = '#FF6B00';

function timeFmt(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleDateString('so-SO') + ' ' + d.toLocaleTimeString('so-SO', { hour: '2-digit', minute: '2-digit' });
}

function statusColor(s) {
  if (s === 'La Dhiibay') return '#22c55e';
  if (s === 'La Diray') return ORANGE;
  if (s === 'La Joojiyay') return '#ef4444';
  return '#888';
}

export default function OrdersHistoryScreen({ navigation }) {
  const { profile } = useAuth();
  const { theme } = useTheme();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { loadOrders(); }, [profile]);

  async function loadOrders() {
    if (!profile?.email) { setLoading(false); return; }
    setLoading(true);
    const { data } = await supabase
      .from('orders')
      .select('*')
      .eq('buyerEmail', profile.email)
      .order('created_at', { ascending: false });
    setOrders(data || []);
    setLoading(false);
  }

  async function deleteOrder(orderId) {
    console.log('Tirtir Dalabka', 'Ma hubtaa inaad tirtireyso dalabkan?', [
      { text: 'Maya', style: 'cancel' },
      {
        text: 'Haa, Tirtir', style: 'destructive', onPress: async () => {
          const { error } = await supabase.from('orders').delete().eq('id', orderId);
          if (!error) setOrders(prev => prev.filter(o => o.id !== orderId));
          else console.log('⚠️ Khalad', error.message);
        }
      }
    ]);
  }

  function chatSeller(sellerName, sellerEmail) {
    if (!profile?.email || !sellerEmail) return;
    const chatId = [profile.email.toLowerCase(), sellerEmail.toLowerCase()].sort().join('__');
    navigation.navigate('ChatRoom', {
      chat: { id: chatId, participantEmails: [profile.email, sellerEmail] },
      otherName: sellerName || sellerEmail.split('@')[0],
      otherEmail: sellerEmail,
    });
  }

  const onRefresh = useCallback(async () => {
    setRefreshing(true); await loadOrders(); setRefreshing(false);
  }, [profile]);

  function renderOrder({ item: o }) {
    const color = statusColor(o.status);
    return (
      <View style={[styles.card, { backgroundColor: theme.card }]}>
        {/* Header */}
        <View style={styles.cardHeader}>
          <Text style={[styles.orderNum, { color: theme.text }]}>
            📋 Dalabka #{String(o.id).slice(-4).toUpperCase()}
          </Text>
          <View style={styles.headerRight}>
            <View style={[styles.statusBadge, { backgroundColor: color + '22' }]}>
              <Text style={[styles.statusTxt, { color }]}>{o.status || 'La Diray'}</Text>
            </View>
            <TouchableOpacity onPress={() => deleteOrder(o.id)} style={styles.deleteBtn}>
              <Text style={styles.deleteTxt}>🗑️</Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Product info */}
        <View style={styles.prodRow}>
          <Text style={styles.prodEmoji}>{o.prodEmoji || '📦'}</Text>
          <View style={{ flex: 1 }}>
            <Text style={[styles.prodName, { color: theme.text }]}>{o.prodName}</Text>
            <Text style={[styles.prodMeta, { color: theme.text2 }]}>Tirada: {o.qty} · Sh.So {(o.totalPrice || 0).toLocaleString()}</Text>
            <Text style={[styles.prodMeta, { color: theme.text2 }]}>👤 {o.sellerName || o.sellerEmail}</Text>
          </View>
        </View>

        {/* Delivery info */}
        <View style={[styles.deliveryBox, { backgroundColor: theme.bg }]}>
          <Text style={[styles.deliveryTxt, { color: theme.text2 }]}>📞 {o.phone}</Text>
          <Text style={[styles.deliveryTxt, { color: theme.text2 }]}>📍 {o.address}</Text>
          {o.payMethod && <Text style={[styles.deliveryTxt, { color: theme.text2 }]}>💳 {o.payMethod}</Text>}
        </View>

        {/* Footer */}
        <View style={styles.cardFooter}>
          <Text style={[styles.orderDate, { color: theme.text2 }]}>📅 {timeFmt(o.created_at)}</Text>
          <TouchableOpacity
            style={styles.chatBtn}
            onPress={() => chatSeller(o.sellerName, o.sellerEmail)}
          >
            <Text style={styles.chatBtnTxt}>💬 Xariir</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Text style={styles.back}>←</Text></TouchableOpacity>
        <Text style={[styles.title, { color: theme.text }]}>📦 Dalabaadayda ({orders.length})</Text>
        <View style={{ width: 30 }} />
      </View>

      {loading ? <ActivityIndicator color={ORANGE} style={{ marginTop: 40 }} /> : (
        <FlatList
          data={orders} keyExtractor={o => String(o.id)}
          contentContainerStyle={{ padding: 14 }}
          renderItem={renderOrder}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={ORANGE} />}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={{ fontSize: 52, marginBottom: 14 }}>📦</Text>
              <Text style={[styles.emptyTxt, { color: theme.text2 }]}>Wax dalabaad ah ma jiraan weli</Text>
              <TouchableOpacity style={styles.shopBtn} onPress={() => navigation.navigate('Home')}>
                <Text style={styles.shopBtnTxt}>🛍️ Alaab Raadi</Text>
              </TouchableOpacity>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52, borderBottomWidth: 1 },
  back: { fontSize: 24, color: ORANGE },
  title: { fontSize: 17, fontWeight: '700' },
  card: { borderRadius: 16, padding: 14, marginBottom: 12, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  orderNum: { fontWeight: '800', fontSize: 14 },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 },
  statusTxt: { fontSize: 12, fontWeight: '700' },
  deleteBtn: { padding: 4 },
  deleteTxt: { fontSize: 18 },
  prodRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 10 },
  prodEmoji: { fontSize: 36, width: 46, textAlign: 'center' },
  prodName: { fontWeight: '700', fontSize: 14, marginBottom: 3 },
  prodMeta: { fontSize: 12, marginBottom: 2 },
  deliveryBox: { borderRadius: 10, padding: 10, marginBottom: 10, gap: 3 },
  deliveryTxt: { fontSize: 12 },
  cardFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  orderDate: { fontSize: 12 },
  chatBtn: { backgroundColor: ORANGE, paddingHorizontal: 16, paddingVertical: 8, borderRadius: 10 },
  chatBtnTxt: { color: '#fff', fontWeight: '700', fontSize: 13 },
  empty: { alignItems: 'center', marginTop: 80 },
  emptyTxt: { fontSize: 15, marginBottom: 20 },
  shopBtn: { backgroundColor: ORANGE, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 14 },
  shopBtnTxt: { color: '#fff', fontWeight: '700' },
});
