import React, { useEffect, useState, useCallback, useRef } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Image,
  ActivityIndicator, RefreshControl, Alert, ScrollView, Dimensions, Animated } from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { useRealtime } from '../contexts/RealtimeContext';
import { COLORS, SHADOWS, R } from '../constants/Design';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width: W } = Dimensions.get('window');
const P = COLORS.primary;
const CARD_W = (W - 48) / 2;

const CATS = [
  { key: 'all',        label: 'Dhammaan',   emoji: '✨' },
  { key: 'dharka',     label: 'Dharka',     emoji: '👗' },
  { key: 'tignoolaji', label: 'Tiknoolaji', emoji: '📱' },
  { key: 'guriga',     label: 'Guriga',     emoji: '🏠' },
  { key: 'cuntada',    label: 'Cuntada',    emoji: '🍽️' },
  { key: 'baabuur',    label: 'Baabuur',    emoji: '🚗' },
  { key: 'beauty',     label: 'Beauty',     emoji: '💄' },
  { key: 'sports',     label: 'Sports',     emoji: '⚽' },
];

const BANNERS = [
  { id: '1', emoji: '🔥', title: 'Flash Sale!',   sub: 'Alaab kasta 20% discount', color: '#fff', bg: P },
  { id: '2', emoji: '🚀', title: 'Ganacsade Noqo', sub: 'Dukaan bilaash u fur',    color: P,    bg: COLORS.primaryPale },
  { id: '3', emoji: '💳', title: 'EVC & Zaad',     sub: 'Lacag bixin fudud & amaan', color: '#fff', bg: '#1565C0' },
];

export default function HomeScreen({ navigation }) {
  const { profile } = useAuth();
  const { addToCart, totalQty } = useCart();
  const { products: rtProds } = useRealtime();
  const [cat, setCat]         = useState('all');
  const [wishlist, setWishlist] = useState([]);
  const [refreshing, setRefreshing] = useState(false);
  const [bannerIdx, setBannerIdx]   = useState(0);
  const bannerRef = useRef(null);
  const timerRef  = useRef(null);

  useEffect(() => {
    loadWishlist();
    timerRef.current = setInterval(() => {
      setBannerIdx(i => { const n = (i + 1) % BANNERS.length; bannerRef.current?.scrollTo({ x: n * (W - 32), animated: true }); return n; });
    }, 4500);
    return () => clearInterval(timerRef.current);
  }, []);

  async function loadWishlist() {
    const { data: u } = await supabase.auth.getUser();
    if (!u?.user) return;
    const { data } = await supabase.from('profiles').select('wishlist').eq('id', u.user.id).maybeSingle();
    setWishlist(data?.wishlist || []);
  }

  async function toggleWish(id) {
    const { data: u } = await supabase.auth.getUser();
    if (!u?.user) return;
    const nl = wishlist.includes(id) ? wishlist.filter(x => x !== id) : [...wishlist, id];
    setWishlist(nl);
    await supabase.from('profiles').update({ wishlist: nl }).eq('id', u.user.id);
  }

  const filtered = (rtProds || []).filter(p => cat === 'all' || p.cat === cat);

  function ProdCard({ p }) {
    const inWish = wishlist.includes(p.id);
    return (
      <TouchableOpacity style={[styles.card, SHADOWS.card]} onPress={() => navigation.navigate('ProductDetail', { product: p })} activeOpacity={0.92}>
        <View style={styles.imgBox}>
          {p.img ? <Image source={{ uri: p.img }} style={styles.img} resizeMode="cover" /> : <Text style={styles.emoji}>{p.emoji || '📦'}</Text>}
          {p.badge && <View style={styles.badge}><Text style={styles.badgeTxt}>{p.badge}</Text></View>}
          <TouchableOpacity style={styles.wishBtn} onPress={() => toggleWish(p.id)}>
            <Text style={{ fontSize: 16 }}>{inWish ? '❤️' : '🤍'}</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.cardBody}>
          <Text style={styles.prodName} numberOfLines={2}>{p.name}</Text>
          <Text style={styles.prodSeller} numberOfLines={1}>🏪 {p.seller}</Text>
          <View style={styles.priceRow}>
            <Text style={styles.price}>Sh.So <Text style={styles.priceNum}>{(p.price || 0).toLocaleString()}</Text></Text>
            <TouchableOpacity style={[styles.addBtn, SHADOWS.orange]} onPress={() => { addToCart(p); console.log('', '✅ Kaydiyaha lagu daray!', [{ text: 'OK' }], { cancelable: true }); }}>
              <Text style={styles.addTxt}>+</Text>
            </TouchableOpacity>
          </View>
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <View style={styles.wrap}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Soo dhawoow 👋</Text>
          <Text style={styles.name}>{profile?.name?.split(' ')[0] || 'Somalizon'}</Text>
        </View>
        <View style={styles.hRight}>
          <TouchableOpacity style={styles.hBtn} onPress={() => navigation.navigate('Search')}>
            <Text style={{ fontSize: 18 }}>🔍</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.hBtn} onPress={() => navigation.navigate('Notifications')}>
            <Text style={{ fontSize: 18 }}>🔔</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.cartBtn, SHADOWS.orange]} onPress={() => navigation.navigate('Cart')}>
            <Text style={{ fontSize: 18 }}>🛒</Text>
            {totalQty > 0 && <View style={styles.cartBadge}><Text style={styles.cartBadgeTxt}>{totalQty}</Text></View>}
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => setRefreshing(false)} tintColor={P} />}>
        {/* Banners */}
        <View style={{ paddingLeft: 16, paddingTop: 14 }}>
          <ScrollView ref={bannerRef} horizontal pagingEnabled showsHorizontalScrollIndicator={false}
            snapToInterval={W - 32} decelerationRate="fast"
            onMomentumScrollEnd={e => setBannerIdx(Math.round(e.nativeEvent.contentOffset.x / (W - 32)))}>
            {BANNERS.map(b => (
              <TouchableOpacity key={b.id} activeOpacity={0.9}
                style={[styles.banner, { backgroundColor: b.bg, width: W - 40, marginRight: 8 }]}>
                <Text style={styles.bannerEmoji}>{b.emoji}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={[styles.bannerTitle, { color: b.color }]}>{b.title}</Text>
                  <Text style={[styles.bannerSub, { color: b.color === '#fff' ? 'rgba(255,255,255,0.8)' : COLORS.text2 }]}>{b.sub}</Text>
                </View>
                <View style={[styles.bannerArrow, { backgroundColor: b.color === '#fff' ? 'rgba(255,255,255,0.2)' : P }]}>
                  <Text style={{ color: b.color === '#fff' ? '#fff' : '#fff', fontWeight: '800', fontSize: 16 }}>›</Text>
                </View>
              </TouchableOpacity>
            ))}
          </ScrollView>
          <View style={styles.dots}>
            {BANNERS.map((b, i) => <View key={i} style={[styles.dot, { backgroundColor: i === bannerIdx ? P : COLORS.border, width: i === bannerIdx ? 18 : 6 }]} />)}
          </View>
        </View>

        {/* Categories */}
        <View style={{ marginTop: 20 }}>
          <Text style={styles.sectionTitle}>Noocyada</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16, gap: 8 }}>
            {CATS.map(c => (
              <TouchableOpacity key={c.key}
                style={[styles.catChip, { backgroundColor: cat === c.key ? P : '#fff' }, cat === c.key && SHADOWS.orange]}
                onPress={() => setCat(c.key)}>
                <Text style={{ fontSize: 16 }}>{c.emoji}</Text>
                <Text style={[styles.catTxt, { color: cat === c.key ? '#fff' : COLORS.text2 }]}>{c.label}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Products */}
        <View style={{ padding: 16, paddingTop: 20 }}>
          <View style={styles.secRow}>
            <Text style={styles.sectionTitle}>Alaabta 🛍️</Text>
            <Text style={{ color: COLORS.text3, fontSize: 13 }}>{filtered.length} alaab</Text>
          </View>
          {filtered.length === 0
            ? <View style={styles.empty}><Text style={{ fontSize: 46, marginBottom: 12 }}>🛍️</Text><Text style={{ color: COLORS.text3, fontSize: 15 }}>Alaab lama helin</Text></View>
            : <View style={styles.grid}>
                {filtered.map((p, i) => (
                  <View key={String(p.id)} style={{ width: CARD_W, marginLeft: i % 2 === 1 ? 16 : 0, marginBottom: 16 }}>
                    <ProdCard p={p} />
                  </View>
                ))}
                {filtered.length % 2 === 1 && <View style={{ width: CARD_W }} />}
              </View>
          }
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 54, paddingBottom: 12, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: COLORS.border },
  greeting: { fontSize: 12, color: COLORS.text2, fontWeight: '500', marginBottom: 2 },
  name: { fontSize: 20, fontWeight: '900', color: COLORS.text, letterSpacing: -0.3 },
  hRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  hBtn: { width: 40, height: 40, borderRadius: R.md, backgroundColor: COLORS.input, alignItems: 'center', justifyContent: 'center' },
  cartBtn: { width: 40, height: 40, borderRadius: R.md, backgroundColor: P, alignItems: 'center', justifyContent: 'center', position: 'relative' },
  cartBadge: { position: 'absolute', top: -5, right: -5, backgroundColor: COLORS.error, borderRadius: 8, minWidth: 18, alignItems: 'center', paddingHorizontal: 4, paddingVertical: 1, borderWidth: 2, borderColor: '#fff' },
  cartBadgeTxt: { color: '#fff', fontSize: 9, fontWeight: '900' },
  banner: { borderRadius: R.xl, padding: 20, flexDirection: 'row', alignItems: 'center', gap: 14 },
  bannerEmoji: { fontSize: 38 },
  bannerTitle: { fontWeight: '900', fontSize: 17, marginBottom: 4 },
  bannerSub: { fontSize: 12, fontWeight: '500' },
  bannerArrow: { width: 32, height: 32, borderRadius: 16, alignItems: 'center', justifyContent: 'center' },
  dots: { flexDirection: 'row', justifyContent: 'center', gap: 5, marginTop: 10 },
  dot: { height: 5, borderRadius: 3 },
  sectionTitle: { fontSize: 18, fontWeight: '900', color: COLORS.text, letterSpacing: -0.3, paddingHorizontal: 16, marginBottom: 12 },
  secRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  catChip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 10, borderRadius: R.full, borderWidth: 1, borderColor: COLORS.border },
  catTxt: { fontSize: 13, fontWeight: '700' },
  grid: { flexDirection: 'row', flexWrap: 'wrap' },
  card: { backgroundColor: '#fff', borderRadius: R.xl, overflow: 'hidden' },
  imgBox: { height: 155, backgroundColor: COLORS.input, alignItems: 'center', justifyContent: 'center', position: 'relative' },
  img: { width: '100%', height: '100%' },
  emoji: { fontSize: 50 },
  badge: { position: 'absolute', top: 8, left: 8, backgroundColor: P, paddingHorizontal: 8, paddingVertical: 3, borderRadius: R.full },
  badgeTxt: { color: '#fff', fontSize: 10, fontWeight: '800' },
  wishBtn: { position: 'absolute', top: 8, right: 8, width: 30, height: 30, borderRadius: 9, backgroundColor: 'rgba(255,255,255,0.85)', alignItems: 'center', justifyContent: 'center' },
  cardBody: { padding: 11 },
  prodName: { fontWeight: '700', fontSize: 13, color: COLORS.text, lineHeight: 18, marginBottom: 3 },
  prodSeller: { fontSize: 11, color: COLORS.text3, marginBottom: 8 },
  priceRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  price: { fontSize: 10, color: COLORS.text2, fontWeight: '500' },
  priceNum: { fontSize: 14, fontWeight: '900', color: P },
  addBtn: { width: 32, height: 32, borderRadius: 10, backgroundColor: P, alignItems: 'center', justifyContent: 'center' },
  addTxt: { color: '#fff', fontSize: 22, fontWeight: '800', lineHeight: 26 },
  empty: { alignItems: 'center', paddingTop: 50 },
});
