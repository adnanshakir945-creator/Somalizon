import React, { useEffect, useRef, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { COLORS, SHADOWS, R } from '../constants/Design';

const P = COLORS.primary;
function pad(n) { return String(n).padStart(2,'0'); }
function fmt(s) { return `${pad(Math.floor(s/60))}:${pad(s%60)}`; }

export default function CallScreen({ route, navigation }) {
  const { otherEmail, otherName, incomingCallId, isIncoming } = route.params;
  const { profile } = useAuth();
  const [status, setStatus]   = useState(isIncoming ? 'incoming' : 'calling');
  const [muted, setMuted]     = useState(false);
  const [speaker, setSpeaker] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const pcRef      = useRef(null);
  const callIdRef  = useRef(incomingCallId || null);
  const timerRef   = useRef(null);
  const channelRef = useRef(null);

  useEffect(() => {
    if (!isIncoming) startCall();
    else listenForAnswer();
    return cleanup;
  }, []);

  function startTimer() { timerRef.current = setInterval(() => setSeconds(s => s+1), 1000); }

  async function cleanup() {
    clearInterval(timerRef.current);
    if (channelRef.current) supabase.removeChannel(channelRef.current);
    if (pcRef.current) { pcRef.current.close(); pcRef.current = null; }
    if (callIdRef.current) await supabase.from('calls').update({ status: 'ended' }).eq('id', callIdRef.current);
  }

  async function createPC() {
    try {
      const { RTCPeerConnection, mediaDevices } = {};
      const stream = await mediaDevices.getUserMedia({ audio: true, video: false });
      const pc = new RTCPeerConnection({ iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] });
      stream.getTracks().forEach(t => pc.addTrack(t, stream));
      pcRef.current = pc; return pc;
    } catch {
      console.log('⚠️', 'Wac-ka u baahan: expo install react-native-webrtc');
      navigation.goBack(); return null;
    }
  }

  async function startCall() {
    const pc = await createPC(); if (!pc) return;
    const callId = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
    callIdRef.current = callId;
    pc.addEventListener('icecandidate', async ({ candidate }) => {
      if (candidate) await supabase.from('call_candidates').insert({ call_id: callId, role: 'caller', candidate: candidate.toJSON() });
    });
    const offer = await pc.createOffer({ offerToReceiveAudio: true });
    await pc.setLocalDescription(offer);
    await supabase.from('calls').insert({ id: callId, callerEmail: profile.email, calleeEmail: otherEmail, offer: { type: offer.type, sdp: offer.sdp }, status: 'ringing' });
    channelRef.current = supabase.channel('call-'+callId)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'calls', filter: 'id=eq.'+callId }, async ({ new: row }) => {
        if (row.status === 'answered' && row.answer) {
          const { RTCSessionDescription } = {};
          await pc.setRemoteDescription(new RTCSessionDescription(row.answer));
          setStatus('active'); startTimer();
        }
        if (row.status === 'ended' || row.status === 'declined') endCall();
      })
      .subscribe();
  }

  async function listenForAnswer() {
    const pc = await createPC(); if (!pc || !callIdRef.current) return;
    const callId = callIdRef.current;
    const { RTCSessionDescription, RTCIceCandidate } = {};
    pc.addEventListener('icecandidate', async ({ candidate }) => {
      if (candidate) await supabase.from('call_candidates').insert({ call_id: callId, role: 'callee', candidate: candidate.toJSON() });
    });
    const { data } = await supabase.from('calls').select('*').eq('id', callId).maybeSingle();
    if (!data?.offer) return;
    await pc.setRemoteDescription(new RTCSessionDescription(data.offer));
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    await supabase.from('calls').update({ answer: { type: answer.type, sdp: answer.sdp }, status: 'answered' }).eq('id', callId);
    setStatus('active'); startTimer();
  }

  async function endCall() {
    setStatus('ended'); await cleanup(); navigation.goBack();
  }

  async function declineCall() {
    if (callIdRef.current) await supabase.from('calls').update({ status: 'declined' }).eq('id', callIdRef.current);
    navigation.goBack();
  }

  const displayName = otherName || otherEmail.split('@')[0];

  return (
    <View style={styles.wrap}>
      {/* Background pattern */}
      <View style={styles.bgCircle1} />
      <View style={styles.bgCircle2} />

      {/* Avatar */}
      <View style={styles.avatarBox}>
        <View style={[styles.avatarRing, styles.ring3]} />
        <View style={[styles.avatarRing, styles.ring2]} />
        <View style={[styles.avatarRing, styles.ring1]} />
        <View style={styles.avatar}>
          <Text style={styles.avatarTxt}>{displayName[0]?.toUpperCase() || '?'}</Text>
        </View>
      </View>

      {/* Name & status */}
      <Text style={styles.callerName}>{displayName}</Text>
      <Text style={styles.callerEmail}>{otherEmail}</Text>
      <Text style={styles.statusTxt}>
        {status === 'calling'  ? '📞 La wacayaa...' :
         status === 'incoming' ? '📲 Wac soo gala...' :
         status === 'active'   ? `🟢 ${fmt(seconds)}` : '📵 Waca la joojiyay'}
      </Text>

      {/* Controls */}
      {status === 'incoming' ? (
        <View style={styles.incomingBtns}>
          <View style={styles.incomingCol}>
            <TouchableOpacity style={[styles.circleBtn, styles.declineBtn, SHADOWS.sm]} onPress={declineCall}>
              <Text style={{ fontSize: 30 }}>📵</Text>
            </TouchableOpacity>
            <Text style={styles.btnLabel}>Diibi</Text>
          </View>
          <View style={styles.incomingCol}>
            <TouchableOpacity style={[styles.circleBtn, styles.answerBtn, SHADOWS.orange]} onPress={listenForAnswer}>
              <Text style={{ fontSize: 30 }}>📞</Text>
            </TouchableOpacity>
            <Text style={styles.btnLabel}>Qabo</Text>
          </View>
        </View>
      ) : (
        <View style={styles.controls}>
          <View style={styles.ctrlCol}>
            <TouchableOpacity style={[styles.ctrlBtn, muted && styles.ctrlBtnOn]} onPress={() => setMuted(m => !m)}>
              <Text style={{ fontSize: 24 }}>{muted ? '🔇' : '🎤'}</Text>
            </TouchableOpacity>
            <Text style={styles.ctrlLabel}>{muted ? 'Unmute' : 'Mute'}</Text>
          </View>
          <View style={styles.ctrlCol}>
            <TouchableOpacity style={[styles.circleBtn, styles.endBtn, SHADOWS.sm]} onPress={endCall}>
              <Text style={{ fontSize: 28 }}>📵</Text>
            </TouchableOpacity>
            <Text style={styles.ctrlLabel}>Jooji</Text>
          </View>
          <View style={styles.ctrlCol}>
            <TouchableOpacity style={[styles.ctrlBtn, speaker && styles.ctrlBtnOn]} onPress={() => setSpeaker(s => !s)}>
              <Text style={{ fontSize: 24 }}>{speaker ? '🔊' : '🔈'}</Text>
            </TouchableOpacity>
            <Text style={styles.ctrlLabel}>Speaker</Text>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#0D0D0D', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  bgCircle1: { position: 'absolute', width: 400, height: 400, borderRadius: 200, backgroundColor: P + '12', top: -80, left: -80 },
  bgCircle2: { position: 'absolute', width: 300, height: 300, borderRadius: 150, backgroundColor: P + '08', bottom: -60, right: -60 },
  avatarBox: { alignItems: 'center', justifyContent: 'center', marginBottom: 28, position: 'relative', width: 160, height: 160 },
  avatarRing: { position: 'absolute', borderRadius: 100, borderWidth: 1.5, borderColor: P },
  ring1: { width: 140, height: 140, opacity: 0.4 },
  ring2: { width: 160, height: 160, opacity: 0.2 },
  ring3: { width: 180, height: 180, opacity: 0.1 },
  avatar: { width: 110, height: 110, borderRadius: 55, backgroundColor: P, alignItems: 'center', justifyContent: 'center', ...SHADOWS.orange },
  avatarTxt: { color: '#fff', fontSize: 46, fontWeight: '900' },
  callerName: { color: '#fff', fontSize: 28, fontWeight: '900', marginBottom: 6, letterSpacing: -0.3 },
  callerEmail: { color: 'rgba(255,255,255,0.5)', fontSize: 13, marginBottom: 12 },
  statusTxt: { color: 'rgba(255,255,255,0.8)', fontSize: 15, marginBottom: 64, fontWeight: '600' },
  incomingBtns: { flexDirection: 'row', gap: 60 },
  incomingCol: { alignItems: 'center', gap: 10 },
  controls: { flexDirection: 'row', alignItems: 'center', gap: 36 },
  ctrlCol: { alignItems: 'center', gap: 8 },
  circleBtn: { width: 68, height: 68, borderRadius: 34, alignItems: 'center', justifyContent: 'center' },
  endBtn: { backgroundColor: COLORS.error },
  answerBtn: { backgroundColor: COLORS.success },
  declineBtn: { backgroundColor: COLORS.error },
  ctrlBtn: { width: 56, height: 56, borderRadius: 18, backgroundColor: 'rgba(255,255,255,0.1)', alignItems: 'center', justifyContent: 'center' },
  ctrlBtnOn: { backgroundColor: '#fff' },
  ctrlLabel: { color: 'rgba(255,255,255,0.6)', fontSize: 11, fontWeight: '600' },
  btnLabel: { color: 'rgba(255,255,255,0.7)', fontSize: 13, fontWeight: '600' },
});
