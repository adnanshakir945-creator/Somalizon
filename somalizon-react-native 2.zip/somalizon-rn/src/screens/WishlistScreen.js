import React, { useEffect, useState, useCallback } from 'react';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  Image, ActivityIndicator, RefreshControl, Alert,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { useTheme } from '../contexts/ThemeContext';

const ORANGE = '#FF6B00';

export default function WishlistScreen({ navigation }) {
  const { profile } = useAuth();
  const { addToCart } = useCart();
  const { theme } = useTheme();
  const [wishlist, setWishlist] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { loadWishlist(); }, []);

  async function loadWishlist() {
    setLoading(true);
    const { data: user } = await supabase.auth.getUser();
    if (!user?.user) { setLoading(false); return; }
    const { data: prof } = await supabase.from('profiles').select('wishlist').eq('id', user.user.id).maybeSingle();
    const ids = prof?.wishlist || [];
    setWishlist(ids);
    if (ids.length) {
      const { data: prods } = await supabase.from('products').select('*').in('id', ids);
      setProducts(prods || []);
    } else {
      setProducts([]);
    }
    setLoading(false);
  }

  async function removeFromWishlist(prodId) {
    const { data: user } = await supabase.auth.getUser();
    if (!user?.user) return;
    const newList = wishlist.filter(id => id !== prodId);
    setWishlist(newList);
    setProducts(prev => prev.filter(p => p.id !== prodId));
    await supabase.from('profiles').update({ wishlist: newList }).eq('id', user.user.id);
  }

  const onRefresh = useCallback(async () => { setRefreshing(true); await loadWishlist(); setRefreshing(false); }, []);

  function renderItem({ item: p }) {
    return (
      <TouchableOpacity
        style={[styles.card, { backgroundColor: theme.card }]}
        onPress={() => navigation.navigate('ProductDetail', { product: p })}
      >
        <View style={styles.imgBox}>
          {p.img
            ? <Image source={{ uri: p.img }} style={styles.img} resizeMode="cover" />
            : <Text style={styles.emoji}>{p.emoji || '📦'}</Text>
          }
          <TouchableOpacity style={styles.heartBtn} onPress={() => console.log('Ka saar?', p.name, [
            { text: 'Maya', style: 'cancel' },
            { text: 'Haa', onPress: () => removeFromWishlist(p.id) }
          ])}>
            <Text style={{ fontSize: 18 }}>❤️</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.info}>
          <Text style={[styles.name, { color: theme.text }]} numberOfLines={2}>{p.name}</Text>
          <Text style={[styles.seller, { color: theme.text2 }]}>👤 {p.seller}</Text>
          <Text style={[styles.price, { color: ORANGE }]}>Sh.So {(p.price || 0).toLocaleString()}</Text>
          <TouchableOpacity style={styles.cartBtn} onPress={() => { addToCart(p); console.log('✅', 'Kaydiyaha lagu daray!'); }}>
            <Text style={styles.cartBtnTxt}>🛒 Basket Ku Dar</Text>
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Text style={styles.back}>←</Text></TouchableOpacity>
        <Text style={[styles.title, { color: theme.text }]}>❤️ Rabitaanka ({wishlist.length})</Text>
        <View style={{ width: 30 }} />
      </View>

      {loading ? <ActivityIndicator color={ORANGE} style={{ marginTop: 40 }} /> : (
        <FlatList
          data={products} keyExtractor={p => String(p.id)}
          numColumns={2} columnWrapperStyle={{ gap: 10 }}
          contentContainerStyle={{ padding: 12 }}
          renderItem={renderItem}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={ORANGE} />}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={{ fontSize: 56, marginBottom: 14 }}>❤️</Text>
              <Text style={[styles.emptyTxt, { color: theme.text2 }]}>Wax alaab ah oo kaydsan ma jirto</Text>
              <TouchableOpacity style={styles.shopBtn} onPress={() => navigation.navigate('Home')}>
                <Text style={styles.shopBtnTxt}>🛍️ Alaab Raadi</Text>
              </TouchableOpacity>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52, borderBottomWidth: 1 },
  back: { fontSize: 24, color: ORANGE },
  title: { fontSize: 17, fontWeight: '700' },
  card: { flex: 1, borderRadius: 16, overflow: 'hidden', marginBottom: 10, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 },
  imgBox: { height: 140, backgroundColor: '#f8f8f8', alignItems: 'center', justifyContent: 'center', position: 'relative' },
  img: { width: '100%', height: '100%' },
  emoji: { fontSize: 46 },
  heartBtn: { position: 'absolute', top: 6, right: 6 },
  info: { padding: 10 },
  name: { fontWeight: '700', fontSize: 13, marginBottom: 3 },
  seller: { fontSize: 11, marginBottom: 3 },
  price: { fontWeight: '800', fontSize: 14, marginBottom: 8 },
  cartBtn: { backgroundColor: ORANGE, padding: 8, borderRadius: 8, alignItems: 'center' },
  cartBtnTxt: { color: '#fff', fontWeight: '700', fontSize: 12 },
  empty: { alignItems: 'center', marginTop: 80 },
  emptyTxt: { fontSize: 15, marginBottom: 20 },
  shopBtn: { backgroundColor: ORANGE, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 14 },
  shopBtnTxt: { color: '#fff', fontWeight: '700' },
});
