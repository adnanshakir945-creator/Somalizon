import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, Image, ActivityIndicator, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';

const ORANGE = '#FF6B00';
const CATS = ['food', 'fashion', 'electronics', 'beauty', 'home', 'sports', 'other'];

export default function EditProductScreen({ route, navigation }) {
  const { product } = route.params;
  const { profile } = useAuth();
  const { theme } = useTheme();
  const [name, setName] = useState(product.name || '');
  const [price, setPrice] = useState(String(product.price || ''));
  const [desc, setDesc] = useState(product.desc || '');
  const [cat, setCat] = useState(product.cat || 'other');
  const [emoji, setEmoji] = useState(product.emoji || '📦');
  const [imgUri, setImgUri] = useState(null);
  const [saving, setSaving] = useState(false);
  const [deleting, setDeleting] = useState(false);

  async function pickImage() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { console.log('⚠️', 'Fasax library'); return; }
    const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, base64: true });
    if (!res.canceled && res.assets?.length) setImgUri(res.assets[0]);
  }

  async function saveProduct() {
    if (!name.trim() || !price || isNaN(Number(price))) { console.log('⚠️', 'Magaca iyo qiimaha sax ah gali'); return; }
    setSaving(true);
    let imgUrl = product.img;

    if (imgUri?.uri && imgUri?.base64) {
      const ext = imgUri.uri.split('.').pop() || 'jpg';
      const path = `products/${profile.id}_${Date.now()}.${ext}`;
      const byteArr = Uint8Array.from(atob(imgUri.base64), c => c.charCodeAt(0));
      const { error: upErr } = await supabase.storage.from('product-images').upload(path, byteArr, { contentType: `image/${ext}`, upsert: false });
      if (!upErr) {
        const { data: urlData } = supabase.storage.from('product-images').getPublicUrl(path);
        imgUrl = urlData.publicUrl;
      }
    }

    const { error } = await supabase.from('products').update({
      name: name.trim(), price: Number(price), desc: desc.trim(), cat, emoji, img: imgUrl,
    }).eq('id', product.id);

    setSaving(false);
    if (error) { console.log('⚠️ Khalad', error.message); return; }
    console.log('✅ La cusboonaysiiyay!', '', [{ text: 'OK', onPress: () => navigation.goBack() }]);
  }

  async function deleteProduct() {
    console.log('Tirtir Alaabta', `"${product.name}" ma tirtirtaa?`, [
      { text: 'Maya', style: 'cancel' },
      {
        text: 'Haa, Tirtir', style: 'destructive', onPress: async () => {
          setDeleting(true);
          const { error } = await supabase.from('products').delete().eq('id', product.id);
          setDeleting(false);
          if (error) { console.log('⚠️ Khalad', error.message); return; }
          navigation.goBack();
        }
      }
    ]);
  }

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView style={[styles.wrap, { backgroundColor: theme.bg }]} keyboardShouldPersistTaps="handled">
        <View style={[styles.header, { backgroundColor: theme.header }]}>
          <TouchableOpacity onPress={() => navigation.goBack()}><Text style={styles.back}>←</Text></TouchableOpacity>
          <Text style={[styles.title, { color: theme.text }]}>✏️ Alaabta Beddel</Text>
          <TouchableOpacity onPress={deleteProduct} disabled={deleting}>
            {deleting ? <ActivityIndicator color="#ef4444" /> : <Text style={{ color: '#ef4444', fontSize: 20 }}>🗑️</Text>}
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.imgPicker} onPress={pickImage}>
          {imgUri?.uri
            ? <Image source={{ uri: imgUri.uri }} style={styles.imgPreview} />
            : product.img
              ? <Image source={{ uri: product.img }} style={styles.imgPreview} />
              : <View style={styles.imgPlaceholder}>
                  <Text style={{ fontSize: 40 }}>{product.emoji || '📦'}</Text>
                  <Text style={{ color: '#aaa', marginTop: 8 }}>Sawir beddel</Text>
                </View>
          }
        </TouchableOpacity>

        <View style={styles.form}>
          <Text style={[styles.label, { color: theme.text }]}>Magaca Alaabta *</Text>
          <TextInput style={[styles.input, { backgroundColor: theme.input, color: theme.inputText }]} value={name} onChangeText={setName} placeholder="Magaca alaabta" placeholderTextColor="#999" />

          <Text style={[styles.label, { color: theme.text }]}>Qiimaha (Sh.So) *</Text>
          <TextInput style={[styles.input, { backgroundColor: theme.input, color: theme.inputText }]} value={price} onChangeText={setPrice} keyboardType="numeric" placeholder="Qiimaha" placeholderTextColor="#999" />

          <Text style={[styles.label, { color: theme.text }]}>Faahfaahinta</Text>
          <TextInput style={[styles.input, { backgroundColor: theme.input, color: theme.inputText, height: 80 }]} value={desc} onChangeText={setDesc} multiline placeholder="Sharax alaabta..." placeholderTextColor="#999" />

          <Text style={[styles.label, { color: theme.text }]}>Nooca</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 20 }}>
            {CATS.map(c => (
              <TouchableOpacity key={c} style={[styles.catChip, cat === c && styles.catChipOn]} onPress={() => setCat(c)}>
                <Text style={[styles.catTxt, cat === c && { color: '#fff' }]}>{c}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <TouchableOpacity style={styles.saveBtn} onPress={saveProduct} disabled={saving}>
            {saving ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveBtnTxt}>💾 Kaydi Isbedelka</Text>}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52 },
  back: { fontSize: 24, color: ORANGE },
  title: { fontSize: 17, fontWeight: '700' },
  imgPicker: { margin: 16, borderRadius: 16, overflow: 'hidden', height: 180, backgroundColor: '#f0f0f0' },
  imgPreview: { width: '100%', height: '100%' },
  imgPlaceholder: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  form: { padding: 16 },
  label: { fontWeight: '700', marginBottom: 6, fontSize: 13 },
  input: { borderRadius: 12, padding: 12, marginBottom: 16, fontSize: 14 },
  catChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: '#f0f0f0', marginRight: 8 },
  catChipOn: { backgroundColor: ORANGE },
  catTxt: { fontSize: 12, fontWeight: '600', color: '#666' },
  saveBtn: { backgroundColor: ORANGE, padding: 16, borderRadius: 14, alignItems: 'center' },
  saveBtnTxt: { color: '#fff', fontWeight: '800', fontSize: 15 },
});
