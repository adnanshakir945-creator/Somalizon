import React, { useState, useRef, useEffect } from 'react';
import { Ionicons } from '@expo/vector-icons';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, Alert, ScrollView, Animated, Dimensions,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { COLORS, SHADOWS, R } from '../constants/Design';
import { PrimaryBtn } from '../components/Buttons';
import { useToast } from '../components/Toast';

const { width: W } = Dimensions.get('window');
const P = COLORS.primary;

export default function LoginScreen({ navigation }) {
  const [tab, setTab]     = useState('buyer');
  const [email, setEmail] = useState('');
  const [pass, setPass]   = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const showToast = useToast();

  const fadeY = useRef(new Animated.Value(30)).current;
  const fadeO = useRef(new Animated.Value(0)).current;
  const tabX  = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.spring(fadeY, { toValue: 0, tension: 60, friction: 8, useNativeDriver: true }),
      Animated.timing(fadeO, { toValue: 1, duration: 500, useNativeDriver: true }),
    ]).start();
  }, []);

  function switchTab(t) {
    setTab(t);
    Animated.spring(tabX, { toValue: t === 'buyer' ? 0 : 1, tension: 120, friction: 10, useNativeDriver: false }).start();
  }

  async function handleLogin() {
    if (!email.trim()) { showToast('Email gali', 'error'); return; }
    if (!pass)         { showToast('Password gali', 'error'); return; }
    setLoading(true);
    const { error } = await supabase.auth.signInWithPassword({ email: email.trim(), password: pass });
    if (error) {
      if ((error.message || '').toLowerCase().includes('invalid login credentials')) {
        const name = email.split('@')[0];
        const r2 = await supabase.auth.signUp({ email: email.trim(), password: pass, options: { data: { name, user_type: tab } } });
        if (r2.error) { showToast(r2.error.message.includes('already registered') ? 'Password-ka khaldan!' : r2.error.message, 'error'); setLoading(false); return; }
        if (!r2.data?.session) { showToast('Password-ka khaldan!', 'error'); setLoading(false); return; }
        await supabase.from('profiles').upsert({ id: r2.data.user.id, email: email.trim().toLowerCase(), name, user_type: tab });
        if (tab === 'seller') await supabase.from('stores').upsert({ id: r2.data.user.id, name, sellerName: name, sellerEmail: email.trim(), sellerUid: r2.data.user.id, emoji: 'storefront-outline', rating: 5, followers: 0 });
        setLoading(false); return;
      }
      showToast(error.message, 'error');
    }
    setLoading(false);
  }

  const indicatorLeft = tabX.interpolate({ inputRange: [0, 1], outputRange: ['3%', '51%'] });

  return (
    <KeyboardAvoidingView style={styles.wrap} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">

        {/* Top orange wave */}
        <View style={styles.topWave}>
          <View style={styles.waveBg} />
          <View style={styles.logoBox}>
            <Ionicons name="bag-handle-outline" size={20} color={'#333'} />
          </View>
          <Text style={styles.appName}>Somali<Text style={styles.appNameOrange}>zon</Text></Text>
          <Text style={styles.appSub}>Suuqa Online-ka Soomaaliya</Text>
        </View>

        <Animated.View style={{ transform: [{ translateY: fadeY }], opacity: fadeO, padding: 24, paddingTop: 32 }}>

          {/* Tab */}
          <View style={styles.tabWrap}>
            <Animated.View style={[styles.tabIndicator, { left: indicatorLeft }]} />
            {['buyer', 'seller'].map(t => (
              <TouchableOpacity key={t} style={styles.tabBtn} onPress={() => switchTab(t)}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                  <Ionicons name={t === 'buyer' ? 'bag-handle-outline' : 'storefront-outline'} size={14} color={tab === t ? styles.tabTxtOn.color : styles.tabTxt.color} />
                  <Text style={[styles.tabTxt, tab === t && styles.tabTxtOn]}>{t === 'buyer' ? 'Macmiil' : 'Ganacsade'}</Text>
                </View>
              </TouchableOpacity>
            ))}
          </View>

          {/* Inputs */}
          <View style={styles.inputWrap}>
            <Ionicons name="mail-outline" size={20} color={'#333'} />
            <TextInput
              style={styles.input} placeholder="Email address"
              placeholderTextColor={COLORS.text3} autoCapitalize="none"
              keyboardType="email-address" value={email} onChangeText={setEmail}
            />
          </View>

          <View style={styles.inputWrap}>
            <Ionicons name="lock-closed-outline" size={20} color={'#333'} />
            <TextInput
              style={styles.input} placeholder="Password"
              placeholderTextColor={COLORS.text3} secureTextEntry={!showPw}
              value={pass} onChangeText={setPass}
            />
            <TouchableOpacity onPress={() => setShowPw(s => !s)} style={{ paddingHorizontal: 4 }}>
              <Ionicons name={showPw ? 'eye-off-outline' : 'eye-outline'} size={18} color={'#333'} />
            </TouchableOpacity>
          </View>

          <PrimaryBtn label="Soo Gal" icon={tab === 'buyer' ? 'bag-handle-outline' : 'storefront-outline'} onPress={handleLogin} loading={loading} style={{ marginTop: 8, marginBottom: 20 }} />

          {/* Divider */}
          <View style={styles.divider}>
            <View style={styles.divLine} />
            <Text style={styles.divTxt}>ama</Text>
            <View style={styles.divLine} />
          </View>

          {/* Google */}
          <TouchableOpacity style={styles.googleBtn} onPress={async () => {
            const { error } = await supabase.auth.signInWithOAuth({ provider: 'google' });
            if (error) showToast(error.message, 'error');
          }}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}><Ionicons name="globe-outline" size={18} color={styles.googleTxt.color} /><Text style={styles.googleTxt}>Google ku Gal</Text></View>
          </TouchableOpacity>

          {tab === 'seller' && (
            <TouchableOpacity style={styles.signupRow} onPress={() => navigation.navigate('Signup')}>
              <Text style={styles.signupTxt}>Ganacsade cusub? <Text style={styles.signupLink}>Account samee</Text></Text>
            </TouchableOpacity>
          )}
        </Animated.View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#fff' },
  scroll: { flexGrow: 1 },
  topWave: { backgroundColor: P, paddingTop: 70, paddingBottom: 40, alignItems: 'center', borderBottomLeftRadius: 36, borderBottomRightRadius: 36, overflow: 'hidden' },
  waveBg: { position: 'absolute', width: W * 1.4, height: W * 1.4, borderRadius: W * 0.7, backgroundColor: 'rgba(255,255,255,0.08)', top: -W * 0.5, left: -W * 0.2 },
  logoBox: { width: 72, height: 72, borderRadius: 22, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', marginBottom: 12, ...SHADOWS.card },
  logoEmoji: { fontSize: 34 },
  appName: { fontSize: 30, fontWeight: '900', color: '#fff', letterSpacing: -0.5 },
  appNameOrange: { color: 'rgba(255,255,255,0.7)' },
  appSub: { color: 'rgba(255,255,255,0.75)', fontSize: 12, marginTop: 4, letterSpacing: 0.5 },
  tabWrap: { flexDirection: 'row', backgroundColor: COLORS.input, borderRadius: R.full, padding: 4, marginBottom: 24, height: 50, position: 'relative' },
  tabIndicator: { position: 'absolute', top: 4, bottom: 4, width: '46%', backgroundColor: P, borderRadius: R.full, ...SHADOWS.orange },
  tabBtn: { flex: 1, alignItems: 'center', justifyContent: 'center', zIndex: 1 },
  tabTxt: { fontWeight: '600', color: COLORS.text2, fontSize: 14 },
  tabTxtOn: { color: '#fff', fontWeight: '800' },
  inputWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.input, borderRadius: R.lg, borderWidth: 1.5, borderColor: COLORS.inputBorder, paddingHorizontal: 14, marginBottom: 14 },
  inputIcon: { fontSize: 18, marginRight: 10 },
  input: { flex: 1, paddingVertical: 15, fontSize: 15, color: COLORS.text },
  divider: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  divLine: { flex: 1, height: 1, backgroundColor: COLORS.border },
  divTxt: { color: COLORS.text3, paddingHorizontal: 12, fontSize: 13 },
  googleBtn: { backgroundColor: '#fff', borderRadius: R.lg, padding: 15, alignItems: 'center', borderWidth: 1.5, borderColor: COLORS.border, marginBottom: 16 },
  googleTxt: { color: COLORS.text, fontWeight: '600', fontSize: 15 },
  signupRow: { alignItems: 'center', marginTop: 6 },
  signupTxt: { color: COLORS.text2, fontSize: 14 },
  signupLink: { color: P, fontWeight: '800' },
});
