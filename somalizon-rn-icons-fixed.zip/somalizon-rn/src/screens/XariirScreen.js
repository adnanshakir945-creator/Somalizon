import React, { useEffect, useState, useRef } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator, RefreshControl } from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { COLORS, SHADOWS, R } from '../constants/Design';

const P = COLORS.primary;
function timeSince(iso) {
  if (!iso) return '';
  const d = Date.now() - new Date(iso).getTime(), m = Math.floor(d / 60000);
  if (m < 1) return 'Hadda'; if (m < 60) return m + 'dq';
  const h = Math.floor(m / 60); if (h < 24) return h + 'swr';
  return Math.floor(h / 24) + 'ml';
}

export default function XariirScreen({ navigation }) {
  const { profile } = useAuth();
  const [chats, setChats] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const channelRef = useRef(null);

  useEffect(() => {
    if (!profile?.email) return;
    loadChats();
    const ch = supabase.channel('chatlist-' + profile.email)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'chats' }, loadChats)
      .subscribe();
    channelRef.current = ch;
    return () => supabase.removeChannel(ch);
  }, [profile]);

  async function loadChats() {
    if (!profile?.email) return;
    setLoading(false);
    const email = profile.email.toLowerCase().trim();
    const { data } = await supabase.from('chats').select('*')
      .contains('participantEmails', JSON.stringify([email]))
      .order('lastTime', { ascending: false });
    setChats(data || []);
  }

  function getOther(chat) {
    const participants = chat.participantEmails || [];
    const other = participants.find(e => e !== profile?.email?.toLowerCase());
    return other || '';
  }

  function ChatRow({ c }) {
    const other = getOther(c);
    const name = other ? other.split('@')[0] : '?';
    const unread = c.unread || 0;
    const isMe = c.lastSenderEmail === profile?.email?.toLowerCase();

    return (
      <TouchableOpacity style={styles.chatRow} onPress={() => navigation.navigate('ChatRoom', { chat: c, otherName: name, otherEmail: other })} activeOpacity={0.8}>
        <View style={styles.avatar}>
          <Text style={styles.avatarTxt}>{name[0]?.toUpperCase() || '?'}</Text>
          {unread > 0 && <View style={styles.unreadDot} />}
        </View>
        <View style={styles.chatBody}>
          <View style={styles.chatTop}>
            <Text style={[styles.chatName, unread > 0 && styles.chatNameBold]}>{name}</Text>
            <Text style={styles.chatTime}>{timeSince(c.lastTime)}</Text>
          </View>
          <View style={styles.chatBottom}>
            <Text style={[styles.lastMsg, unread > 0 && styles.lastMsgBold]} numberOfLines={1}>
              {isMe ? 'Adiga: ' : ''}{c.lastMessage || 'Fariin ma jirto'}
            </Text>
            {unread > 0 && <View style={styles.unreadBadge}><Text style={styles.unreadTxt}>{unread}</Text></View>}
          </View>
        </View>
      </TouchableOpacity>
    );
  }

  if (!profile) return (
    <View style={styles.center}>
      <Ionicons name="chatbubble-outline" size={50} color={'#333'} />
      <Text style={styles.guestTxt}>Fadlan soo gal si aad xariirtaada u aragto</Text>
    </View>
  );

  return (
    <View style={styles.wrap}>
      <View style={styles.header}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Ionicons name="chatbubble-outline" size={18} color={COLORS.text} />
          <Text style={styles.title}>Xariir</Text>
        </View>
        <View style={[styles.onlineBadge]}>
          <View style={styles.onlineDot} />
          <Text style={styles.onlineTxt}>Online</Text>
        </View>
      </View>
      {loading ? <ActivityIndicator color={P} style={{ marginTop: 40 }} /> : (
        <FlatList
          data={chats} keyExtractor={c => String(c.id)}
          renderItem={({ item }) => <ChatRow c={item} />}
          contentContainerStyle={{ paddingTop: 8 }}
          ItemSeparatorComponent={() => <View style={styles.sep} />}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await loadChats(); setRefreshing(false); }} tintColor={P} />}
          ListEmptyComponent={
            <View style={styles.center}>
              <Ionicons name="chatbubble-outline" size={60} color={'#333'} />
              <Text style={styles.emptyTitle}>Wax xariir ah ma jiraan weli</Text>
              <Text style={styles.emptyHint}>Alaab riix ka dib "Xariir" si aad u hadashid ganacsade</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#fff' },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 54, paddingBottom: 12, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  title: { fontSize: 22, fontWeight: '900', color: COLORS.text },
  onlineBadge: { flexDirection: 'row', alignItems: 'center', gap: 5, backgroundColor: '#E8FFF5', paddingHorizontal: 10, paddingVertical: 5, borderRadius: R.full },
  onlineDot: { width: 7, height: 7, borderRadius: 4, backgroundColor: COLORS.success },
  onlineTxt: { color: COLORS.success, fontSize: 12, fontWeight: '700' },
  chatRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 14 },
  avatar: { width: 52, height: 52, borderRadius: 26, backgroundColor: COLORS.primaryPale, alignItems: 'center', justifyContent: 'center', marginRight: 12, position: 'relative' },
  avatarTxt: { color: P, fontWeight: '800', fontSize: 20 },
  unreadDot: { position: 'absolute', top: 2, right: 2, width: 12, height: 12, borderRadius: 6, backgroundColor: P, borderWidth: 2, borderColor: '#fff' },
  chatBody: { flex: 1 },
  chatTop: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 5 },
  chatName: { fontWeight: '600', fontSize: 15, color: COLORS.text },
  chatNameBold: { fontWeight: '800' },
  chatTime: { color: COLORS.text3, fontSize: 12 },
  chatBottom: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  lastMsg: { color: COLORS.text2, fontSize: 13, flex: 1 },
  lastMsgBold: { color: COLORS.text, fontWeight: '600' },
  unreadBadge: { backgroundColor: P, borderRadius: R.full, minWidth: 20, height: 20, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 5 },
  unreadTxt: { color: '#fff', fontSize: 11, fontWeight: '800' },
  sep: { height: 1, backgroundColor: COLORS.border, marginLeft: 80 },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', padding: 30, marginTop: 60 },
  guestTxt: { color: COLORS.text2, fontSize: 15, textAlign: 'center' },
  emptyTitle: { fontWeight: '800', fontSize: 17, color: COLORS.text, marginBottom: 8, textAlign: 'center' },
  emptyHint: { color: COLORS.text2, fontSize: 13, textAlign: 'center', lineHeight: 18 },
});
