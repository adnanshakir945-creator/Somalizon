import React, { useState, useEffect, useRef } from 'react';
import { Ionicons } from '@expo/vector-icons';
import {
  View, Text, TextInput, FlatList, TouchableOpacity, StyleSheet,
  Image, ActivityIndicator, Keyboard,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useTheme } from '../contexts/ThemeContext';
import { useCart } from '../contexts/CartContext';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ORANGE = '#FF6B00';
const HISTORY_KEY = 'sHistory';

export default function SearchScreen({ navigation }) {
  const { theme } = useTheme();
  const { addToCart } = useCart();
  const [query, setQuery] = useState('');
  const [history, setHistory] = useState([]);
  const [tab, setTab] = useState('products');
  const [results, setResults] = useState([]);
  const [storeResults, setStoreResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const inputRef = useRef(null);
  const debounceRef = useRef(null);

  useEffect(() => {
    loadHistory();
    setTimeout(() => inputRef.current?.focus(), 100);
  }, []);

  async function loadHistory() {
    const h = await AsyncStorage.getItem(HISTORY_KEY);
    setHistory(h ? JSON.parse(h) : []);
  }

  async function saveToHistory(q) {
    if (!q.trim()) return;
    const updated = [q.trim(), ...history.filter(s => s !== q.trim())].slice(0, 8);
    setHistory(updated);
    await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
  }

  async function clearHistory() {
    setHistory([]);
    await AsyncStorage.removeItem(HISTORY_KEY);
  }

  async function deleteHistoryItem(item) {
    const updated = history.filter(h => h !== item);
    setHistory(updated);
    await AsyncStorage.setItem(HISTORY_KEY, JSON.stringify(updated));
  }

  function handleChange(text) {
    setQuery(text);
    clearTimeout(debounceRef.current);
    if (!text.trim()) { setResults([]); setStoreResults([]); return; }
    debounceRef.current = setTimeout(() => doSearch(text.trim()), 350);
  }

  async function doSearch(q) {
    setLoading(true);
    const [prodsRes, storesRes] = await Promise.all([
      supabase.from('products').select('*').ilike('name', `%${q}%`).limit(30),
      supabase.from('stores').select('*').ilike('name', `%${q}%`).limit(15),
    ]);
    setResults(prodsRes.data || []);
    setStoreResults(storesRes.data || []);
    setLoading(false);
    await saveToHistory(q);
  }

  function handleSubmit() {
    Keyboard.dismiss();
    if (query.trim()) doSearch(query.trim());
  }

  function useHistory(q) {
    setQuery(q);
    doSearch(q);
  }

  const showHistory = !query.trim() && history.length > 0;
  const noResults = query.trim() && !loading && results.length === 0 && storeResults.length === 0;

  return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      {/* Search bar */}
      <View style={[styles.searchBar, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <Ionicons name="chevron-back" size={20} color={'#333'} />
        </TouchableOpacity>
        <Ionicons name="search-outline" size={16} color={'#999'} style={{ marginRight: 6 }} />
        <TextInput
          ref={inputRef}
          style={[styles.input, { backgroundColor: theme.input, color: theme.inputText }]}
          placeholder="Alaab, dukaan raadi..." placeholderTextColor="#999"
          value={query} onChangeText={handleChange} onSubmitEditing={handleSubmit}
          returnKeyType="search" autoCorrect={false}
        />
        {query.length > 0 && (
          <TouchableOpacity onPress={() => { setQuery(''); setResults([]); setStoreResults([]); }} style={styles.clearBtn}>
            <Ionicons name="close" size={20} color={'#333'} />
          </TouchableOpacity>
        )}
      </View>

      {/* Tabs */}
      {query.trim() && (
        <View style={[styles.tabs, { backgroundColor: theme.card, borderBottomColor: theme.border }]}>
          {[
            { key: 'products', label: `Alaabta (${results.length})`, icon: 'bag-handle-outline' },
            { key: 'stores', label: `Dukaannada (${storeResults.length})`, icon: 'storefront-outline' },
          ].map(t => (
            <TouchableOpacity key={t.key} style={[styles.tab, tab === t.key && styles.tabOn]} onPress={() => setTab(t.key)}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
                <Ionicons name={t.icon} size={13} color={tab === t.key ? ORANGE : theme.text2} />
                <Text style={[styles.tabTxt, { color: tab === t.key ? ORANGE : theme.text2 }]}>{t.label}</Text>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      )}

      {loading && <ActivityIndicator color={ORANGE} style={{ marginTop: 30 }} />}

      {/* History */}
      {showHistory && (
        <View style={{ padding: 16 }}>
          <View style={styles.historyHeader}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="time-outline" size={14} color={theme.text} /><Text style={[styles.historyTitle, { color: theme.text }]}>Raadintii Hore</Text></View>
            <TouchableOpacity onPress={clearHistory}><Text style={styles.clearAll}>Dhami tirtir</Text></TouchableOpacity>
          </View>
          {history.map(h => (
            <View key={h} style={[styles.historyRow, { borderBottomColor: theme.border }]}>
              <TouchableOpacity style={{ flex: 1, flexDirection: 'row', alignItems: 'center', gap: 10 }} onPress={() => useHistory(h)}>
                <Ionicons name="time-outline" size={16} color={'#aaa'} />
                <Text style={[styles.historyTxt, { color: theme.text }]}>{h}</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => deleteHistoryItem(h)}><Ionicons name="close" size={18} color={'#ccc'} /></TouchableOpacity>
            </View>
          ))}
        </View>
      )}

      {/* No results */}
      {noResults && (
        <View style={styles.empty}>
          <Ionicons name="search-outline" size={50} color={'#333'} />
          <Text style={[styles.emptyTxt, { color: theme.text2 }]}>"{query}" lama helin</Text>
          <Text style={[styles.emptyHint, { color: theme.text2 }]}>Ereyga kale isku day</Text>
        </View>
      )}

      {/* Product results */}
      {!loading && query.trim() && tab === 'products' && results.length > 0 && (
        <FlatList
          data={results} keyExtractor={p => String(p.id)}
          contentContainerStyle={{ padding: 12 }}
          numColumns={2} columnWrapperStyle={{ gap: 10 }}
          renderItem={({ item: p }) => (
            <TouchableOpacity
              style={[styles.prodCard, { backgroundColor: theme.card }]}
              onPress={() => navigation.navigate('ProductDetail', { product: p })}
            >
              <View style={styles.prodImg}>
                {p.img
                  ? <Image source={{ uri: p.img }} style={{ width: '100%', height: '100%' }} resizeMode="cover" />
                  : <Ionicons name={toIconName(p.emoji)} size={36} color={'#333'} />}
              </View>
              <View style={{ padding: 8 }}>
                <Text style={[styles.prodName, { color: theme.text }]} numberOfLines={2}>{p.name}</Text>
                <Text style={styles.prodPrice}>Sh.So {(p.price || 0).toLocaleString()}</Text>
                <TouchableOpacity style={styles.cartBtn} onPress={() => { addToCart(p); }}>
                  <Text style={styles.cartBtnTxt}>+ Basket</Text>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          )}
        />
      )}

      {/* Store results */}
      {!loading && query.trim() && tab === 'stores' && storeResults.length > 0 && (
        <FlatList
          data={storeResults} keyExtractor={s => String(s.id)}
          contentContainerStyle={{ padding: 12 }}
          renderItem={({ item: s }) => (
            <TouchableOpacity
              style={[styles.storeCard, { backgroundColor: theme.card }]}
              onPress={() => navigation.navigate('StoreDetail', { store: s })}
            >
              <Ionicons name={toIconName(s.emoji, 'storefront-outline')} size={styles.storeEmoji.fontSize || 30} color={'#333'} style={styles.storeEmoji} />
              <View style={{ flex: 1 }}>
                <Text style={[styles.storeName, { color: theme.text }]}>{s.name}</Text>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                  <Ionicons name="star" size={11} color="#FFB800" />
                  <Text style={[styles.storeMeta, { color: theme.text2 }]}>{s.rating || 5}</Text>
                  <Text style={[styles.storeMeta, { color: theme.text2 }]}> · </Text>
                  <Ionicons name="people-outline" size={11} color={theme.text2} />
                  <Text style={[styles.storeMeta, { color: theme.text2 }]}>{s.followers || 0}</Text>
                </View>
              </View>
              <Text style={{ color: ORANGE, fontWeight: '700' }}>›</Text>
            </TouchableOpacity>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  searchBar: { flexDirection: 'row', alignItems: 'center', padding: 12, paddingTop: 52, borderBottomWidth: 1, gap: 8 },
  backBtn: { padding: 4 },
  backTxt: { fontSize: 22, color: ORANGE },
  input: { flex: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10, fontSize: 15 },
  clearBtn: { padding: 6 },
  clearTxt: { color: '#aaa', fontSize: 16 },
  tabs: { flexDirection: 'row', borderBottomWidth: 1 },
  tab: { flex: 1, paddingVertical: 12, alignItems: 'center', borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabOn: { borderBottomColor: ORANGE },
  tabTxt: { fontSize: 13, fontWeight: '600' },
  historyHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  historyTitle: { fontWeight: '700', fontSize: 14 },
  clearAll: { color: ORANGE, fontSize: 13 },
  historyRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 12, borderBottomWidth: 1 },
  historyTxt: { fontSize: 14 },
  empty: { alignItems: 'center', marginTop: 80 },
  emptyTxt: { fontSize: 16, fontWeight: '700', marginBottom: 6 },
  emptyHint: { fontSize: 13 },
  prodCard: { flex: 1, borderRadius: 14, overflow: 'hidden', marginBottom: 10 },
  prodImg: { height: 130, backgroundColor: '#f8f8f8', alignItems: 'center', justifyContent: 'center' },
  prodName: { fontWeight: '700', fontSize: 12, marginBottom: 3 },
  prodPrice: { color: ORANGE, fontWeight: '700', fontSize: 12, marginBottom: 6 },
  cartBtn: { backgroundColor: ORANGE, borderRadius: 8, padding: 6, alignItems: 'center' },
  cartBtnTxt: { color: '#fff', fontWeight: '700', fontSize: 11 },
  storeCard: { flexDirection: 'row', alignItems: 'center', borderRadius: 14, padding: 14, marginBottom: 10, gap: 12 },
  storeEmoji: { fontSize: 30, width: 44, textAlign: 'center' },
  storeName: { fontWeight: '700', fontSize: 15, marginBottom: 2 },
  storeMeta: { fontSize: 12 },
});
