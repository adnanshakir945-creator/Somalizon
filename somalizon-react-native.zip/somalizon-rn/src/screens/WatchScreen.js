import React, { useEffect, useState, useRef } from 'react';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Dimensions, ActivityIndicator, Alert } from 'react-native';
import { Video } from 'expo-av';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { COLORS } from '../constants/Design';

const P = COLORS.primary;
const { height: H, width: W } = Dimensions.get('window');

function fmtNum(n) { if (!n) return '0'; if (n >= 1000000) return (n/1000000).toFixed(1)+'M'; if (n >= 1000) return (n/1000).toFixed(1)+'K'; return String(n); }

function VideoItem({ item: v, isActive, profile, onLike, onComment }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current) return;
    if (isActive) ref.current.playAsync().catch(()=>{});
    else ref.current.pauseAsync().catch(()=>{});
  }, [isActive]);

  return (
    <View style={styles.videoItem}>
      <Video ref={ref} source={{ uri: v.url }} style={styles.video} resizeMode="cover" shouldPlay={isActive} isLooping isMuted={false} />

      {/* Gradient overlay */}
      <View style={styles.gradient} />

      {/* Info */}
      <View style={styles.overlay}>
        <View style={styles.leftInfo}>
          <View style={styles.userRow}>
            <View style={styles.userAvatar}><Text style={styles.userAvatarTxt}>{(v.user?.[0]||'?').toUpperCase()}</Text></View>
            <Text style={styles.userName}>@{v.user}</Text>
          </View>
          {v.desc && <Text style={styles.videoDesc} numberOfLines={2}>{v.desc}</Text>}
          {v.prodName && (
            <View style={styles.prodTag}>
              <Text style={styles.prodTagTxt}>🛍️ {v.prodName}</Text>
            </View>
          )}
        </View>

        {/* Right actions */}
        <View style={styles.rightActions}>
          <TouchableOpacity style={styles.actionBtn} onPress={() => onLike(v)}>
            <Text style={styles.actionIco}>❤️</Text>
            <Text style={styles.actionCnt}>{fmtNum(v.likes)}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionBtn} onPress={() => onComment(v)}>
            <Text style={styles.actionIco}>💬</Text>
            <Text style={styles.actionCnt}>{fmtNum(v.comments)}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionBtn}>
            <Text style={styles.actionIco}>↗️</Text>
            <Text style={styles.actionCnt}>Share</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

export default function WatchScreen({ navigation }) {
  const { profile } = useAuth();
  const [videos, setVideos]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeIdx, setActiveIdx] = useState(0);

  useEffect(() => {
    loadVideos();
    const ch = supabase.channel('watch-feed')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'videos' }, payload => {
        if (payload.eventType === 'INSERT') setVideos(prev => [payload.new, ...prev]);
        if (payload.eventType === 'UPDATE') setVideos(prev => prev.map(v => v.id === payload.new.id ? { ...v, ...payload.new } : v));
        if (payload.eventType === 'DELETE') setVideos(prev => prev.filter(v => v.id !== payload.old.id));
      })
      .subscribe();
    return () => supabase.removeChannel(ch);
  }, []);

  async function loadVideos() {
    const { data } = await supabase.from('videos').select('*').order('created_at', { ascending: false });
    setVideos(data || []); setLoading(false);
  }

  async function handleLike(v) {
    if (!profile) { Alert.alert('⚠️', 'Marka hore soo gal'); return; }
    const newLikes = (v.likes || 0) + 1;
    setVideos(prev => prev.map(vid => vid.id === v.id ? { ...vid, likes: newLikes } : vid));
    await supabase.from('videos').update({ likes: newLikes }).eq('id', v.id);
    await supabase.from('video_interactions').upsert({ video_id: v.id, user_email: profile.email, type: 'like' });
  }

  if (loading) return (
    <View style={styles.center}>
      <ActivityIndicator color={P} size="large" />
    </View>
  );

  if (!videos.length) return (
    <View style={styles.center}>
      <Text style={{ fontSize: 56, marginBottom: 16 }}>🎬</Text>
      <Text style={{ color: '#fff', fontSize: 16, fontWeight: '700' }}>Video ma jiro weli</Text>
    </View>
  );

  return (
    <View style={styles.wrap}>
      {/* Header overlay */}
      <View style={styles.header}>
        <Text style={styles.headerTitle}>🎬 Watch</Text>
        <View style={styles.headerRight}>
          <TouchableOpacity style={styles.headerBtn} onPress={() => navigation.navigate('WatchSearch')}>
            <Text style={{ fontSize: 18 }}>🔍</Text>
          </TouchableOpacity>
          {profile?.user_type === 'seller' && (
            <TouchableOpacity style={[styles.headerBtn, styles.headerBtnOrange]} onPress={() => navigation.navigate('UploadVideo')}>
              <Text style={{ fontSize: 18 }}>➕</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      <FlatList
        data={videos} keyExtractor={v => String(v.id)}
        pagingEnabled snapToInterval={H} decelerationRate="fast"
        showsVerticalScrollIndicator={false}
        onViewableItemsChanged={({ viewableItems }) => { if (viewableItems.length > 0) setActiveIdx(viewableItems[0].index); }}
        viewabilityConfig={{ itemVisiblePercentThreshold: 80 }}
        renderItem={({ item, index }) => (
          <VideoItem
            item={item} isActive={index === activeIdx} profile={profile}
            onLike={handleLike}
            onComment={v => navigation.navigate('Comments', { videoId: v.id, videoDesc: v.desc })}
          />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#000' },
  center: { flex: 1, backgroundColor: '#000', alignItems: 'center', justifyContent: 'center' },
  header: { position: 'absolute', top: 0, left: 0, right: 0, zIndex: 99, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 52, paddingBottom: 12 },
  headerTitle: { color: '#fff', fontSize: 20, fontWeight: '900', letterSpacing: -0.3, textShadowColor: 'rgba(0,0,0,0.5)', textShadowRadius: 8 },
  headerRight: { flexDirection: 'row', gap: 8 },
  headerBtn: { width: 38, height: 38, borderRadius: 12, backgroundColor: 'rgba(0,0,0,0.4)', alignItems: 'center', justifyContent: 'center' },
  headerBtnOrange: { backgroundColor: P },
  videoItem: { width: W, height: H, position: 'relative' },
  video: { width: '100%', height: '100%' },
  gradient: { position: 'absolute', bottom: 0, left: 0, right: 0, height: H * 0.55, backgroundColor: 'transparent',
    // Simple gradient-like using shadow
  },
  overlay: { position: 'absolute', bottom: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'flex-end', padding: 16, paddingBottom: 100 },
  leftInfo: { flex: 1, marginRight: 12 },
  userRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  userAvatar: { width: 36, height: 36, borderRadius: 18, backgroundColor: P, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff' },
  userAvatarTxt: { color: '#fff', fontWeight: '800', fontSize: 14 },
  userName: { color: '#fff', fontWeight: '800', fontSize: 15, textShadowColor: 'rgba(0,0,0,0.6)', textShadowRadius: 6 },
  videoDesc: { color: '#eee', fontSize: 13, lineHeight: 18, marginBottom: 8, textShadowColor: 'rgba(0,0,0,0.6)', textShadowRadius: 6 },
  prodTag: { backgroundColor: P, paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20, alignSelf: 'flex-start' },
  prodTagTxt: { color: '#fff', fontWeight: '700', fontSize: 12 },
  rightActions: { alignItems: 'center', gap: 20 },
  actionBtn: { alignItems: 'center' },
  actionIco: { fontSize: 30 },
  actionCnt: { color: '#fff', fontSize: 11, fontWeight: '700', marginTop: 3, textShadowColor: 'rgba(0,0,0,0.6)', textShadowRadius: 6 },
});
