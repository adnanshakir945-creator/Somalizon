import React, { useState, useRef } from 'react';
import {
  View, Text, TextInput, FlatList, TouchableOpacity, StyleSheet,
  ActivityIndicator, Dimensions,
} from 'react-native';
import { Video } from 'expo-av';
import { supabase } from '../lib/supabase';
import { useTheme } from '../contexts/ThemeContext';

const ORANGE = '#FF6B00';
const { width: W } = Dimensions.get('window');
const THUMB_W = (W - 36) / 2;

export default function WatchSearchScreen({ navigation }) {
  const { theme } = useTheme();
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const debounceRef = useRef(null);

  function handleChange(text) {
    setQuery(text);
    clearTimeout(debounceRef.current);
    if (!text.trim()) { setResults([]); return; }
    debounceRef.current = setTimeout(() => doSearch(text.trim()), 400);
  }

  async function doSearch(q) {
    setLoading(true);
    const { data } = await supabase
      .from('videos')
      .select('*')
      .or(`desc.ilike.%${q}%,user.ilike.%${q}%,prodName.ilike.%${q}%`)
      .limit(30);
    setResults(data || []);
    setLoading(false);
  }

  function renderItem({ item: v }) {
    return (
      <TouchableOpacity
        style={[styles.card, { backgroundColor: theme.card, width: THUMB_W }]}
        onPress={() => navigation.navigate('Comments', { videoId: v.id, videoDesc: v.desc })}
      >
        <Video
          source={{ uri: v.url }}
          style={styles.thumb}
          resizeMode="cover"
          shouldPlay={false}
          isMuted
        />
        <View style={styles.cardBody}>
          <Text style={[styles.user, { color: theme.text }]}>👤 {v.user}</Text>
          <Text style={[styles.desc, { color: theme.text2 }]} numberOfLines={2}>{v.desc}</Text>
          <Text style={[styles.stats, { color: theme.text2 }]}>❤️ {v.likes || 0} · 💬 {v.comments || 0}</Text>
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.bar, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Text style={styles.back}>←</Text></TouchableOpacity>
        <TextInput
          style={[styles.input, { backgroundColor: theme.input, color: theme.inputText }]}
          placeholder="🔍 Video raadi..." placeholderTextColor="#999"
          value={query} onChangeText={handleChange}
          autoFocus returnKeyType="search"
        />
      </View>

      {loading && <ActivityIndicator color={ORANGE} style={{ marginTop: 30 }} />}

      {!loading && query.trim() && results.length === 0 && (
        <View style={styles.empty}>
          <Text style={{ fontSize: 46, marginBottom: 12 }}>🎬</Text>
          <Text style={[styles.emptyTxt, { color: theme.text2 }]}>"{query}" video lama helin</Text>
        </View>
      )}

      {!query.trim() && (
        <View style={styles.empty}>
          <Text style={{ fontSize: 46, marginBottom: 12 }}>🔍</Text>
          <Text style={[styles.emptyTxt, { color: theme.text2 }]}>Video raadi</Text>
        </View>
      )}

      <FlatList
        data={results} keyExtractor={v => String(v.id)}
        numColumns={2} columnWrapperStyle={{ gap: 12 }}
        contentContainerStyle={{ padding: 12 }}
        renderItem={renderItem}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  bar: { flexDirection: 'row', alignItems: 'center', padding: 12, paddingTop: 52, borderBottomWidth: 1, gap: 8 },
  back: { fontSize: 22, color: ORANGE },
  input: { flex: 1, borderRadius: 12, paddingHorizontal: 14, paddingVertical: 10, fontSize: 15 },
  card: { borderRadius: 12, overflow: 'hidden', marginBottom: 12 },
  thumb: { width: '100%', height: 140 },
  cardBody: { padding: 8 },
  user: { fontWeight: '700', fontSize: 12, marginBottom: 2 },
  desc: { fontSize: 11, lineHeight: 15, marginBottom: 4 },
  stats: { fontSize: 11 },
  empty: { alignItems: 'center', marginTop: 80 },
  emptyTxt: { fontSize: 15 },
});
