import React, { useEffect, useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, Alert, ActivityIndicator, Linking, Platform,
} from 'react-native';
import * as StoreReview from 'expo-store-review';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';

const ORANGE = '#FF6B00';

export default function SettingsScreen({ navigation }) {
  const { profile, signOut, refreshProfile } = useAuth();
  const { theme, isDark, toggleDark } = useTheme();
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [city, setCity] = useState('');
  const [evcNum, setEvcNum] = useState('');
  const [zaadNum, setZaadNum] = useState('');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (profile) {
      setPhone(profile.phone || '');
      setAddress(profile.address || '');
      setCity(profile.city || '');
      setEvcNum(profile.evc_number || '');
      setZaadNum(profile.zaad_number || '');
    }
  }, [profile]);

  async function saveSettings() {
    if (!profile) return;
    setSaving(true);
    const { data: user } = await supabase.auth.getUser();
    const { error } = await supabase.from('profiles').update({
      phone, address, city, evc_number: evcNum, zaad_number: zaadNum,
    }).eq('id', user.user.id);
    setSaving(false);
    if (!error) {
      setSaved(true);
      await refreshProfile();
      setTimeout(() => setSaved(false), 2000);
    } else {
      Alert.alert('⚠️ Khalad', error.message);
    }
  }

  async function rateApp() {
    if (await StoreReview.hasAction()) {
      await StoreReview.requestReview();
    } else {
      const url = Platform.OS === 'ios'
        ? 'https://apps.apple.com/app/somalizon/id0000000000'
        : 'market://details?id=com.somalizon.app';
      Linking.openURL(url).catch(() => Alert.alert('⚠️', 'App store kuma furi karin'));
    }
  }

  function openSupport() {
    Linking.openURL('https://wa.me/252XXXXXXXXX?text=Caawimo%20baan%20u%20baahan%20ahay')
      .catch(() => Alert.alert('⚠️', 'WhatsApp lama furi karin'));
  }

  function Section({ title, children }) {
    return (
      <View style={[styles.section, { backgroundColor: theme.card }]}>
        <Text style={[styles.sectionTitle, { color: theme.text2 }]}>{title}</Text>
        {children}
      </View>
    );
  }

  function Row({ label, emoji, onPress, danger = false }) {
    return (
      <TouchableOpacity style={[styles.row, { borderBottomColor: theme.border }]} onPress={onPress}>
        <Text style={styles.rowEmoji}>{emoji}</Text>
        <Text style={[styles.rowLabel, { color: danger ? '#ef4444' : theme.text }]}>{label}</Text>
        <Text style={{ color: theme.text2 }}>›</Text>
      </TouchableOpacity>
    );
  }

  return (
    <ScrollView style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Text style={styles.back}>←</Text></TouchableOpacity>
        <Text style={[styles.title, { color: theme.text }]}>⚙️ Dejinta</Text>
        <View style={{ width: 30 }} />
      </View>

      {/* Address Book */}
      <Section title="📍 CINWAANKA IYO XIRIIRKA">
        <TextInput style={[styles.input, { backgroundColor: theme.bg, color: theme.inputText }]} placeholder="📞 Telefoon" placeholderTextColor="#999" keyboardType="phone-pad" value={phone} onChangeText={setPhone} />
        <TextInput style={[styles.input, { backgroundColor: theme.bg, color: theme.inputText }]} placeholder="🏙️ Magaalada" placeholderTextColor="#999" value={city} onChangeText={setCity} />
        <TextInput style={[styles.input, { backgroundColor: theme.bg, color: theme.inputText }]} placeholder="🏠 Cinwaanka (Xaafad, Guri No.)" placeholderTextColor="#999" value={address} onChangeText={setAddress} />
      </Section>

      {/* Payment Numbers */}
      <Section title="💳 LAMBARKA LACAG BIXINTA">
        <TextInput style={[styles.input, { backgroundColor: theme.bg, color: theme.inputText }]} placeholder="💳 EVC Plus Number (063...)" placeholderTextColor="#999" keyboardType="phone-pad" value={evcNum} onChangeText={setEvcNum} />
        <TextInput style={[styles.input, { backgroundColor: theme.bg, color: theme.inputText }]} placeholder="📱 Zaad Number (063...)" placeholderTextColor="#999" keyboardType="phone-pad" value={zaadNum} onChangeText={setZaadNum} />
      </Section>

      <TouchableOpacity style={[styles.saveBtn, saved && styles.savedBtn]} onPress={saveSettings} disabled={saving}>
        {saving ? <ActivityIndicator color="#fff" /> : <Text style={styles.saveBtnTxt}>{saved ? '✅ La Keydiay!' : '💾 Kaydi Dejinta'}</Text>}
      </TouchableOpacity>

      {/* Preferences */}
      <Section title="🎨 MUUQAALKA">
        <TouchableOpacity style={[styles.row, { borderBottomColor: theme.border }]} onPress={toggleDark}>
          <Text style={styles.rowEmoji}>{isDark ? '☀️' : '🌙'}</Text>
          <Text style={[styles.rowLabel, { color: theme.text }]}>{isDark ? 'Muuqaallka Ifka' : 'Muuqaalka Madow'}</Text>
          <View style={[styles.toggle, isDark && styles.toggleOn]}>
            <View style={[styles.toggleBall, isDark && styles.toggleBallOn]} />
          </View>
        </TouchableOpacity>
      </Section>

      {/* More */}
      <Section title="📱 KALE">
        <Row emoji="⭐" label="App-ka Qiimee" onPress={rateApp} />
        <Row emoji="💬" label="Caawimaad Codso" onPress={openSupport} />
        <Row emoji="👥" label="Asxaabta" onPress={() => navigation.navigate('Asxaabta')} />
        <Row emoji="❤️" label="Rabitaanka" onPress={() => navigation.navigate('Wishlist')} />
        <Row emoji="⭐" label="Qiimayntayda" onPress={() => navigation.navigate('ReviewsPage')} />
      </Section>

      <Section title="🔐 ACCOUNT">
        <Row emoji="🚪" label="Ka Bixi" onPress={() => Alert.alert('Ka bixi', 'Ma hubtaa?', [
          { text: 'Maya', style: 'cancel' },
          { text: 'Haa', style: 'destructive', onPress: signOut }
        ])} danger />
      </Section>

      <View style={{ height: 40 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52, borderBottomWidth: 1 },
  back: { fontSize: 24, color: ORANGE },
  title: { fontSize: 17, fontWeight: '700' },
  section: { marginHorizontal: 14, marginBottom: 14, borderRadius: 16, overflow: 'hidden', paddingHorizontal: 14 },
  sectionTitle: { fontSize: 11, fontWeight: '700', paddingTop: 14, paddingBottom: 6, letterSpacing: 0.5 },
  input: { borderRadius: 10, padding: 12, marginBottom: 10, fontSize: 14 },
  saveBtn: { backgroundColor: ORANGE, marginHorizontal: 14, padding: 15, borderRadius: 14, alignItems: 'center', marginBottom: 16 },
  savedBtn: { backgroundColor: '#22c55e' },
  saveBtnTxt: { color: '#fff', fontWeight: '700', fontSize: 15 },
  row: { flexDirection: 'row', alignItems: 'center', paddingVertical: 14, borderBottomWidth: 1 },
  rowEmoji: { fontSize: 18, marginRight: 12 },
  rowLabel: { flex: 1, fontSize: 15 },
  toggle: { width: 46, height: 26, borderRadius: 13, backgroundColor: '#ddd', padding: 2, justifyContent: 'center' },
  toggleOn: { backgroundColor: ORANGE },
  toggleBall: { width: 22, height: 22, borderRadius: 11, backgroundColor: '#fff' },
  toggleBallOn: { alignSelf: 'flex-end' },
});
