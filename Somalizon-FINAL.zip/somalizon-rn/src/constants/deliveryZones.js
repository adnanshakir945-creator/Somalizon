// Very simple zone-based delivery pricing. Muqdisho (where most sellers
// are) is cheapest since it's usually same-city delivery; everywhere else
// costs more to reflect inter-city transport. Sellers/admins can tune
// these numbers later — the point is the fee is no longer a guess, it's
// looked up from the buyer's chosen city.

export const DELIVERY_ZONES = {
  'Muqdisho':    { fee: 15000,  label: 'Gudaha Muqdisho' },
  'Afgooye':     { fee: 25000,  label: 'Agagaarka Muqdisho' },
  'Jowhar':      { fee: 35000,  label: 'Gobolka Dhexe' },
  'Beledweyne':  { fee: 45000,  label: 'Gobolka Dhexe' },
  'Baydhabo':    { fee: 45000,  label: 'Gobolka Koonfureed' },
  'Kismaayo':    { fee: 55000,  label: 'Gobolka Koonfureed' },
  'Hargeysa':    { fee: 55000,  label: 'Woqooyiga' },
  'Berbera':     { fee: 60000,  label: 'Woqooyiga' },
  'Boosaaso':    { fee: 60000,  label: 'Bari' },
  'Gaalkacyo':   { fee: 50000,  label: 'Dhexe/Bari' },
};

const DEFAULT_FEE = 50000; // used for any city not in the table above

export function deliveryFeeFor(city) {
  if (!city) return 0;
  return DELIVERY_ZONES[city]?.fee ?? DEFAULT_FEE;
}
