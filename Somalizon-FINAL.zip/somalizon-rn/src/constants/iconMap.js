// Central place that turns either an old emoji character (data saved before
// this update) or a new Ionicons name (data saved after this update) into a
// valid Ionicons name we can render with <Ionicons name={...} />.
// This lets existing products/stores in the database keep working while
// everything new uses real icons instead of emoji.

export const LEGACY_EMOJI_TO_ICON = {
  '📦': 'cube-outline',
  '👗': 'shirt-outline',
  '👟': 'footsteps-outline',
  '📱': 'phone-portrait-outline',
  '💄': 'color-palette-outline',
  '🏠': 'home-outline',
  '⚽': 'football-outline',
  '🍕': 'pizza-outline',
  '🎮': 'game-controller-outline',
  '📚': 'book-outline',
  '🌿': 'leaf-outline',
  '💎': 'diamond-outline',
  '🏪': 'storefront-outline',
  '🛍️': 'bag-handle-outline',
  '🛍': 'bag-handle-outline',
  '❤️': 'heart',
  '❤': 'heart',
  '⭐': 'star',
  '👥': 'people-outline',
  '⚙️': 'settings-outline',
  '⚙': 'settings-outline',
  '🚪': 'log-out-outline',
  '➕': 'add',
  '📹': 'videocam-outline',
  '💬': 'chatbubble-outline',
  '💰': 'cash-outline',
  '🛒': 'cart-outline',
  '🔥': 'flame-outline',
  '🚀': 'rocket-outline',
  '💳': 'card-outline',
};

// Product/store category icon picker — replaces the old EMOJIS array.
export const CATEGORY_ICONS = [
  'cube-outline', 'shirt-outline', 'footsteps-outline', 'phone-portrait-outline',
  'color-palette-outline', 'home-outline', 'football-outline', 'pizza-outline',
  'game-controller-outline', 'book-outline', 'leaf-outline', 'diamond-outline',
];

const KNOWN_IONICONS_NAMES = new Set([...CATEGORY_ICONS, 'storefront-outline']);

// Accepts whatever is stored (legacy emoji OR icon name) and always
// returns something safe to pass to <Ionicons name={...} />.
export function toIconName(value, fallback = 'cube-outline') {
  if (!value) return fallback;
  if (LEGACY_EMOJI_TO_ICON[value]) return LEGACY_EMOJI_TO_ICON[value];
  if (KNOWN_IONICONS_NAMES.has(value)) return value;
  // Looks like an icon name already (e.g. "storefront-outline")
  if (/^[a-z0-9-]+$/i.test(value)) return value;
  return fallback;
}
