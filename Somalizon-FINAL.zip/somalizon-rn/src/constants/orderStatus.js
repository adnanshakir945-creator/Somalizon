// Canonical order-status pipeline used everywhere in the app.
// Keeping this in one place means the buyer tracker, the seller
// update screen, and the dashboard badges can never drift apart.

export const ORDER_STATUSES = [
  { key: 'La Diray',       label: 'La Diray',        icon: 'receipt-outline',        color: '#FF6B00' },
  { key: 'Diyaarinta',     label: 'Diyaarinaya',      icon: 'cube-outline',           color: '#2563eb' },
  { key: 'Socota',         label: 'Wadada Ku Socota', icon: 'bicycle-outline',        color: '#a855f7' },
  { key: 'La Dhiibay',     label: 'La Dhiibay',       icon: 'checkmark-circle-outline', color: '#22c55e' },
];

export const CANCELLED_STATUS = { key: 'La Joojiyay', label: 'La Joojiyay', icon: 'close-circle-outline', color: '#ef4444' };

// Returns the 0-based index of a status within the normal flow, or -1
// if it's cancelled / unknown (so the tracker can render it specially).
export function statusIndex(status) {
  return ORDER_STATUSES.findIndex(s => s.key === status);
}

export function statusMeta(status) {
  if (status === CANCELLED_STATUS.key) return CANCELLED_STATUS;
  return ORDER_STATUSES.find(s => s.key === status) || ORDER_STATUSES[0];
}

export function statusColor(status) {
  return statusMeta(status).color;
}

// What a seller is allowed to move an order to next (used to build the
// action buttons on the seller order-management screen).
export function nextStatuses(current) {
  if (current === CANCELLED_STATUS.key) return [];
  const idx = statusIndex(current);
  const options = [];
  if (idx >= 0 && idx < ORDER_STATUSES.length - 1) options.push(ORDER_STATUSES[idx + 1]);
  if (idx >= 0 && idx < ORDER_STATUSES.length - 1) options.push(CANCELLED_STATUS);
  return options;
}
