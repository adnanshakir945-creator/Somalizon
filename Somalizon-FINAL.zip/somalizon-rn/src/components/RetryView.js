import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export default function RetryView({ message = 'Wax lama soo gelin karin. Fiiri xiriirkaaga internet-ka.', onRetry, textColor }) {
  return (
    <View style={styles.wrap}>
      <Ionicons name="cloud-offline-outline" size={44} color={'#999'} />
      <Text style={[styles.msg, textColor && { color: textColor }]}>{message}</Text>
      <TouchableOpacity style={styles.btn} onPress={onRetry}>
        <Ionicons name="refresh-outline" size={15} color="#fff" />
        <Text style={styles.btnTxt}>Isku Day Mar Kale</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { alignItems: 'center', justifyContent: 'center', paddingVertical: 60, paddingHorizontal: 30 },
  msg: { fontSize: 13, color: '#888', textAlign: 'center', marginTop: 12, marginBottom: 18, lineHeight: 19 },
  btn: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: '#FF6B00', paddingHorizontal: 18, paddingVertical: 11, borderRadius: 12 },
  btnTxt: { color: '#fff', fontWeight: '700', fontSize: 13 },
});
