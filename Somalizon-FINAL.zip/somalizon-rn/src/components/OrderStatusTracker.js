import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { ORDER_STATUSES, CANCELLED_STATUS, statusIndex } from '../constants/orderStatus';

// A horizontal 4-step tracker: La Diray -> Diyaarinta -> Socota -> La Dhiibay.
// If the order was cancelled, we show a single cancelled banner instead.
export default function OrderStatusTracker({ status, textColor, mutedColor }) {
  if (status === CANCELLED_STATUS.key) {
    return (
      <View style={styles.cancelledRow}>
        <Ionicons name={CANCELLED_STATUS.icon} size={16} color={CANCELLED_STATUS.color} />
        <Text style={[styles.cancelledTxt, { color: CANCELLED_STATUS.color }]}>Dalabka waa la joojiyay</Text>
      </View>
    );
  }

  const activeIdx = Math.max(statusIndex(status), 0);

  return (
    <View style={styles.wrap}>
      {ORDER_STATUSES.map((s, i) => {
        const done = i <= activeIdx;
        const isLast = i === ORDER_STATUSES.length - 1;
        return (
          <View key={s.key} style={styles.stepWrap}>
            <View style={styles.stepCol}>
              <View style={[styles.dot, done && { backgroundColor: s.color, borderColor: s.color }]}>
                <Ionicons name={s.icon} size={13} color={done ? '#fff' : (mutedColor || '#bbb')} />
              </View>
              <Text
                style={[styles.stepLabel, { color: done ? textColor : (mutedColor || '#999') }, done && { fontWeight: '700' }]}
                numberOfLines={2}
              >
                {s.label}
              </Text>
            </View>
            {!isLast && <View style={[styles.line, i < activeIdx && { backgroundColor: ORDER_STATUSES[i + 1].color }]} />}
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flexDirection: 'row', alignItems: 'flex-start', paddingVertical: 6 },
  stepWrap: { flex: 1, flexDirection: 'row', alignItems: 'flex-start' },
  stepCol: { alignItems: 'center', width: 70 },
  dot: {
    width: 28, height: 28, borderRadius: 14, borderWidth: 2, borderColor: '#ddd',
    backgroundColor: '#eee', alignItems: 'center', justifyContent: 'center', marginBottom: 5,
  },
  stepLabel: { fontSize: 10, textAlign: 'center', lineHeight: 13 },
  line: { flex: 1, height: 2, backgroundColor: '#ddd', marginTop: 13, marginHorizontal: -4 },
  cancelledRow: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingVertical: 8 },
  cancelledTxt: { fontWeight: '700', fontSize: 13 },
});
