import React, { useRef } from 'react';
import { Ionicons } from '@expo/vector-icons';
import {
  Modal, View, Image, TouchableOpacity, StyleSheet,
  Dimensions, StatusBar, PanResponder, Animated,
} from 'react-native';

const { width: W, height: H } = Dimensions.get('window');

export default function ImageViewer({ uri, visible, onClose }) {
  const scale = useRef(new Animated.Value(1)).current;
  const lastScale = useRef(1);

  const pinchRef = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onPanResponderGrant: () => { lastScale.current = scale.__getValue(); },
      onPanResponderMove: (e, { numberActiveTouches }) => {
        if (numberActiveTouches === 2) {
          const { touches } = e.nativeEvent;
          const dx = touches[0].pageX - touches[1].pageX;
          const dy = touches[0].pageY - touches[1].pageY;
          const dist = Math.sqrt(dx * dx + dy * dy);
          // Basic scale — in production use react-native-gesture-handler
          const newScale = Math.min(4, Math.max(1, lastScale.current * (dist / 200)));
          scale.setValue(newScale);
        }
      },
      onPanResponderRelease: () => {
        lastScale.current = scale.__getValue();
        if (lastScale.current < 1.1) {
          Animated.spring(scale, { toValue: 1, useNativeDriver: true }).start();
          lastScale.current = 1;
        }
      },
    })
  ).current;

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <StatusBar hidden />
      <View style={styles.wrap}>
        <TouchableOpacity style={styles.closeBtn} onPress={onClose}>
          <View style={styles.closeCircle}><Ionicons name="close" size={22} color="#fff" /></View>
        </TouchableOpacity>
        <Animated.View style={[styles.imgWrap, { transform: [{ scale }] }]} {...pinchRef.panHandlers}>
          <Image source={{ uri }} style={styles.img} resizeMode="contain" />
        </Animated.View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: 'rgba(0,0,0,0.95)', alignItems: 'center', justifyContent: 'center' },
  closeBtn: { position: 'absolute', top: 52, right: 16, zIndex: 10 },
  closeCircle: { width: 36, height: 36, borderRadius: 18, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  imgWrap: { width: W, height: H * 0.8 },
  img: { width: '100%', height: '100%' },
});
