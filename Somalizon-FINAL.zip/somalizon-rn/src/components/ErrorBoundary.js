import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

// Wraps the whole app. If any screen throws during render, React Native
// would otherwise show a blank/red screen with no way back — this catches
// it and gives the user a "Isku day mar kale" button that resets the tree.
export default class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  static getDerivedStateFromError() {
    return { hasError: true };
  }

  componentDidCatch(error, info) {
    console.log('ErrorBoundary caught:', error?.message || error, info?.componentStack);
  }

  handleRetry = () => {
    this.setState({ hasError: false });
  };

  render() {
    if (this.state.hasError) {
      return (
        <View style={styles.wrap}>
          <Ionicons name="alert-circle-outline" size={64} color="#FF6B00" />
          <Text style={styles.title}>Wax baa qaldamay</Text>
          <Text style={styles.sub}>
            Waxaa dhacday cilad lama filaan ah. Isku day mar kale — haddii ay sii socoto, laga bilaab app-ka.
          </Text>
          <TouchableOpacity style={styles.btn} onPress={this.handleRetry}>
            <Ionicons name="refresh-outline" size={16} color="#fff" />
            <Text style={styles.btnTxt}>Isku Day Mar Kale</Text>
          </TouchableOpacity>
        </View>
      );
    }
    return this.props.children;
  }
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', padding: 32 },
  title: { fontSize: 18, fontWeight: '800', color: '#222', marginTop: 18, textAlign: 'center' },
  sub: { fontSize: 13, color: '#666', marginTop: 10, textAlign: 'center', lineHeight: 20 },
  btn: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#FF6B00', paddingHorizontal: 20, paddingVertical: 12, borderRadius: 14, marginTop: 28 },
  btnTxt: { color: '#fff', fontWeight: '700', fontSize: 14 },
});
