import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useNetwork } from '../contexts/NetworkContext';

export default function OfflineBanner() {
  const { isOnline } = useNetwork();
  if (isOnline) return null;

  return (
    <View style={styles.wrap}>
      <Ionicons name="cloud-offline-outline" size={14} color="#fff" />
      <Text style={styles.txt}>Internet ma jiro — fiiri xiriirkaaga</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6,
    backgroundColor: '#ef4444', paddingTop: 50, paddingBottom: 8,
  },
  txt: { color: '#fff', fontWeight: '700', fontSize: 12 },
});
