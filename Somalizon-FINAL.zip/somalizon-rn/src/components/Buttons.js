import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator, View } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, SHADOWS, R } from '../constants/Design';

const P = COLORS.primary;

export function PrimaryBtn({ label, onPress, loading, disabled, style, icon }) {
  return (
    <TouchableOpacity
      style={[styles.primary, disabled && styles.disabled, SHADOWS.orange, style]}
      onPress={onPress} disabled={loading || disabled} activeOpacity={0.85}
    >
      {loading
        ? <ActivityIndicator color="#fff" />
        : <View style={styles.row}>
            {icon && <Ionicons name={icon} size={18} color="#fff" />}
            <Text style={styles.primaryTxt}>{label}</Text>
          </View>
      }
    </TouchableOpacity>
  );
}

export function SecondaryBtn({ label, onPress, style, icon }) {
  return (
    <TouchableOpacity style={[styles.secondary, style]} onPress={onPress} activeOpacity={0.8}>
      <View style={styles.row}>
        {icon && <Ionicons name={icon} size={18} color={P} />}
        <Text style={styles.secondaryTxt}>{label}</Text>
      </View>
    </TouchableOpacity>
  );
}

export function GhostBtn({ label, onPress, style, color = P }) {
  return (
    <TouchableOpacity style={[styles.ghost, { borderColor: color }, style]} onPress={onPress} activeOpacity={0.8}>
      <Text style={[styles.ghostTxt, { color }]}>{label}</Text>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  primary: { backgroundColor: P, borderRadius: R.xl, padding: 16, alignItems: 'center' },
  primaryTxt: { color: '#fff', fontWeight: '800', fontSize: 15, letterSpacing: 0.2 },
  disabled: { backgroundColor: COLORS.text3 },
  secondary: { backgroundColor: COLORS.primaryPale, borderRadius: R.xl, padding: 15, alignItems: 'center' },
  secondaryTxt: { color: P, fontWeight: '700', fontSize: 15 },
  ghost: { borderWidth: 1.5, borderRadius: R.xl, padding: 14, alignItems: 'center' },
  ghostTxt: { fontWeight: '700', fontSize: 14 },
  row: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  icon: { fontSize: 18 },
});
