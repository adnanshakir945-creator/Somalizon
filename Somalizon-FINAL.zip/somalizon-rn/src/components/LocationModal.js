import React, { useState } from 'react';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  Modal, KeyboardAvoidingView, Platform, ScrollView, Alert,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { deliveryFeeFor } from '../constants/deliveryZones';

const ORANGE = '#FF6B00';

const CITIES = ['Muqdisho', 'Hargeysa', 'Berbera', 'Kismaayo', 'Baydhabo', 'Boosaaso', 'Gaalkacyo', 'Jowhar', 'Afgooye', 'Beledweyne'];

function Row({ icon, text, theme }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 6, gap: 6 }}>
      <Ionicons name={icon} size={14} color={theme.text} />
      <Text style={[styles.label, { color: theme.text, marginBottom: 0 }]}>{text}</Text>
    </View>
  );
}

export default function LocationModal({ visible, onClose, onSave, initialData = {} }) {
  const { profile } = useAuth();
  const { theme } = useTheme();
  const [name, setName] = useState(initialData.name || '');
  const [phone, setPhone] = useState(initialData.phone || '');
  const [city, setCity] = useState(initialData.city || '');
  const [district, setDistrict] = useState(initialData.district || '');
  const [details, setDetails] = useState(initialData.details || '');
  const [saving, setSaving] = useState(false);

  async function handleSave() {
    if (!phone.trim()) { Alert.alert('Digniin', 'Telefoonka gali'); return; }
    if (!city.trim()) { Alert.alert('Digniin', 'Magaalada dooro'); return; }
    setSaving(true);
    const addressData = {
      name: name || profile?.name, phone: phone.trim(), city, district: district.trim(), details: details.trim(),
      deliveryFee: deliveryFeeFor(city),
    };

    // Optionally save to profile for future use
    if (profile?.id) {
      await supabase.from('profiles').update({ saved_address: addressData }).eq('id', profile.id).then(() => {});
    }

    onSave(addressData);
    setSaving(false);
    onClose();
  }

  return (
    <Modal visible={visible} animationType="slide" transparent onRequestClose={onClose}>
      <KeyboardAvoidingView style={styles.overlay} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <View style={[styles.sheet, { backgroundColor: theme.card }]}>
          <View style={styles.handle} />
          <View style={styles.titleRow}>
            <Ionicons name="location-outline" size={18} color={theme.text} />
            <Text style={[styles.title, { color: theme.text, marginBottom: 0, marginLeft: 6 }]}>Cinwaanka Gaarsiinta</Text>
          </View>

          <ScrollView showsVerticalScrollIndicator={false}>
            <Text style={[styles.label, { color: theme.text }]}>Magacaaga</Text>
            <TextInput style={[styles.input, { backgroundColor: theme.bg, color: theme.inputText }]} placeholder="Magacaaga dhabta ah" placeholderTextColor="#999" value={name} onChangeText={setName} />

            <Row icon="call-outline" text="Telefoonka *" theme={theme} />
            <TextInput style={[styles.input, { backgroundColor: theme.bg, color: theme.inputText }]} placeholder="063XXXXXXX" placeholderTextColor="#999" keyboardType="phone-pad" value={phone} onChangeText={setPhone} />

            <Row icon="business-outline" text="Magaalada *" theme={theme} />
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 6 }}>
              {CITIES.map(c => (
                <TouchableOpacity key={c} style={[styles.cityChip, city === c && styles.cityChipOn]} onPress={() => setCity(c)}>
                  <Text style={[styles.cityTxt, city === c && styles.cityTxtOn]}>{c}</Text>
                </TouchableOpacity>
              ))}
            </ScrollView>
            {city ? (
              <View style={styles.feeRow}>
                <Ionicons name="bicycle-outline" size={13} color={ORANGE} />
                <Text style={styles.feeTxt}>Kharashka gaarsiinta: Sh.So {deliveryFeeFor(city).toLocaleString()}</Text>
              </View>
            ) : null}

            <Row icon="map-outline" text="Xaafadda" theme={theme} />
            <TextInput style={[styles.input, { backgroundColor: theme.bg, color: theme.inputText }]} placeholder="Xaafadda / District" placeholderTextColor="#999" value={district} onChangeText={setDistrict} />

            <Row icon="home-outline" text="Faahfaahinta" theme={theme} />
            <TextInput style={[styles.input, { backgroundColor: theme.bg, color: theme.inputText, height: 80 }]} placeholder="Guriyaha lambarku, jidka, calaamad..." placeholderTextColor="#999" multiline value={details} onChangeText={setDetails} />

            <View style={styles.btnRow}>
              <TouchableOpacity style={styles.cancelBtn} onPress={onClose}>
                <Text style={styles.cancelTxt}>Ka noqo</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveBtn} onPress={handleSave} disabled={saving}>
                {saving
                  ? <Text style={styles.saveTxt}>...</Text>
                  : <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                      <Ionicons name="checkmark-circle-outline" size={16} color="#fff" />
                      <Text style={styles.saveTxt}>Xaqiiji</Text>
                    </View>}
              </TouchableOpacity>
            </View>
          </ScrollView>
        </View>
      </KeyboardAvoidingView>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: { flex: 1, justifyContent: 'flex-end', backgroundColor: 'rgba(0,0,0,0.5)' },
  sheet: { borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: '90%' },
  handle: { width: 40, height: 4, backgroundColor: '#ddd', borderRadius: 2, alignSelf: 'center', marginBottom: 16 },
  title: { fontSize: 18, fontWeight: '800', marginBottom: 20, textAlign: 'center' },
  titleRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  label: { fontWeight: '700', fontSize: 13, marginBottom: 6 },
  input: { borderRadius: 12, padding: 12, marginBottom: 14, fontSize: 14 },
  cityChip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: '#f0f0f0', marginRight: 8 },
  cityChipOn: { backgroundColor: ORANGE },
  cityTxt: { fontSize: 13, fontWeight: '600', color: '#666' },
  cityTxtOn: { color: '#fff' },
  feeRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 14 },
  feeTxt: { color: ORANGE, fontWeight: '700', fontSize: 12 },
  btnRow: { flexDirection: 'row', gap: 12, marginTop: 8, marginBottom: 20 },
  cancelBtn: { flex: 1, padding: 14, borderRadius: 14, alignItems: 'center', borderWidth: 1, borderColor: '#ddd' },
  cancelTxt: { fontWeight: '600', color: '#666' },
  saveBtn: { flex: 2, padding: 14, borderRadius: 14, alignItems: 'center', backgroundColor: ORANGE },
  saveTxt: { color: '#fff', fontWeight: '800', fontSize: 15 },
});
