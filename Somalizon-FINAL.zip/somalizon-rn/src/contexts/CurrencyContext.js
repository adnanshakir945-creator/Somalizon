import React, { createContext, useContext, useEffect, useState } from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';

const CurrencyCtx = createContext(null);
const STORAGE_KEY = 'currency_pref';

// Approximate market rate — Sh.So per 1 USD. Sellers/admins list prices in
// Sh.So (the app's native currency); this is only used to show a USD
// estimate for buyers who think in dollars. Update this number as the
// real exchange rate moves.
const DEFAULT_RATE = 570;

export function CurrencyProvider({ children }) {
  const [currency, setCurrencyState] = useState('SOS'); // 'SOS' | 'USD'
  const [rate] = useState(DEFAULT_RATE);

  useEffect(() => {
    AsyncStorage.getItem(STORAGE_KEY).then(v => { if (v === 'USD' || v === 'SOS') setCurrencyState(v); });
  }, []);

  function setCurrency(c) {
    setCurrencyState(c);
    AsyncStorage.setItem(STORAGE_KEY, c);
  }

  // sosAmount is always the source-of-truth number stored in the DB.
  function formatPrice(sosAmount) {
    const n = Number(sosAmount) || 0;
    if (currency === 'USD') {
      return `$${(n / rate).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
    }
    return `Sh.So ${n.toLocaleString()}`;
  }

  return (
    <CurrencyCtx.Provider value={{ currency, setCurrency, rate, formatPrice }}>
      {children}
    </CurrencyCtx.Provider>
  );
}

export const useCurrency = () => useContext(CurrencyCtx);
