import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { supabase } from '../lib/supabase';
import { useAuth } from './AuthContext';
import { navigate, navigationRef } from '../navigation/navigationRef';

const RealtimeCtx = createContext(null);

export function RealtimeProvider({ children }) {
  const { profile } = useAuth();
  const [products, setProducts] = useState([]);
  const [stores, setStores] = useState([]);
  const [productsError, setProductsError] = useState(false);
  const [storesError, setStoresError] = useState(false);
  const [chatUnread, setChatUnread] = useState(0);
  const [newOrder, setNewOrder] = useState(null); // seller gets notified
  const channels = useRef([]);

  useEffect(() => {
    startProductSync();
    startStoreSync();
    if (profile?.email) {
      startChatSync(profile.email);
      startIncomingCallSync(profile.email);
      if (profile.user_type === 'seller') startSellerOrderSync(profile.email);
    }
    return () => channels.current.forEach(c => supabase.removeChannel(c));
  }, [profile?.email]);

  // ─── Products real-time ─────────────────────────────────
  async function startProductSync() {
    const { data, error } = await supabase.from('products').select('*').order('created_at', { ascending: false });
    setProductsError(!!error && !data);
    setProducts(data || []);

    const ch = supabase.channel('global-products')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'products' }, ({ new: row }) => {
        setProducts(prev => [row, ...prev]);
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'products' }, ({ new: row }) => {
        setProducts(prev => prev.map(p => p.id === row.id ? row : p));
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'products' }, ({ old: row }) => {
        setProducts(prev => prev.filter(p => p.id !== row.id));
      })
      .subscribe();
    channels.current.push(ch);
  }

  // ─── Stores real-time ────────────────────────────────────
  async function startStoreSync() {
    const { data, error } = await supabase.from('stores').select('*').eq('verified', true).order('followers', { ascending: false });
    setStoresError(!!error && !data);
    setStores(data || []);

    const ch = supabase.channel('global-stores')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'stores' }, () => {
        supabase.from('stores').select('*').order('followers', { ascending: false })
          .then(({ data }) => setStores(data || []));
      })
      .subscribe();
    channels.current.push(ch);
  }

  // ─── Chat unread count real-time ────────────────────────
  function startChatSync(email) {
    const myEmail = email.toLowerCase().trim();
    const ch = supabase.channel('global-chats-' + myEmail)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'chats' }, ({ new: row }) => {
        const participants = row.participantEmails || [];
        if (!participants.includes(myEmail)) return;
        if (row.lastSenderEmail !== myEmail) {
          setChatUnread(prev => prev + 1);
        }
      })
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, ({ new: row }) => {
        if (row.senderEmail !== myEmail) {
          setChatUnread(prev => prev + 1);
        }
      })
      .subscribe();
    channels.current.push(ch);
  }

  // ─── Incoming call listener (global) ────────────────────
  // Watches the 'calls' table app-wide for new rows where I'm the callee, and
  // pushes the Call screen with isIncoming:true — without this, the callee
  // never finds out someone is calling them.
  function startIncomingCallSync(email) {
    const myEmail = email.toLowerCase().trim();
    const ch = supabase.channel('incoming-calls-' + myEmail)
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'calls',
        filter: `calleeEmail=eq.${myEmail}`,
      }, async ({ new: row }) => {
        if (row.status !== 'ringing') return;
        // Don't hijack the screen if we're already on a call somehow.
        if (navigationRef.isReady() && navigationRef.getCurrentRoute()?.name === 'Call') return;

        const { data: callerProfile } = await supabase
          .from('profiles').select('name').eq('email', row.callerEmail).maybeSingle();

        navigate('Call', {
          isIncoming: true,
          incomingCallId: row.id,
          otherEmail: row.callerEmail,
          otherName: callerProfile?.name || row.callerEmail.split('@')[0],
        });
      })
      .subscribe();
    channels.current.push(ch);
  }

  // ─── Seller order alerts real-time ──────────────────────
  function startSellerOrderSync(email) {
    const ch = supabase.channel('seller-orders-' + email)
      .on('postgres_changes', {
        event: 'INSERT', schema: 'public', table: 'orders',
        filter: `sellerEmail=eq.${email}`,
      }, ({ new: row }) => {
        setNewOrder(row);
      })
      .subscribe();
    channels.current.push(ch);
  }

  function clearChatUnread() { setChatUnread(0); }
  function clearNewOrder() { setNewOrder(null); }

  return (
    <RealtimeCtx.Provider value={{
      products, stores, chatUnread, newOrder,
      productsError, storesError,
      retryProducts: startProductSync, retryStores: startStoreSync,
      clearChatUnread, clearNewOrder,
    }}>
      {children}
    </RealtimeCtx.Provider>
  );
}

export const useRealtime = () => useContext(RealtimeCtx);
