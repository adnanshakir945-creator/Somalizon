import React, { createContext, useContext, useEffect, useState } from 'react';
import NetInfo from '@react-native-community/netinfo';

const NetworkCtx = createContext({ isOnline: true });

export function NetworkProvider({ children }) {
  const [isOnline, setIsOnline] = useState(true);

  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      // isConnected can be null briefly on some Android devices while the
      // radio is switching networks — treat null as "still online" so we
      // don't flash the offline banner on every wifi handoff.
      setIsOnline(state.isConnected !== false);
    });
    return () => unsubscribe();
  }, []);

  return (
    <NetworkCtx.Provider value={{ isOnline }}>
      {children}
    </NetworkCtx.Provider>
  );
}

export const useNetwork = () => useContext(NetworkCtx);
