import React, { useEffect, useState, useCallback } from 'react';
import { Ionicons } from '@expo/vector-icons';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  Image, ActivityIndicator, RefreshControl, Alert,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { useTheme } from '../contexts/ThemeContext';
import { toIconName } from '../constants/iconMap';
import { useToast } from '../components/Toast';

const ORANGE = '#FF6B00';

export default function WishlistScreen({ navigation }) {
  const { profile } = useAuth();
  const { addToCart } = useCart();
  const { theme } = useTheme();
  const showToast = useToast();
  const [wishlist, setWishlist] = useState([]);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { loadWishlist(); }, []);

  async function loadWishlist() {
    setLoading(true);
    const { data: user } = await supabase.auth.getUser();
    if (!user?.user) { setLoading(false); return; }
    const { data: prof } = await supabase.from('profiles').select('wishlist').eq('id', user.user.id).maybeSingle();
    const ids = prof?.wishlist || [];
    setWishlist(ids);
    if (ids.length) {
      const { data: prods } = await supabase.from('products').select('*').in('id', ids);
      setProducts(prods || []);
    } else {
      setProducts([]);
    }
    setLoading(false);
  }

  async function removeFromWishlist(prodId) {
    const { data: user } = await supabase.auth.getUser();
    if (!user?.user) return;
    const newList = wishlist.filter(id => id !== prodId);
    setWishlist(newList);
    setProducts(prev => prev.filter(p => p.id !== prodId));
    await supabase.from('profiles').update({ wishlist: newList }).eq('id', user.user.id);
  }

  const onRefresh = useCallback(async () => { setRefreshing(true); await loadWishlist(); setRefreshing(false); }, []);

  function renderItem({ item: p }) {
    return (
      <TouchableOpacity
        style={[styles.card, { backgroundColor: theme.card }]}
        onPress={() => navigation.navigate('ProductDetail', { product: p })}
      >
        <View style={styles.imgBox}>
          {p.img
            ? <Image source={{ uri: p.img }} style={styles.img} resizeMode="cover" />
            : <Ionicons name={toIconName(p.emoji)} size={40} color={'#333'} />
          }
          <TouchableOpacity style={styles.heartBtn} onPress={() => Alert.alert('Ka saar?', p.name, [
            { text: 'Maya', style: 'cancel' },
            { text: 'Haa', onPress: () => removeFromWishlist(p.id) }
          ])}>
            <Ionicons name="heart" size={18} color={'#333'} />
          </TouchableOpacity>
        </View>
        <View style={styles.info}>
          <Text style={[styles.name, { color: theme.text }]} numberOfLines={2}>{p.name}</Text>
          <View style={styles.rowLine}><Ionicons name="person-outline" size={12} color={theme.text2} /><Text style={[styles.seller, { color: theme.text2, marginLeft: 4 }]}>{p.seller}</Text></View>
          <Text style={[styles.price, { color: ORANGE }]}>Sh.So {(p.price || 0).toLocaleString()}</Text>
          <TouchableOpacity style={styles.cartBtn} onPress={() => { addToCart(p); showToast('Kaydiyaha lagu daray!', 'success'); }}>
            <View style={styles.rowLine}><Ionicons name="cart-outline" size={14} color="#fff" /><Text style={[styles.cartBtnTxt, { marginLeft: 6 }]}>Basket Ku Dar</Text></View>
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="chevron-back" size={20} color={'#333'} /></TouchableOpacity>
        <View style={styles.rowLine}><Ionicons name="heart" size={16} color={theme.text} /><Text style={[styles.title, { color: theme.text, marginLeft: 6 }]}>Rabitaanka ({wishlist.length})</Text></View>
        <View style={{ width: 30 }} />
      </View>

      {loading ? <ActivityIndicator color={ORANGE} style={{ marginTop: 40 }} /> : (
        <FlatList
          data={products} keyExtractor={p => String(p.id)}
          numColumns={2} columnWrapperStyle={{ gap: 10 }}
          contentContainerStyle={{ padding: 12 }}
          renderItem={renderItem}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={ORANGE} />}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="heart" size={56} color={'#333'} />
              <Text style={[styles.emptyTxt, { color: theme.text2 }]}>Wax alaab ah oo kaydsan ma jirto</Text>
              <TouchableOpacity style={styles.shopBtn} onPress={() => navigation.navigate('Home')}>
                <View style={styles.rowLine}><Ionicons name="bag-handle-outline" size={15} color="#fff" /><Text style={[styles.shopBtnTxt, { marginLeft: 6 }]}>Alaab Raadi</Text></View>
              </TouchableOpacity>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  rowLine: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center' },
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52, borderBottomWidth: 1 },
  back: { fontSize: 24, color: ORANGE },
  title: { fontSize: 17, fontWeight: '700' },
  card: { flex: 1, borderRadius: 16, overflow: 'hidden', marginBottom: 10, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 },
  imgBox: { height: 140, backgroundColor: '#f8f8f8', alignItems: 'center', justifyContent: 'center', position: 'relative' },
  img: { width: '100%', height: '100%' },
  emoji: { fontSize: 46 },
  heartBtn: { position: 'absolute', top: 6, right: 6 },
  info: { padding: 10 },
  name: { fontWeight: '700', fontSize: 13, marginBottom: 3 },
  seller: { fontSize: 11, marginBottom: 3 },
  price: { fontWeight: '800', fontSize: 14, marginBottom: 8 },
  cartBtn: { backgroundColor: ORANGE, padding: 8, borderRadius: 8, alignItems: 'center' },
  cartBtnTxt: { color: '#fff', fontWeight: '700', fontSize: 12 },
  empty: { alignItems: 'center', marginTop: 80 },
  emptyTxt: { fontSize: 15, marginBottom: 20 },
  shopBtn: { backgroundColor: ORANGE, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 14 },
  shopBtnTxt: { color: '#fff', fontWeight: '700' },
});
