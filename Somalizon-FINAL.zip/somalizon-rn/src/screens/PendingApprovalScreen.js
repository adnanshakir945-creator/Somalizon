import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../contexts/AuthContext';

const ORANGE = '#FF6B00';

export default function PendingApprovalScreen({ rejected }) {
  const { signOut, refreshProfile } = useAuth();
  return (
    <View style={styles.wrap}>
      <View style={styles.iconBox}>
        <Ionicons name={rejected ? 'close-circle-outline' : 'time-outline'} size={44} color={rejected ? '#ef4444' : ORANGE} />
      </View>
      <Text style={styles.title}>
        {rejected ? 'Codsigaaga Ganacsi Waa La Diiday' : 'Codsigaaga Waa La Eegayaa'}
      </Text>
      <Text style={styles.sub}>
        {rejected
          ? 'Maamulka Somalizon ma ogolaan codsigaaga inaad ganacsade noqoto. Haddii aad aaminsan tahay in tani khalad tahay, nala soo xiriir taageerada.'
          : 'Account-kaaga ganacsadenimo weli waa la eegayaa maamulka Somalizon. Marka la ogolaado, waxaad awoodi doontaa inaad alaab gelisid oo aad iibisid. Tani caadi ahaan waxay qaadataa ilaa 24-48 saacadood.'}
      </Text>
      <TouchableOpacity style={styles.refreshBtn} onPress={refreshProfile}>
        <Ionicons name="refresh-outline" size={16} color={ORANGE} />
        <Text style={styles.refreshTxt}>Hubi Xaaladda</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.btn} onPress={signOut}>
        <Ionicons name="log-out-outline" size={16} color="#fff" />
        <Text style={styles.btnTxt}>Ka Bixi</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', padding: 32 },
  iconBox: { width: 88, height: 88, borderRadius: 28, backgroundColor: '#FFF6F0', alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  title: { fontSize: 18, fontWeight: '800', color: '#222', textAlign: 'center' },
  sub: { fontSize: 13, color: '#666', marginTop: 10, textAlign: 'center', lineHeight: 20 },
  refreshBtn: { flexDirection: 'row', alignItems: 'center', gap: 8, borderWidth: 1.5, borderColor: ORANGE, paddingHorizontal: 20, paddingVertical: 12, borderRadius: 14, marginTop: 28 },
  refreshTxt: { color: ORANGE, fontWeight: '700', fontSize: 14 },
  btn: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#999', paddingHorizontal: 20, paddingVertical: 12, borderRadius: 14, marginTop: 14 },
  btnTxt: { color: '#fff', fontWeight: '700', fontSize: 14 },
});
