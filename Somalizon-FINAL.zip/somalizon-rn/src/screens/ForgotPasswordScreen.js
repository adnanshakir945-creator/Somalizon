import React, { useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { COLORS, SHADOWS, R } from '../constants/Design';
import { PrimaryBtn } from '../components/Buttons';
import { useToast } from '../components/Toast';

const P = COLORS.primary;

export default function ForgotPasswordScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);
  const [loading, setLoading] = useState(false);
  const showToast = useToast();

  async function sendReset() {
    if (!email.trim()) { showToast('Email gali', 'error'); return; }
    setLoading(true);
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), {
      redirectTo: 'somalizon://reset-password',
    });
    setLoading(false);
    if (error) { showToast(error.message, 'error'); return; }
    setSent(true);
  }

  return (
    <KeyboardAvoidingView style={styles.wrap} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
        <Ionicons name="chevron-back" size={20} color={'#333'} />
      </TouchableOpacity>

      <View style={styles.content}>
        <View style={styles.iconBox}>
          <Ionicons name="key-outline" size={32} color={P} />
        </View>

        {!sent ? (
          <>
            <Text style={styles.title}>Password Ma Iloowday?</Text>
            <Text style={styles.sub}>Geli email-kaaga, waxaan kuu soo dirraynaa link aad ku bedeli karto password-kaaga.</Text>

            <View style={styles.inputWrap}>
              <Ionicons name="mail-outline" size={20} color={'#333'} />
              <TextInput
                style={styles.input} placeholder="Email address"
                placeholderTextColor={COLORS.text3} autoCapitalize="none"
                keyboardType="email-address" value={email} onChangeText={setEmail}
              />
            </View>

            <PrimaryBtn label="Dir Link-ga Reset-ka" icon="paper-plane-outline" onPress={sendReset} loading={loading} style={{ marginTop: 8 }} />
          </>
        ) : (
          <>
            <Text style={styles.title}>Email-ka Waa La Diray!</Text>
            <Text style={styles.sub}>Hubi sanduuqa email-kaaga ({email.trim()}) — waxaad ka heli doontaa link aad ku bedeli karto password-kaaga cusub.</Text>
            <TouchableOpacity style={styles.backLoginBtn} onPress={() => navigation.navigate('Login')}>
              <Text style={styles.backLoginTxt}>Ku Noqo Login-ka</Text>
            </TouchableOpacity>
          </>
        )}
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#fff' },
  backBtn: { marginTop: 54, marginLeft: 16, width: 38, height: 38, borderRadius: 13, backgroundColor: COLORS.input, alignItems: 'center', justifyContent: 'center' },
  content: { flex: 1, padding: 24, paddingTop: 30 },
  iconBox: { width: 64, height: 64, borderRadius: 20, backgroundColor: COLORS.primaryPale, alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  title: { fontSize: 22, fontWeight: '900', color: COLORS.text, marginBottom: 8 },
  sub: { fontSize: 14, color: COLORS.text2, lineHeight: 20, marginBottom: 24 },
  inputWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.input, borderRadius: R.lg, borderWidth: 1.5, borderColor: COLORS.inputBorder, paddingHorizontal: 14, marginBottom: 20 },
  input: { flex: 1, paddingVertical: 15, fontSize: 15, color: COLORS.text, marginLeft: 10 },
  backLoginBtn: { alignItems: 'center', marginTop: 10 },
  backLoginTxt: { color: P, fontWeight: '800', fontSize: 15 },
});
