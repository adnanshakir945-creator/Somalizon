import React, { useEffect, useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Image, ActivityIndicator, Alert } from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { COLORS, SHADOWS, R } from '../constants/Design';
import { PrimaryBtn, GhostBtn } from '../components/Buttons';
import { toIconName } from '../constants/iconMap';
import { useToast } from '../components/Toast';

const P = COLORS.primary;

function fmtCount(n) {
  n = n || 0;
  if (n >= 1000000) return (n / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'k';
  return String(n);
}

export default function UserProfileScreen({ route, navigation }) {
  const { email, name } = route.params;
  const { profile }     = useAuth();
  const [userProf, setUserProf] = useState(null);
  const [videos, setVideos]     = useState([]);
  const [products, setProducts] = useState([]);
  const [followerCount, setFollowerCount] = useState(0);
  const [followed, setFollowed] = useState(false);
  const [blocked, setBlocked]   = useState(false);
  const [loading, setLoading]   = useState(true);
  const [tab, setTab]           = useState('products');
  const showToast = useToast();

  useEffect(() => { loadData(); }, [email]);

  async function loadData() {
    setLoading(true);
    const [profRes, followRes, videosRes, productsRes, followerCountRes] = await Promise.all([
      supabase.from('profiles').select('*').eq('email', email).maybeSingle(),
      profile?.email ? supabase.from('follows').select('id').eq('user_email', profile.email).eq('seller_email', email).maybeSingle() : Promise.resolve({ data: null }),
      supabase.from('videos').select('*').eq('userEmail', email).order('created_at', { ascending: false }),
      supabase.from('products').select('*').eq('sellerEmail', email).order('created_at', { ascending: false }),
      supabase.from('follows').select('id', { count: 'exact', head: true }).eq('seller_email', email),
    ]);
    setUserProf(profRes.data);
    setFollowed(!!followRes.data);
    setVideos(videosRes.data || []);
    setProducts(productsRes.data || []);
    setFollowerCount(followerCountRes.count || 0);
    setTab((productsRes.data || []).length > 0 ? 'products' : 'videos');
    if (profile?.blocked_users) setBlocked(profile.blocked_users.includes(email));
    setLoading(false);
  }

  async function toggleBlock() {
    if (!profile?.id) return;
    const current = profile.blocked_users || [];
    const now = blocked ? current.filter(e => e !== email) : [...current, email];
    const { error } = await supabase.from('profiles').update({ blocked_users: now }).eq('id', profile.id);
    if (error) { showToast(error.message, 'error'); return; }
    setBlocked(!blocked);
    showToast(blocked ? 'Xannibaaddii waa laga saaray' : `${displayName} waa la xannibay — mar dambe kuma soo dari doono`, 'success');
  }

  function reportUser() {
    Alert.alert('Sheeg Isticmaalahan', 'Waa maxay sababta?', [
      { text: 'Faragelin/Cabsi Gelin', onPress: () => sendUserReport('harassment') },
      { text: 'Been-abuur/Khiyaano', onPress: () => sendUserReport('fraud') },
      { text: 'Fariimo Xun', onPress: () => sendUserReport('inappropriate') },
      { text: 'Ka Noqo', style: 'cancel' },
    ]);
  }

  async function sendUserReport(reason) {
    if (!profile?.email) { showToast('Marka hore soo gal', 'error'); return; }
    const { error } = await supabase.from('reports').insert({
      reportedUserEmail: email, reportedUserName: displayName,
      reporterEmail: profile.email, reporterName: profile.name, reason, status: 'pending',
    });
    if (error) showToast(error.message, 'error');
    else showToast('Waad ku mahadsan tahay — waan eegi doonaa.', 'success');
  }

  async function toggleFollow() {
    if (!profile?.email) return;
    if (followed) {
      await supabase.from('follows').delete().eq('user_email', profile.email).eq('seller_email', email);
      setFollowed(false);
    } else {
      await supabase.from('follows').upsert({ user_email: profile.email, seller_email: email });
      setFollowed(true);
    }
  }

  function openChat() {
    if (!profile?.email) return;
    const chatId = [profile.email.toLowerCase(), email.toLowerCase()].sort().join('__');
    navigation.navigate('ChatRoom', { chat: { id: chatId, participantEmails: [profile.email, email] }, otherName: displayName, otherEmail: email });
  }

  if (loading) return <View style={styles.center}><ActivityIndicator color={P} size="large" /></View>;

  const displayName = userProf?.name || name || email.split('@')[0];
  const isSeller    = userProf?.user_type === 'seller';
  const isMe        = profile?.email?.toLowerCase() === email.toLowerCase();

  return (
    <ScrollView style={styles.wrap} showsVerticalScrollIndicator={false}>
      {/* Orange header */}
      <View style={styles.headerBand}>
        <View style={styles.waveBg} />
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={20} color={'#333'} />
        </TouchableOpacity>
        {!isMe && (
          <TouchableOpacity
            style={styles.menuBtn}
            onPress={() => Alert.alert('Isticmaalahan', undefined, [
              { text: blocked ? 'Ka Saar Xannibaadda' : 'Xannib Isticmaalahan', onPress: toggleBlock, style: blocked ? 'default' : 'destructive' },
              { text: 'Sheeg Isticmaalahan', onPress: reportUser, style: 'destructive' },
              { text: 'Ka Noqo', style: 'cancel' },
            ])}
          >
            <Ionicons name="ellipsis-horizontal" size={18} color={'#333'} />
          </TouchableOpacity>
        )}
        {userProf?.profile_image
          ? <Image source={{ uri: userProf.profile_image }} style={styles.avatar} />
          : <View style={styles.avatarDefault}><Text style={styles.avatarTxt}>{displayName[0]?.toUpperCase() || '?'}</Text></View>
        }
        <Text style={styles.userName}>{displayName}</Text>
        {isSeller && userProf?.shop_name && <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Ionicons name="storefront-outline" size={13} color={styles.shopName.color} /><Text style={styles.shopName}>{userProf.shop_name}</Text></View>}
        <Text style={styles.userEmail}>{email}</Text>
        <View style={[styles.typeBadge, { backgroundColor: isSeller ? 'rgba(255,255,255,0.25)' : 'rgba(255,255,255,0.15)' }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Ionicons name={isSeller ? 'storefront-outline' : 'bag-handle-outline'} size={12} color={styles.typeTxt.color} /><Text style={styles.typeTxt}>{isSeller ? 'Ganacsade' : 'Macmiil'}</Text></View>
        </View>

        {/* Stats row */}
        <View style={styles.statsRow}>
          <View style={styles.statItem}><Text style={styles.statNum}>{fmtCount(products.length + videos.length)}</Text><Text style={styles.statLbl}>Wax lagu daray</Text></View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}><Text style={styles.statNum}>{fmtCount(followerCount)}</Text><Text style={styles.statLbl}>Raaciyayaal</Text></View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}><Text style={styles.statNum}>{fmtCount(videos.reduce((s, v) => s + (v.likes || 0), 0))}</Text><Text style={styles.statLbl}>Jecel</Text></View>
        </View>
      </View>

      {/* Action buttons */}
      {!isMe && !blocked && (
        <View style={styles.actionRow}>
          <TouchableOpacity style={[styles.followBtn, followed && styles.followedBtn, SHADOWS.orange]} onPress={toggleFollow}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}><Ionicons name={followed ? 'checkmark' : 'add'} size={13} color={styles.followTxt.color} /><Text style={styles.followTxt}>{followed ? 'Following' : 'Follow'}</Text></View>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.msgBtn, SHADOWS.sm]} onPress={openChat}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Ionicons name="chatbubble-outline" size={14} color={styles.msgTxt.color} /><Text style={styles.msgTxt}>Xariir</Text></View>
          </TouchableOpacity>
        </View>
      )}
      {blocked && (
        <View style={styles.blockedNotice}>
          <Ionicons name="ban-outline" size={16} color={'#ef4444'} />
          <Text style={styles.blockedTxt}>Waad xannibtay isticmaalahan</Text>
          <TouchableOpacity onPress={toggleBlock}><Text style={styles.unblockLink}>Ka saar</Text></TouchableOpacity>
        </View>
      )}

      {/* Tab bar: Alaabta (grid) / Muuqaallo (play) */}
      {(products.length > 0 || videos.length > 0) && (
        <>
          <View style={styles.tabBar}>
            <TouchableOpacity style={[styles.tabBtn, tab === 'products' && styles.tabBtnOn]} onPress={() => setTab('products')}>
              <Ionicons name="grid-outline" size={20} color={tab === 'products' ? P : COLORS.text3} />
            </TouchableOpacity>
            <TouchableOpacity style={[styles.tabBtn, tab === 'videos' && styles.tabBtnOn]} onPress={() => setTab('videos')}>
              <Ionicons name="play-outline" size={20} color={tab === 'videos' ? P : COLORS.text3} />
            </TouchableOpacity>
          </View>

          {tab === 'products' && (
            <View style={styles.gridWrap}>
              {products.length === 0
                ? <Text style={styles.emptyTxt}>Alaab lama gelin weli</Text>
                : (
                  <View style={styles.postsGrid}>
                    {products.map((p) => (
                      <TouchableOpacity
                        key={p.id} style={styles.gridCell}
                        onPress={() => navigation.navigate('ProductDetail', { product: p })}
                      >
                        {p.img
                          ? <Image source={{ uri: p.img }} style={styles.gridImg} />
                          : <View style={[styles.gridImg, styles.gridImgFallback]}><Ionicons name={toIconName(p.emoji)} size={30} color={'#666'} /></View>
                        }
                        <View style={styles.gridPriceTag}>
                          <Text style={styles.gridPriceTxt}>Sh.So {(p.price || 0).toLocaleString()}</Text>
                        </View>
                      </TouchableOpacity>
                    ))}
                  </View>
                )
              }
            </View>
          )}

          {tab === 'videos' && (
            <View style={styles.gridWrap}>
              {videos.length === 0
                ? <Text style={styles.emptyTxt}>Video lama soo dejin weli</Text>
                : (
                  <View style={styles.postsGrid}>
                    {videos.map((v, i) => (
                      <TouchableOpacity
                        key={v.id} style={styles.gridCell}
                        onPress={() => navigation.navigate('ProfileVideoViewer', { userEmail: email, userName: displayName, startIndex: i })}
                      >
                        <View style={[styles.gridImg, styles.videoDark]}>
                          <Ionicons name="play" size={22} color="#fff" style={{ position: 'absolute', top: 8, right: 8 }} />
                          <View style={styles.videoLikesTag}>
                            <Ionicons name="heart" size={11} color="#fff" />
                            <Text style={styles.videoLikesTxt}>{fmtCount(v.likes || 0)}</Text>
                          </View>
                        </View>
                      </TouchableOpacity>
                    ))}
                  </View>
                )
              }
            </View>
          )}
        </>
      )}

      {/* Info */}
      <View style={styles.section}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="information-circle-outline" size={15} color={styles.secTitle.color} /><Text style={styles.secTitle}>Macluumaad</Text></View>
        {[
          ['Nooca', isSeller ? 'Ganacsade' : 'Macmiil'],
          isSeller && userProf?.shop_name ? ['Dukaanka', userProf.shop_name] : null,
        ].filter(Boolean).map(([label, val]) => (
          <View key={label} style={styles.infoRow}>
            <Text style={styles.infoLabel}>{label}</Text>
            <Text style={styles.infoVal}>{val}</Text>
          </View>
        ))}
      </View>
      <View style={{ height: 24 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#fff' },
  headerBand: { backgroundColor: P, paddingTop: 54, paddingBottom: 28, alignItems: 'center', borderBottomLeftRadius: 32, borderBottomRightRadius: 32, overflow: 'hidden', marginBottom: 16 },
  waveBg: { position: 'absolute', width: 320, height: 320, borderRadius: 160, backgroundColor: 'rgba(255,255,255,0.08)', top: -80, right: -40 },
  backBtn: { position: 'absolute', top: 54, left: 16, width: 38, height: 38, borderRadius: 13, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  menuBtn: { position: 'absolute', top: 54, right: 16, width: 38, height: 38, borderRadius: 13, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  backTxt: { color: '#fff', fontSize: 22, fontWeight: '700', lineHeight: 26 },
  avatar: { width: 88, height: 88, borderRadius: 28, marginBottom: 12, borderWidth: 3, borderColor: 'rgba(255,255,255,0.4)' },
  avatarDefault: { width: 88, height: 88, borderRadius: 28, backgroundColor: 'rgba(255,255,255,0.25)', alignItems: 'center', justifyContent: 'center', marginBottom: 12, borderWidth: 3, borderColor: 'rgba(255,255,255,0.4)' },
  avatarTxt: { color: '#fff', fontSize: 36, fontWeight: '900' },
  userName: { fontSize: 22, fontWeight: '900', color: '#fff', letterSpacing: -0.3, marginBottom: 4 },
  shopName: { color: 'rgba(255,255,255,0.8)', fontSize: 13, marginBottom: 4 },
  userEmail: { color: 'rgba(255,255,255,0.65)', fontSize: 12, marginBottom: 10 },
  typeBadge: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: R.full },
  typeTxt: { color: '#fff', fontWeight: '700', fontSize: 13 },
  actionRow: { flexDirection: 'row', gap: 12, paddingHorizontal: 16, marginBottom: 16 },
  followBtn: { flex: 1, backgroundColor: P, padding: 14, borderRadius: R.xl, alignItems: 'center' },
  followedBtn: { backgroundColor: COLORS.success },
  followTxt: { color: '#fff', fontWeight: '800', fontSize: 14 },
  msgBtn: { flex: 1, backgroundColor: '#fff', padding: 14, borderRadius: R.xl, alignItems: 'center' },
  msgTxt: { fontWeight: '700', color: COLORS.text, fontSize: 14 },
  section: { backgroundColor: '#fff', marginHorizontal: 16, borderRadius: R.xl, padding: 16, marginBottom: 12, ...SHADOWS.card },
  secHeader: { marginBottom: 12 },
  secTitle: { fontWeight: '800', fontSize: 15, color: COLORS.text },
  videosGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  videoThumb: { width: (COLORS.card ? 100 : 100), flex: 1, minWidth: '30%' },
  videoPlaceholder: { height: 90, backgroundColor: COLORS.primaryPale, borderRadius: R.lg, alignItems: 'center', justifyContent: 'center', marginBottom: 5 },
  videoDesc: { fontSize: 11, color: COLORS.text2, fontWeight: '600', marginBottom: 2 },
  videoMeta: { fontSize: 10, color: COLORS.text3 },
  infoRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 10, borderTopWidth: 1, borderTopColor: COLORS.border },
  infoLabel: { color: COLORS.text2, fontSize: 13 },
  infoVal: { fontWeight: '700', color: COLORS.text, fontSize: 13 },

  // Stats row (posts / followers / likes)
  statsRow: { flexDirection: 'row', alignItems: 'center', marginTop: 16, backgroundColor: 'rgba(255,255,255,0.14)', borderRadius: R.xl, paddingVertical: 12, paddingHorizontal: 10, width: '86%' },
  statItem: { flex: 1, alignItems: 'center' },
  statNum: { color: '#fff', fontWeight: '900', fontSize: 17 },
  statLbl: { color: 'rgba(255,255,255,0.75)', fontSize: 11, marginTop: 2 },
  statDivider: { width: 1, height: 26, backgroundColor: 'rgba(255,255,255,0.25)' },

  // Tab bar
  tabBar: { flexDirection: 'row', backgroundColor: '#fff', marginHorizontal: 16, borderRadius: R.xl, marginBottom: 2, ...SHADOWS.card },
  tabBtn: { flex: 1, alignItems: 'center', paddingVertical: 12, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabBtnOn: { borderBottomColor: P },

  // Grid (products / videos)
  gridWrap: { paddingHorizontal: 16, paddingTop: 10 },
  postsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  gridCell: { width: '31.5%' },
  gridImg: { width: '100%', aspectRatio: 0.8, borderRadius: R.md, backgroundColor: COLORS.primaryPale },
  gridImgFallback: { alignItems: 'center', justifyContent: 'center' },
  gridPriceTag: { position: 'absolute', bottom: 6, left: 6, right: 6, backgroundColor: 'rgba(0,0,0,0.55)', borderRadius: 6, paddingVertical: 3, paddingHorizontal: 6 },
  gridPriceTxt: { color: '#fff', fontSize: 10, fontWeight: '700' },
  videoDark: { backgroundColor: '#1a1a1a', justifyContent: 'flex-end' },
  videoLikesTag: { flexDirection: 'row', alignItems: 'center', gap: 3, position: 'absolute', bottom: 6, left: 6 },
  videoLikesTxt: { color: '#fff', fontSize: 10, fontWeight: '700' },
  emptyTxt: { textAlign: 'center', color: COLORS.text3, fontSize: 13, paddingVertical: 30 },
  blockedNotice: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#FEE2E2', marginHorizontal: 16, marginBottom: 16, padding: 12, borderRadius: R.lg },
  blockedTxt: { flex: 1, color: '#ef4444', fontWeight: '700', fontSize: 13 },
  unblockLink: { color: '#ef4444', fontWeight: '800', fontSize: 13, textDecorationLine: 'underline' },
});
