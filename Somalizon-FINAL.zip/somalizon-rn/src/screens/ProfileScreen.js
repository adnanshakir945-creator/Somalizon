import React, { useEffect, useState, useCallback } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Image, Alert, RefreshControl, TextInput, ActivityIndicator } from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/Toast';
import { toIconName } from '../constants/iconMap';
import { COLORS, SHADOWS, R } from '../constants/Design';

const P = COLORS.primary;

export default function ProfileScreen({ navigation }) {
  const { profile, signOut, refreshProfile } = useAuth();
  const showToast = useToast();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [editName, setEditName] = useState(false);
  const [nameVal, setNameVal] = useState('');
  const [uploadingImg, setUploadingImg] = useState(false);

  useEffect(() => { loadOrders(); }, [profile]);

  async function loadOrders() {
    if (!profile?.email) { setLoading(false); return; }
    const { data } = await supabase.from('orders').select('*').eq('buyerEmail', profile.email).order('created_at', { ascending: false }).limit(5);
    setOrders(data || []); setLoading(false);
  }

  async function saveName() {
    if (!nameVal.trim() || !profile?.id) return;
    await supabase.from('profiles').update({ name: nameVal.trim() }).eq('id', profile.id);
    await refreshProfile(); setEditName(false);
  }

  async function changePhoto() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { showToast('Fasax sawir', 'error'); return; }
    const res = await ImagePicker.launchImageLibraryAsync({ quality: 0.7, base64: true });
    if (res.canceled || !res.assets?.length) return;
    setUploadingImg(true);
    const asset = res.assets[0];
    const ext = asset.uri.split('.').pop() || 'jpg';
    const path = `profiles/${profile.id}.${ext}`;
    const bytes = Uint8Array.from(atob(asset.base64), c => c.charCodeAt(0));
    const { error } = await supabase.storage.from('profile-images').upload(path, bytes, { contentType: `image/${ext}`, upsert: true });
    if (!error) {
      const { data: url } = supabase.storage.from('profile-images').getPublicUrl(path);
      await supabase.from('profiles').update({ profile_image: url.publicUrl }).eq('id', profile.id);
      await refreshProfile();
    } else {
      showToast(error.message, 'error');
    }
    setUploadingImg(false);
  }

  const onRefresh = useCallback(async () => { setRefreshing(true); await loadOrders(); setRefreshing(false); }, [profile]);

  const BUYER_MENU = [
    { icon: 'cube-outline', label: 'Dalabaadayda', screen: 'OrdersHistory', color: '#FFF0E6' },
    { icon: 'heart', label: 'Rabitaanka', screen: 'Wishlist', color: '#FFF0F0' },
    { icon: 'star', label: 'Qiimayntayda', screen: 'ReviewsPage', color: '#FFFBF0' },
    { icon: 'people-outline', label: 'Asxaabtayda', screen: 'Asxaabta', color: '#F0F4FF' },
    { icon: 'settings-outline', label: 'Dejinta', screen: 'Settings', color: '#F5F5F5' },
  ];

  if (!profile) return <View style={styles.center}><ActivityIndicator color={P} /></View>;

  return (
    <ScrollView style={styles.wrap} showsVerticalScrollIndicator={false}
      refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={P} />}>

      {/* Header orange band */}
      <View style={styles.headerBand}>
        <View style={styles.waveBg} />

        {/* Avatar */}
        <TouchableOpacity style={styles.avatarWrap} onPress={changePhoto}>
          {uploadingImg
            ? <View style={styles.avatar}><ActivityIndicator color={P} /></View>
            : profile.profile_image
              ? <Image source={{ uri: profile.profile_image }} style={styles.avatarImg} />
              : <View style={styles.avatar}><Text style={styles.avatarTxt}>{(profile.name?.[0] || '?').toUpperCase()}</Text></View>
          }
          <View style={styles.cameraBtn}><Ionicons name="camera-outline" size={14} color={'#333'} /></View>
        </TouchableOpacity>

        {/* Name */}
        {editName ? (
          <View style={styles.nameEditRow}>
            <TextInput style={styles.nameInput} value={nameVal} onChangeText={setNameVal} autoFocus onSubmitEditing={saveName} />
            <TouchableOpacity style={styles.nameConfirm} onPress={saveName}><Ionicons name="checkmark" size={20} color={'#fff'} /></TouchableOpacity>
            <TouchableOpacity style={styles.nameCancel} onPress={() => setEditName(false)}><Ionicons name="close" size={20} color={P} /></TouchableOpacity>
          </View>
        ) : (
          <TouchableOpacity style={styles.nameRow} onPress={() => { setNameVal(profile.name || ''); setEditName(true); }}>
            <Text style={styles.profileName}>{profile.name}</Text>
            <Ionicons name="create-outline" size={20} color={'#333'} />
          </TouchableOpacity>
        )}

        <Text style={styles.profileEmail}>{profile.email}</Text>
        <View style={styles.typeBadge}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
          <Ionicons name={profile.user_type === 'seller' ? 'storefront-outline' : 'bag-handle-outline'} size={12} color={styles.typeTxt.color} />
          <Text style={styles.typeTxt}>{profile.user_type === 'seller' ? 'Ganacsade' : 'Macmiil'}</Text>
        </View>
        </View>
      </View>

      {/* Recent orders strip */}
      {orders.length > 0 && (
        <View style={styles.ordersStrip}>
          <View style={styles.stripHeader}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="cube-outline" size={15} color={styles.stripTitle.color} /><Text style={styles.stripTitle}>Dalabaadayda Ugu Dambeeyay</Text></View>
            <TouchableOpacity onPress={() => navigation.navigate('OrdersHistory')} style={{ flexDirection: 'row', alignItems: 'center', gap: 3 }}><Text style={styles.stripSeeAll}>Dhammaan</Text><Ionicons name="chevron-forward" size={12} color={styles.stripSeeAll.color} /></TouchableOpacity>
          </View>
          {orders.slice(0, 3).map(o => (
            <View key={o.id} style={styles.orderRow}>
              <Ionicons name={toIconName(o.prodEmoji)} size={styles.orderEmoji.fontSize || 30} color={'#333'} style={styles.orderEmoji} />
              <View style={{ flex: 1 }}>
                <Text style={styles.orderName} numberOfLines={1}>{o.prodName}</Text>
                <Text style={styles.orderMeta}>x{o.qty} · Sh.So {(o.totalPrice || 0).toLocaleString()}</Text>
              </View>
              <View style={[styles.statusBadge, { backgroundColor: o.status === 'La Dhiibay' ? '#E8FFF5' : COLORS.primaryPale }]}>
                <Text style={[styles.statusTxt, { color: o.status === 'La Dhiibay' ? COLORS.success : P }]}>{o.status || 'La Diray'}</Text>
              </View>
            </View>
          ))}
        </View>
      )}

      {/* Menu */}
      <View style={styles.menu}>
        {BUYER_MENU.map(item => (
          <TouchableOpacity key={item.label} style={styles.menuItem} onPress={() => navigation.navigate(item.screen)} activeOpacity={0.8}>
            <View style={[styles.menuIcon, { backgroundColor: item.color }]}>
              <Ionicons name={item.icon} size={22} color={'#333'} />
            </View>
            <Text style={styles.menuLabel}>{item.label}</Text>
            <Text style={styles.menuArrow}>›</Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Sign out */}
      <TouchableOpacity style={styles.signOutBtn} onPress={signOut}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="log-out-outline" size={16} color={styles.signOutTxt.color} /><Text style={styles.signOutTxt}>Ka Bixi</Text></View>
      </TouchableOpacity>

      <View style={{ height: 100 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  headerBand: { backgroundColor: P, paddingTop: 54, paddingBottom: 28, alignItems: 'center', borderBottomLeftRadius: 32, borderBottomRightRadius: 32, overflow: 'hidden', marginBottom: 16 },
  waveBg: { position: 'absolute', width: 340, height: 340, borderRadius: 170, backgroundColor: 'rgba(255,255,255,0.08)', top: -80, left: -40 },
  avatarWrap: { position: 'relative', marginBottom: 14 },
  avatar: { width: 90, height: 90, borderRadius: 45, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', borderWidth: 3, borderColor: 'rgba(255,255,255,0.4)' },
  avatarImg: { width: 90, height: 90, borderRadius: 45, borderWidth: 3, borderColor: 'rgba(255,255,255,0.4)' },
  avatarTxt: { color: P, fontWeight: '900', fontSize: 36 },
  cameraBtn: { position: 'absolute', bottom: 0, right: 0, width: 28, height: 28, borderRadius: 14, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center' },
  nameRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 },
  profileName: { fontSize: 22, fontWeight: '900', color: '#fff', letterSpacing: -0.3 },
  editIcon: { fontSize: 16 },
  nameEditRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 6 },
  nameInput: { backgroundColor: 'rgba(255,255,255,0.2)', color: '#fff', borderRadius: 10, paddingHorizontal: 12, paddingVertical: 6, fontSize: 16, fontWeight: '700', minWidth: 140, borderWidth: 1, borderColor: 'rgba(255,255,255,0.4)' },
  nameConfirm: { backgroundColor: 'rgba(255,255,255,0.25)', width: 32, height: 32, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  nameCancel: { backgroundColor: '#fff', width: 32, height: 32, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  profileEmail: { color: 'rgba(255,255,255,0.75)', fontSize: 13, marginBottom: 10 },
  typeBadge: { backgroundColor: 'rgba(255,255,255,0.2)', paddingHorizontal: 16, paddingVertical: 6, borderRadius: R.full },
  typeTxt: { color: '#fff', fontWeight: '700', fontSize: 13 },
  ordersStrip: { backgroundColor: '#fff', marginHorizontal: 16, borderRadius: R.xl, padding: 16, marginBottom: 12, ...SHADOWS.card },
  stripHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 },
  stripTitle: { fontWeight: '800', color: COLORS.text, fontSize: 14 },
  stripSeeAll: { color: P, fontWeight: '700', fontSize: 13 },
  orderRow: { flexDirection: 'row', alignItems: 'center', gap: 10, paddingVertical: 8, borderTopWidth: 1, borderTopColor: COLORS.border },
  orderEmoji: { fontSize: 26, width: 34, textAlign: 'center' },
  orderName: { fontWeight: '700', fontSize: 13, color: COLORS.text, marginBottom: 2 },
  orderMeta: { color: COLORS.text3, fontSize: 12 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: R.full },
  statusTxt: { fontSize: 11, fontWeight: '700' },
  menu: { backgroundColor: '#fff', marginHorizontal: 16, borderRadius: R.xl, overflow: 'hidden', marginBottom: 12, ...SHADOWS.card },
  menuItem: { flexDirection: 'row', alignItems: 'center', padding: 16, borderBottomWidth: 1, borderBottomColor: COLORS.border },
  menuIcon: { width: 44, height: 44, borderRadius: 14, alignItems: 'center', justifyContent: 'center', marginRight: 14 },
  menuLabel: { flex: 1, fontWeight: '700', fontSize: 15, color: COLORS.text },
  menuArrow: { color: COLORS.text3, fontSize: 22, fontWeight: '600' },
  signOutBtn: { marginHorizontal: 16, borderRadius: R.xl, padding: 16, alignItems: 'center', borderWidth: 1.5, borderColor: COLORS.error },
  signOutTxt: { color: COLORS.error, fontWeight: '800', fontSize: 15 },
});
