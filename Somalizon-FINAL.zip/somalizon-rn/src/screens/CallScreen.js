import React, { useEffect, useRef, useState } from 'react';
import { Ionicons, MaterialIcons } from '@expo/vector-icons';
import { View, Text, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { RTCPeerConnection, RTCSessionDescription, RTCIceCandidate, mediaDevices } from 'react-native-webrtc';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { COLORS, SHADOWS, R } from '../constants/Design';

const P = COLORS.primary;
function pad(n) { return String(n).padStart(2,'0'); }
function fmt(s) { return `${pad(Math.floor(s/60))}:${pad(s%60)}`; }

// STUN alone only works when at least one side has an "easy" NAT. For real users
// on different mobile networks / carrier-grade NAT, you need a TURN server as a
// relay fallback, or calls will just hang at "La wacayaa..." and never connect.
//
// Below uses Open Relay Project's public test TURN server (free, no signup) so
// this works out of the box. It's fine for development/testing, but it's a shared
// public server — for production, switch to your own Twilio NTS, Xirsys, or
// coturn credentials instead (see https://www.metered.ca/tools/openrelay/).
const ICE_SERVERS = [
  { urls: 'stun:stun.relay.metered.ca:80' },
  { urls: 'turn:global.relay.metered.ca:80', username: 'openrelayproject', credential: 'openrelayproject' },
  { urls: 'turn:global.relay.metered.ca:443', username: 'openrelayproject', credential: 'openrelayproject' },
  { urls: 'turn:global.relay.metered.ca:443?transport=tcp', username: 'openrelayproject', credential: 'openrelayproject' },
];

export default function CallScreen({ route, navigation }) {
  const { otherEmail, otherName, incomingCallId, isIncoming } = route.params;
  const { profile } = useAuth();
  const [status, setStatus]   = useState(isIncoming ? 'incoming' : 'calling');
  const [muted, setMuted]     = useState(false);
  // NOTE: speaker toggle is UI-only for now — actually routing audio to the
  // loudspeaker needs a native module like react-native-incall-manager,
  // which isn't installed in this project yet.
  const [speaker, setSpeaker] = useState(false);
  const [seconds, setSeconds] = useState(0);
  const pcRef       = useRef(null);
  const callIdRef   = useRef(incomingCallId || null);
  const timerRef    = useRef(null);
  const channelRef  = useRef(null);
  const candChRef   = useRef(null);
  const seenCandRef = useRef(new Set());

  useEffect(() => {
    if (!isIncoming) startCall();
    else watchIncomingCall(); // just watch for cancel/decline until user taps "Qabo"
    return cleanup;
  }, []);

  function startTimer() { timerRef.current = setInterval(() => setSeconds(s => s+1), 1000); }

  async function cleanup() {
    clearInterval(timerRef.current);
    if (channelRef.current) supabase.removeChannel(channelRef.current);
    if (candChRef.current) supabase.removeChannel(candChRef.current);
    if (pcRef.current) { pcRef.current.close(); pcRef.current = null; }
    if (callIdRef.current) await supabase.from('calls').update({ status: 'ended' }).eq('id', callIdRef.current);
  }

  async function createPC() {
    try {
      const stream = await mediaDevices.getUserMedia({ audio: true, video: false });
      const pc = new RTCPeerConnection({ iceServers: ICE_SERVERS });
      stream.getTracks().forEach(t => pc.addTrack(t, stream));
      pcRef.current = pc; return pc;
    } catch (e) {
      console.log('WebRTC error:', e?.message || e);
      Alert.alert('Wac ma bilaabmin', 'Fadlan hubi ogolaanshaha mic-ga (microphone permission).');
      navigation.goBack(); return null;
    }
  }

  // Listen for remote ICE candidates from the other side and feed them to the PC.
  function watchRemoteCandidates(pc, callId, myRole) {
    const otherRole = myRole === 'caller' ? 'callee' : 'caller';
    candChRef.current = supabase.channel('cand-' + callId)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'call_candidates', filter: 'call_id=eq.' + callId }, ({ new: row }) => {
        if (row.role !== otherRole) return;
        const key = JSON.stringify(row.candidate);
        if (seenCandRef.current.has(key)) return;
        seenCandRef.current.add(key);
        pc.addIceCandidate(new RTCIceCandidate(row.candidate)).catch(() => {});
      })
      .subscribe();
  }

  async function startCall() {
    const pc = await createPC(); if (!pc) return;
    const callId = `${Date.now()}_${Math.random().toString(36).slice(2)}`;
    callIdRef.current = callId;
    pc.addEventListener('icecandidate', async ({ candidate }) => {
      if (candidate) await supabase.from('call_candidates').insert({ call_id: callId, role: 'caller', candidate: candidate.toJSON() });
    });
    watchRemoteCandidates(pc, callId, 'caller');
    const offer = await pc.createOffer({ offerToReceiveAudio: true });
    await pc.setLocalDescription(offer);
    await supabase.from('calls').insert({ id: callId, callerEmail: profile.email, calleeEmail: otherEmail, offer: { type: offer.type, sdp: offer.sdp }, status: 'ringing' });
    channelRef.current = supabase.channel('call-'+callId)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'calls', filter: 'id=eq.'+callId }, async ({ new: row }) => {
        if (row.status === 'answered' && row.answer) {
          await pc.setRemoteDescription(new RTCSessionDescription(row.answer));
          setStatus('active'); startTimer();
        }
        if (row.status === 'ended' || row.status === 'declined') endCall();
      })
      .subscribe();
  }

  // For an incoming call: just watch the row so we notice if the caller hangs up
  // before we answer. We deliberately do NOT open the mic / build a PeerConnection yet.
  function watchIncomingCall() {
    if (!callIdRef.current) return;
    channelRef.current = supabase.channel('call-watch-' + callIdRef.current)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'calls', filter: 'id=eq.' + callIdRef.current }, ({ new: row }) => {
        if (row.status === 'ended' || row.status === 'declined') {
          if (status !== 'active') { navigation.goBack(); }
        }
      })
      .subscribe();
  }

  async function listenForAnswer() {
    if (!callIdRef.current) return;
    if (channelRef.current) { supabase.removeChannel(channelRef.current); channelRef.current = null; }
    const pc = await createPC(); if (!pc) return;
    const callId = callIdRef.current;
    pc.addEventListener('icecandidate', async ({ candidate }) => {
      if (candidate) await supabase.from('call_candidates').insert({ call_id: callId, role: 'callee', candidate: candidate.toJSON() });
    });
    watchRemoteCandidates(pc, callId, 'callee');
    const { data } = await supabase.from('calls').select('*').eq('id', callId).maybeSingle();
    if (!data?.offer) return;
    await pc.setRemoteDescription(new RTCSessionDescription(data.offer));
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    await supabase.from('calls').update({ answer: { type: answer.type, sdp: answer.sdp }, status: 'answered' }).eq('id', callId);
    setStatus('active'); startTimer();
  }

  function toggleMute() {
    const pc = pcRef.current;
    if (pc) {
      pc.getSenders().forEach(s => { if (s.track && s.track.kind === 'audio') s.track.enabled = muted; });
    }
    setMuted(m => !m);
  }

  async function endCall() {
    setStatus('ended'); await cleanup(); navigation.goBack();
  }

  async function declineCall() {
    if (callIdRef.current) await supabase.from('calls').update({ status: 'declined' }).eq('id', callIdRef.current);
    navigation.goBack();
  }

  const displayName = otherName || otherEmail.split('@')[0];

  return (
    <View style={styles.wrap}>
      {/* Background pattern */}
      <View style={styles.bgCircle1} />
      <View style={styles.bgCircle2} />

      {/* Avatar */}
      <View style={styles.avatarBox}>
        <View style={[styles.avatarRing, styles.ring3]} />
        <View style={[styles.avatarRing, styles.ring2]} />
        <View style={[styles.avatarRing, styles.ring1]} />
        <View style={styles.avatar}>
          <Text style={styles.avatarTxt}>{displayName[0]?.toUpperCase() || '?'}</Text>
        </View>
      </View>

      {/* Name & status */}
      <Text style={styles.callerName}>{displayName}</Text>
      <Text style={styles.callerEmail}>{otherEmail}</Text>
      <View style={styles.statusRow}>
        {status === 'active' && <View style={styles.activeDot} />}
        {status !== 'active' && (
          <Ionicons
            name={status === 'calling' ? 'call-outline' : status === 'incoming' ? 'call-outline' : 'close-circle-outline'}
            size={14} color={styles.statusTxt.color} style={{ marginRight: 6 }}
          />
        )}
        <Text style={styles.statusTxt}>
          {status === 'calling'  ? 'La wacayaa...' :
           status === 'incoming' ? 'Wac soo gala...' :
           status === 'active'   ? fmt(seconds) : 'Waca la joojiyay'}
        </Text>
      </View>

      {/* Controls */}
      {status === 'incoming' ? (
        <View style={styles.incomingBtns}>
          <View style={styles.incomingCol}>
            <TouchableOpacity style={[styles.circleBtn, styles.declineBtn, SHADOWS.sm]} onPress={declineCall}>
              <MaterialIcons name="call-end" size={28} color={'#fff'} />
            </TouchableOpacity>
            <Text style={styles.btnLabel}>Diibi</Text>
          </View>
          <View style={styles.incomingCol}>
            <TouchableOpacity style={[styles.circleBtn, styles.answerBtn, SHADOWS.orange]} onPress={listenForAnswer}>
              <Ionicons name="call" size={28} color={'#fff'} />
            </TouchableOpacity>
            <Text style={styles.btnLabel}>Qabo</Text>
          </View>
        </View>
      ) : (
        <View style={styles.controls}>
          <View style={styles.ctrlCol}>
            <TouchableOpacity style={[styles.ctrlBtn, muted && styles.ctrlBtnOn]} onPress={toggleMute}>
              <Ionicons name={muted ? 'mic-off-outline' : 'mic-outline'} size={24} color={'#333'} />
            </TouchableOpacity>
            <Text style={styles.ctrlLabel}>{muted ? 'Unmute' : 'Mute'}</Text>
          </View>
          <View style={styles.ctrlCol}>
            <TouchableOpacity style={[styles.circleBtn, styles.endBtn, SHADOWS.sm]} onPress={endCall}>
              <MaterialIcons name="call-end" size={26} color={'#fff'} />
            </TouchableOpacity>
            <Text style={styles.ctrlLabel}>Jooji</Text>
          </View>
          <View style={styles.ctrlCol}>
            <TouchableOpacity style={[styles.ctrlBtn, speaker && styles.ctrlBtnOn]} onPress={() => setSpeaker(s => !s)}>
              <Ionicons name={speaker ? 'volume-high-outline' : 'volume-low-outline'} size={24} color={'#333'} />
            </TouchableOpacity>
            <Text style={styles.ctrlLabel}>Speaker</Text>
          </View>
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#0D0D0D', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' },
  bgCircle1: { position: 'absolute', width: 400, height: 400, borderRadius: 200, backgroundColor: P + '12', top: -80, left: -80 },
  bgCircle2: { position: 'absolute', width: 300, height: 300, borderRadius: 150, backgroundColor: P + '08', bottom: -60, right: -60 },
  avatarBox: { alignItems: 'center', justifyContent: 'center', marginBottom: 28, position: 'relative', width: 160, height: 160 },
  avatarRing: { position: 'absolute', borderRadius: 100, borderWidth: 1.5, borderColor: P },
  ring1: { width: 140, height: 140, opacity: 0.4 },
  ring2: { width: 160, height: 160, opacity: 0.2 },
  ring3: { width: 180, height: 180, opacity: 0.1 },
  avatar: { width: 110, height: 110, borderRadius: 55, backgroundColor: P, alignItems: 'center', justifyContent: 'center', ...SHADOWS.orange },
  avatarTxt: { color: '#fff', fontSize: 46, fontWeight: '900' },
  callerName: { color: '#fff', fontSize: 28, fontWeight: '900', marginBottom: 6, letterSpacing: -0.3 },
  callerEmail: { color: 'rgba(255,255,255,0.5)', fontSize: 13, marginBottom: 12 },
  statusTxt: { color: 'rgba(255,255,255,0.8)', fontSize: 15, fontWeight: '600' },
  statusRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginBottom: 64 },
  activeDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: COLORS.success, marginRight: 6 },
  incomingBtns: { flexDirection: 'row', gap: 60 },
  incomingCol: { alignItems: 'center', gap: 10 },
  controls: { flexDirection: 'row', alignItems: 'center', gap: 36 },
  ctrlCol: { alignItems: 'center', gap: 8 },
  circleBtn: { width: 68, height: 68, borderRadius: 34, alignItems: 'center', justifyContent: 'center' },
  endBtn: { backgroundColor: COLORS.error },
  answerBtn: { backgroundColor: COLORS.success },
  declineBtn: { backgroundColor: COLORS.error },
  ctrlBtn: { width: 56, height: 56, borderRadius: 18, backgroundColor: 'rgba(255,255,255,0.1)', alignItems: 'center', justifyContent: 'center' },
  ctrlBtnOn: { backgroundColor: '#fff' },
  ctrlLabel: { color: 'rgba(255,255,255,0.6)', fontSize: 11, fontWeight: '600' },
  btnLabel: { color: 'rgba(255,255,255,0.7)', fontSize: 13, fontWeight: '600' },
});
