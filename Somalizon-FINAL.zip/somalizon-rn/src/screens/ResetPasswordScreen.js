import React, { useState, useEffect } from 'react';
import { Ionicons } from '@expo/vector-icons';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, Linking, ActivityIndicator,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { COLORS, SHADOWS, R } from '../constants/Design';
import { PrimaryBtn } from '../components/Buttons';
import { useToast } from '../components/Toast';

const P = COLORS.primary;

// Pulls access_token/refresh_token out of the somalizon://reset-password
// link, whether Supabase put them after a `?` or a `#`.
function parseTokensFromUrl(url) {
  if (!url) return null;
  const raw = url.split(/[?#]/).slice(1).join('&');
  const params = new URLSearchParams(raw);
  const access_token = params.get('access_token');
  const refresh_token = params.get('refresh_token');
  if (!access_token || !refresh_token) return null;
  return { access_token, refresh_token };
}

// Reached via the somalizon://reset-password deep link inside the
// password-reset email. We read the recovery tokens straight from the
// link and open a session with them before letting the user set a
// new password (detectSessionInUrl is off in lib/supabase.js, so this
// has to happen manually).
export default function ResetPasswordScreen({ navigation }) {
  const [pass, setPass] = useState('');
  const [confirm, setConfirm] = useState('');
  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [ready, setReady] = useState(false);
  const [linkError, setLinkError] = useState(false);
  const showToast = useToast();

  useEffect(() => {
    (async () => {
      const url = await Linking.getInitialURL();
      const tokens = parseTokensFromUrl(url);
      if (!tokens) { setLinkError(true); return; }
      const { error } = await supabase.auth.setSession(tokens);
      if (error) { setLinkError(true); return; }
      setReady(true);
    })();
  }, []);

  async function saveNewPassword() {
    if (!pass || pass.length < 6) { showToast('Password-ku waa in uu ka badan yahay 6 xaraf', 'error'); return; }
    if (pass !== confirm) { showToast('Password-yadu isku mid ma aha', 'error'); return; }
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password: pass });
    setLoading(false);
    if (error) { showToast(error.message, 'error'); return; }
    setDone(true);
  }

  return (
    <KeyboardAvoidingView style={styles.wrap} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.content}>
        <View style={styles.iconBox}>
          <Ionicons name={done ? 'checkmark-circle-outline' : linkError ? 'alert-circle-outline' : 'lock-closed-outline'} size={32} color={P} />
        </View>

        {linkError ? (
          <>
            <Text style={styles.title}>Link-gu Wuu Dhacay</Text>
            <Text style={styles.sub}>Link-kan reset-ka waa mid duugoobay ama khaldan. Dib u codso mid cusub.</Text>
            <TouchableOpacity style={styles.backLoginBtn} onPress={() => navigation.reset({ index: 0, routes: [{ name: 'ForgotPassword' }] })}>
              <Text style={styles.backLoginTxt}>Dib u Isku Day</Text>
            </TouchableOpacity>
          </>
        ) : !ready ? (
          <ActivityIndicator color={P} style={{ marginTop: 20 }} />
        ) : !done ? (
          <>
            <Text style={styles.title}>Samee Password Cusub</Text>
            <Text style={styles.sub}>Geli password-ka cusub ee aad rabto in aad isticmaasho.</Text>

            <View style={styles.inputWrap}>
              <Ionicons name="lock-closed-outline" size={20} color={'#333'} />
              <TextInput
                style={styles.input} placeholder="Password cusub"
                placeholderTextColor={COLORS.text3} secureTextEntry={!showPw}
                value={pass} onChangeText={setPass}
              />
              <TouchableOpacity onPress={() => setShowPw(s => !s)}>
                <Ionicons name={showPw ? 'eye-off-outline' : 'eye-outline'} size={18} color={'#333'} />
              </TouchableOpacity>
            </View>

            <View style={styles.inputWrap}>
              <Ionicons name="lock-closed-outline" size={20} color={'#333'} />
              <TextInput
                style={styles.input} placeholder="Xaqiiji password-ka"
                placeholderTextColor={COLORS.text3} secureTextEntry={!showPw}
                value={confirm} onChangeText={setConfirm}
              />
            </View>

            <PrimaryBtn label="Kaydi Password-ka" icon="checkmark-outline" onPress={saveNewPassword} loading={loading} style={{ marginTop: 8 }} />
          </>
        ) : (
          <>
            <Text style={styles.title}>Password-ka Waa La Beddelay!</Text>
            <Text style={styles.sub}>Hadda waxaad ku soo gali kartaa password-kaaga cusub.</Text>
            <TouchableOpacity style={styles.backLoginBtn} onPress={() => navigation.reset({ index: 0, routes: [{ name: 'Login' }] })}>
              <Text style={styles.backLoginTxt}>Ku Noqo Login-ka</Text>
            </TouchableOpacity>
          </>
        )}
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#fff' },
  content: { flex: 1, padding: 24, paddingTop: 90 },
  iconBox: { width: 64, height: 64, borderRadius: 20, backgroundColor: COLORS.primaryPale, alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  title: { fontSize: 22, fontWeight: '900', color: COLORS.text, marginBottom: 8 },
  sub: { fontSize: 14, color: COLORS.text2, lineHeight: 20, marginBottom: 24 },
  inputWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.input, borderRadius: R.lg, borderWidth: 1.5, borderColor: COLORS.inputBorder, paddingHorizontal: 14, marginBottom: 14 },
  input: { flex: 1, paddingVertical: 15, fontSize: 15, color: COLORS.text, marginLeft: 10 },
  backLoginBtn: { alignItems: 'center', marginTop: 10 },
  backLoginTxt: { color: P, fontWeight: '800', fontSize: 15 },
});
