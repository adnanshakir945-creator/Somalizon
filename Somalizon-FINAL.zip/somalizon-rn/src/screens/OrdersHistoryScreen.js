import React, { useEffect, useState, useCallback } from 'react';
import { Ionicons } from '@expo/vector-icons';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  ActivityIndicator, RefreshControl, Alert,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { toIconName } from '../constants/iconMap';
import { useToast } from '../components/Toast';
import OrderStatusTracker from '../components/OrderStatusTracker';
import { statusColor as sharedStatusColor, statusMeta, CANCELLED_STATUS } from '../constants/orderStatus';
import { useCurrency } from '../contexts/CurrencyContext';

const ORANGE = '#FF6B00';

function timeFmt(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleDateString('so-SO') + ' ' + d.toLocaleTimeString('so-SO', { hour: '2-digit', minute: '2-digit' });
}

function statusColor(s) {
  return sharedStatusColor(s);
}

export default function OrdersHistoryScreen({ navigation }) {
  const { profile } = useAuth();
  const { theme } = useTheme();
  const { formatPrice } = useCurrency();
  const showToast = useToast();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { loadOrders(); }, [profile]);

  // Live-update the status badge/tracker the moment a seller marks an
  // order as preparing / on the way / delivered — no manual refresh needed.
  useEffect(() => {
    if (!profile?.email) return;
    const ch = supabase.channel('buyer-orders-' + profile.email)
      .on('postgres_changes', {
        event: 'UPDATE', schema: 'public', table: 'orders',
        filter: `buyerEmail=eq.${profile.email}`,
      }, ({ new: row }) => {
        setOrders(prev => prev.map(o => o.id === row.id ? row : o));
      })
      .subscribe();
    return () => supabase.removeChannel(ch);
  }, [profile?.email]);

  async function loadOrders() {
    if (!profile?.email) { setLoading(false); return; }
    setLoading(true);
    const { data } = await supabase
      .from('orders')
      .select('*')
      .eq('buyerEmail', profile.email)
      .order('created_at', { ascending: false });
    setOrders(data || []);
    setLoading(false);
  }

  async function deleteOrder(orderId) {
    Alert.alert('Tirtir Dalabka', 'Ma hubtaa inaad tirtireyso dalabkan?', [
      { text: 'Maya', style: 'cancel' },
      {
        text: 'Haa, Tirtir', style: 'destructive', onPress: async () => {
          const { error } = await supabase.from('orders').delete().eq('id', orderId);
          if (!error) setOrders(prev => prev.filter(o => o.id !== orderId));
          else showToast(error.message, 'error');
        }
      }
    ]);
  }

  async function cancelOrder(orderId) {
    Alert.alert('Joojii Dalabka', 'Ma hubtaa inaad joojineyso dalabkan? Ganacsadaha ayaa ogaan doona.', [
      { text: 'Maya', style: 'cancel' },
      {
        text: 'Haa, Joojii', style: 'destructive', onPress: async () => {
          const { error } = await supabase.from('orders').update({ status: CANCELLED_STATUS.key }).eq('id', orderId);
          if (!error) {
            setOrders(prev => prev.map(o => o.id === orderId ? { ...o, status: CANCELLED_STATUS.key } : o));
            showToast('Dalabka waa la joojiyay', 'success');
          } else showToast(error.message, 'error');
        }
      }
    ]);
  }

  function chatSeller(sellerName, sellerEmail) {
    if (!profile?.email || !sellerEmail) return;
    const chatId = [profile.email.toLowerCase(), sellerEmail.toLowerCase()].sort().join('__');
    navigation.navigate('ChatRoom', {
      chat: { id: chatId, participantEmails: [profile.email, sellerEmail] },
      otherName: sellerName || sellerEmail.split('@')[0],
      otherEmail: sellerEmail,
    });
  }

  const onRefresh = useCallback(async () => {
    setRefreshing(true); await loadOrders(); setRefreshing(false);
  }, [profile]);

  function renderOrder({ item: o }) {
    const color = statusColor(o.status);
    return (
      <View style={[styles.card, { backgroundColor: theme.card }]}>
        {/* Header */}
        <View style={styles.cardHeader}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
            <Ionicons name="clipboard-outline" size={13} color={theme.text} />
            <Text style={[styles.orderNum, { color: theme.text }]}>
              Dalabka #{String(o.id).slice(-4).toUpperCase()}
            </Text>
          </View>
          <View style={styles.headerRight}>
            <View style={[styles.statusBadge, { backgroundColor: color + '22' }]}>
              <Text style={[styles.statusTxt, { color }]}>{statusMeta(o.status).label}</Text>
            </View>
            <TouchableOpacity onPress={() => deleteOrder(o.id)} style={styles.deleteBtn}>
              <Ionicons name="trash-outline" size={20} color={'#333'} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Order progress tracker */}
        <OrderStatusTracker status={o.status || 'La Diray'} textColor={theme.text} mutedColor={theme.text2} />

        {/* Product info */}
        <View style={styles.prodRow}>
          <Ionicons name={toIconName(o.prodEmoji)} size={styles.prodEmoji.fontSize || 32} color={'#333'} style={styles.prodEmoji} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.prodName, { color: theme.text }]}>{o.prodName}</Text>
            <Text style={[styles.prodMeta, { color: theme.text2 }]}>Tirada: {o.qty} · {formatPrice(o.totalPrice || 0)}</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
              <Ionicons name="person-outline" size={11} color={theme.text2} />
              <Text style={[styles.prodMeta, { color: theme.text2 }]}>{o.sellerName || o.sellerEmail}</Text>
            </View>
          </View>
        </View>

        {/* Delivery info */}
        <View style={[styles.deliveryBox, { backgroundColor: theme.bg }]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Ionicons name="call-outline" size={12} color={theme.text2} /><Text style={[styles.deliveryTxt, { color: theme.text2 }]}>{o.phone}</Text></View>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Ionicons name="location-outline" size={12} color={theme.text2} /><Text style={[styles.deliveryTxt, { color: theme.text2 }]}>{o.address}</Text></View>
          {o.payMethod && <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Ionicons name="card-outline" size={12} color={theme.text2} /><Text style={[styles.deliveryTxt, { color: theme.text2 }]}>{o.payMethod}</Text></View>}
        </View>

        {/* Footer */}
        <View style={styles.cardFooter}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Ionicons name="calendar-outline" size={11} color={theme.text2} /><Text style={[styles.orderDate, { color: theme.text2 }]}>{timeFmt(o.created_at)}</Text></View>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            {(o.status || 'La Diray') === 'La Diray' && (
              <TouchableOpacity style={styles.cancelBtn} onPress={() => cancelOrder(o.id)}>
                <Text style={styles.cancelBtnTxt}>Joojii</Text>
              </TouchableOpacity>
            )}
            <TouchableOpacity
              style={styles.chatBtn}
              onPress={() => chatSeller(o.sellerName, o.sellerEmail)}
            >
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="chatbubble-outline" size={14} color={styles.chatBtnTxt.color} /><Text style={styles.chatBtnTxt}>Xariir</Text></View>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="chevron-back" size={20} color={'#333'} /></TouchableOpacity>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Ionicons name="cube-outline" size={18} color={theme.text} />
          <Text style={[styles.title, { color: theme.text }]}>Dalabaadayda ({orders.length})</Text>
        </View>
        <View style={{ width: 30 }} />
      </View>

      {loading ? <ActivityIndicator color={ORANGE} style={{ marginTop: 40 }} /> : (
        <FlatList
          data={orders} keyExtractor={o => String(o.id)}
          contentContainerStyle={{ padding: 14 }}
          renderItem={renderOrder}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={ORANGE} />}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="cube-outline" size={52} color={'#333'} />
              <Text style={[styles.emptyTxt, { color: theme.text2 }]}>Wax dalabaad ah ma jiraan weli</Text>
              <TouchableOpacity style={styles.shopBtn} onPress={() => navigation.navigate('Home')}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="bag-handle-outline" size={15} color={styles.shopBtnTxt.color} /><Text style={styles.shopBtnTxt}>Alaab Raadi</Text></View>
              </TouchableOpacity>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52, borderBottomWidth: 1 },
  back: { fontSize: 24, color: ORANGE },
  title: { fontSize: 17, fontWeight: '700' },
  card: { borderRadius: 16, padding: 14, marginBottom: 12, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  orderNum: { fontWeight: '800', fontSize: 14 },
  headerRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 },
  statusTxt: { fontSize: 12, fontWeight: '700' },
  deleteBtn: { padding: 4 },
  deleteTxt: { fontSize: 18 },
  prodRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 10 },
  prodEmoji: { fontSize: 36, width: 46, textAlign: 'center' },
  prodName: { fontWeight: '700', fontSize: 14, marginBottom: 3 },
  prodMeta: { fontSize: 12, marginBottom: 2 },
  deliveryBox: { borderRadius: 10, padding: 10, marginBottom: 10, gap: 3 },
  deliveryTxt: { fontSize: 12 },
  cardFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  orderDate: { fontSize: 12 },
  chatBtn: { backgroundColor: ORANGE, paddingHorizontal: 16, paddingVertical: 8, borderRadius: 10 },
  chatBtnTxt: { color: '#fff', fontWeight: '700', fontSize: 13 },
  cancelBtn: { backgroundColor: '#FEE2E2', paddingHorizontal: 14, paddingVertical: 8, borderRadius: 10 },
  cancelBtnTxt: { color: '#ef4444', fontWeight: '700', fontSize: 13 },
  empty: { alignItems: 'center', marginTop: 80 },
  emptyTxt: { fontSize: 15, marginBottom: 20 },
  shopBtn: { backgroundColor: ORANGE, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 14 },
  shopBtnTxt: { color: '#fff', fontWeight: '700' },
});
