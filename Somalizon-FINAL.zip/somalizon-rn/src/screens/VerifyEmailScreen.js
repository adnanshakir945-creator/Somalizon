import React, { useState, useRef } from 'react';
import { Ionicons } from '@expo/vector-icons';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { COLORS, R } from '../constants/Design';
import { PrimaryBtn } from '../components/Buttons';
import { useToast } from '../components/Toast';

const P = COLORS.primary;

// Reached right after signUp. Supabase emails a 6-digit code (as long
// as the "Confirm signup" template uses {{ .Token }} — see the note
// at the bottom of this file) which we verify here before letting the
// person into the app.
export default function VerifyEmailScreen({ route, navigation }) {
  const { email } = route.params;
  const [code, setCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [resending, setResending] = useState(false);
  const showToast = useToast();

  async function verify() {
    if (code.trim().length !== 6) { showToast('Geli 6-da lambar ee code-ka', 'error'); return; }
    setLoading(true);
    const { error } = await supabase.auth.verifyOtp({ email, token: code.trim(), type: 'signup' });
    setLoading(false);
    if (error) { showToast(error.message, 'error'); return; }
    showToast('Email-kaaga waa la xaqiijiyay!', 'success');
    navigation.reset({ index: 0, routes: [{ name: 'Login' }] });
  }

  async function resend() {
    setResending(true);
    const { error } = await supabase.auth.resend({ type: 'signup', email });
    setResending(false);
    if (error) { showToast(error.message, 'error'); return; }
    showToast('Code cusub waa la diray', 'success');
  }

  return (
    <KeyboardAvoidingView style={styles.wrap} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <View style={styles.content}>
        <View style={styles.iconBox}>
          <Ionicons name="mail-open-outline" size={32} color={P} />
        </View>
        <Text style={styles.title}>Xaqiiji Email-kaaga</Text>
        <Text style={styles.sub}>
          Waxaan diray koodh 6-lambar ah {'\n'}<Text style={{ fontWeight: '800' }}>{email}</Text>
        </Text>

        <TextInput
          style={styles.codeInput}
          placeholder="000000"
          placeholderTextColor={COLORS.text3}
          keyboardType="number-pad"
          maxLength={6}
          value={code}
          onChangeText={t => setCode(t.replace(/\D/g, ''))}
          textAlign="center"
        />

        <PrimaryBtn label="Xaqiiji" icon="checkmark-outline" onPress={verify} loading={loading} style={{ marginTop: 8 }} />

        <TouchableOpacity style={styles.resendBtn} onPress={resend} disabled={resending}>
          <Text style={styles.resendTxt}>{resending ? 'Dirayaa...' : 'Ma helin koodhka? Dib u dir'}</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#fff' },
  content: { flex: 1, padding: 24, paddingTop: 90, alignItems: 'center' },
  iconBox: { width: 64, height: 64, borderRadius: 20, backgroundColor: COLORS.primaryPale, alignItems: 'center', justifyContent: 'center', marginBottom: 20 },
  title: { fontSize: 22, fontWeight: '900', color: COLORS.text, marginBottom: 8 },
  sub: { fontSize: 14, color: COLORS.text2, lineHeight: 20, marginBottom: 24, textAlign: 'center' },
  codeInput: {
    width: '100%', backgroundColor: COLORS.input, borderRadius: R.lg, borderWidth: 1.5, borderColor: COLORS.inputBorder,
    paddingVertical: 16, fontSize: 26, fontWeight: '800', letterSpacing: 10, color: COLORS.text, marginBottom: 18,
  },
  resendBtn: { marginTop: 18 },
  resendTxt: { color: P, fontWeight: '700', fontSize: 13 },
});

// ─────────────────────────────────────────────────────────
// SUPABASE DASHBOARD SETUP REQUIRED:
// Authentication → Email Templates → "Confirm signup"
// Make sure the template body includes {{ .Token }} (the 6-digit
// code), not just {{ .ConfirmationURL }}. Supabase's default
// template uses the link only — swap/add the token so this screen
// has something to verify against. Also check Authentication →
// Providers → Email → "Confirm email" is turned ON, otherwise
// accounts are auto-confirmed and this screen never triggers.
// ─────────────────────────────────────────────────────────
