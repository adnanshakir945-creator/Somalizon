import React, { useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { Video } from 'expo-av';
import {
  View, Text, TouchableOpacity, StyleSheet,
  TextInput, Alert, ActivityIndicator, ScrollView,
} from 'react-native';

import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { useToast } from '../components/Toast';

const ORANGE = '#FF6B00';

export default function UploadVideoScreen({ navigation }) {
  const { profile } = useAuth();
  const { theme } = useTheme();
  const showToast = useToast();
  const [videoUri, setVideoUri] = useState(null);
  const [desc, setDesc] = useState('');
  const [prodName, setProdName] = useState('');
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState('');

  async function pickVideo() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { showToast('Fasax library', 'error'); return; }
    const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Videos, quality: 0.7 });
    if (!res.canceled && res.assets?.length) setVideoUri(res.assets[0].uri);
  }

  async function recordVideo() {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') { showToast('Fasax camera', 'error'); return; }
    const res = await ImagePicker.launchCameraAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Videos, videoMaxDuration: 60 });
    if (!res.canceled && res.assets?.length) setVideoUri(res.assets[0].uri);
  }

  async function uploadVideo() {
    if (!videoUri) { showToast('Video dooro marka hore', 'error'); return; }
    if (!desc.trim()) { showToast('Sharaxaadda gali', 'error'); return; }
    if (!profile) return;
    setUploading(true);

    try {
      setProgress('Video la soo geliyaa...');
      const ext = videoUri.split('.').pop() || 'mp4';
      const path = `videos/${profile.id}_${Date.now()}.${ext}`;

      const response = await fetch(videoUri);
      const blob = await response.blob();

      const { error: upErr } = await supabase.storage.from('videos').upload(path, blob, { contentType: `video/${ext}`, upsert: false });
      if (upErr) throw upErr;

      const { data: urlData } = supabase.storage.from('videos').getPublicUrl(path);
      setProgress('Macluumaadka la keydinayaa...');

      const { error: dbErr } = await supabase.from('videos').insert({
        url: urlData.publicUrl,
        user: profile.name || profile.email.split('@')[0],
        userEmail: profile.email,
        desc: desc.trim(),
        prodName: prodName.trim() || null,
        likes: 0,
        comments: 0,
      });
      if (dbErr) throw dbErr;

      setUploading(false);
      setProgress('');
      showToast('Videohaga ayaa lagu daray Watch feed-ka!', 'success');
      navigation.goBack();
    } catch (e) {
      setUploading(false);
      setProgress('');
      showToast(e.message, 'error');
    }
  }

  return (
    <ScrollView style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="chevron-back" size={20} color={'#333'} /></TouchableOpacity>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Ionicons name="videocam-outline" size={18} color={theme.text} />
          <Text style={[styles.title, { color: theme.text }]}>Video Soo Dhig</Text>
        </View>
        <View style={{ width: 30 }} />
      </View>

      {/* Video preview / picker */}
      {videoUri
        ? <Video source={{ uri: videoUri }} style={styles.preview} resizeMode="cover" useNativeControls />
        : (
          <View style={styles.pickerArea}>
            <TouchableOpacity style={styles.pickBtn} onPress={pickVideo}>
              <Ionicons name="folder-outline" size={40} color={'#333'} />
              <Text style={styles.pickTxt}>Library ka dooro</Text>
            </TouchableOpacity>
            <View style={styles.divider} />
            <TouchableOpacity style={styles.pickBtn} onPress={recordVideo}>
              <Ionicons name="videocam-outline" size={40} color={'#333'} />
              <Text style={styles.pickTxt}>Camera ka duub</Text>
            </TouchableOpacity>
          </View>
        )
      }

      <View style={{ padding: 16 }}>
        {videoUri && (
          <TouchableOpacity style={styles.changeBtn} onPress={() => setVideoUri(null)}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="refresh-outline" size={14} color={styles.changeTxt.color} /><Text style={styles.changeTxt}>Video beddel</Text></View>
          </TouchableOpacity>
        )}

        <Text style={[styles.label, { color: theme.text }]}>Sharaxaadda Video *</Text>
        <TextInput
          style={[styles.input, { backgroundColor: theme.input, color: theme.inputText, height: 80 }]}
          placeholder="Maxaa video-ga ku jira?..." placeholderTextColor="#999"
          multiline value={desc} onChangeText={setDesc}
        />

        <Text style={[styles.label, { color: theme.text }]}>Magaca Alaabta (ikhtiyaari)</Text>
        <TextInput
          style={[styles.input, { backgroundColor: theme.input, color: theme.inputText }]}
          placeholder="Haddii video-ga alaab ka muujinayso..." placeholderTextColor="#999"
          value={prodName} onChangeText={setProdName}
        />

        {progress ? <Text style={styles.progress}>{progress}</Text> : null}

        <TouchableOpacity style={[styles.uploadBtn, !videoUri && styles.uploadBtnDis]} onPress={uploadVideo} disabled={uploading || !videoUri}>
          {uploading ? <ActivityIndicator color="#fff" /> : <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="rocket-outline" size={16} color={styles.uploadTxt.color} /><Text style={styles.uploadTxt}>Soo Dhig Watch-ka</Text></View>}
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52 },
  back: { fontSize: 24, color: ORANGE },
  title: { fontSize: 17, fontWeight: '700' },
  pickerArea: { flexDirection: 'row', height: 180, margin: 16, borderRadius: 16, overflow: 'hidden', backgroundColor: '#f0f0f0' },
  pickBtn: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  pickTxt: { color: '#888', marginTop: 8, fontSize: 13 },
  divider: { width: 1, backgroundColor: '#ddd' },
  preview: { height: 220, margin: 16, borderRadius: 16 },
  changeBtn: { alignItems: 'center', padding: 10, marginBottom: 12 },
  changeTxt: { color: ORANGE, fontWeight: '600' },
  label: { fontWeight: '700', fontSize: 13, marginBottom: 7 },
  input: { borderRadius: 12, padding: 13, marginBottom: 14, fontSize: 14 },
  progress: { color: ORANGE, textAlign: 'center', marginBottom: 12, fontSize: 13 },
  uploadBtn: { backgroundColor: ORANGE, padding: 16, borderRadius: 14, alignItems: 'center', marginBottom: 30 },
  uploadBtnDis: { backgroundColor: '#ccc' },
  uploadTxt: { color: '#fff', fontWeight: '800', fontSize: 15 },
});
