import React, { useEffect, useState, useRef } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { Video } from 'expo-av';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  Dimensions, ActivityIndicator,
} from 'react-native';

import { supabase } from '../lib/supabase';
import { useTheme } from '../contexts/ThemeContext';

const ORANGE = '#FF6B00';
const { height: H, width: W } = Dimensions.get('window');

function VideoItem({ item: v, isActive, onComment }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!ref.current) return;
    if (isActive) ref.current.playAsync().catch(() => {});
    else ref.current.pauseAsync().catch(() => {});
  }, [isActive]);

  return (
    <View style={styles.videoWrap}>
      <Video ref={ref} source={{ uri: v.url }} style={styles.video}
        resizeMode="cover" shouldPlay={isActive} isLooping isMuted={false} />
      <View style={styles.overlay}>
        <View style={styles.infoBox}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Ionicons name="person-outline" size={13} color="#fff" /><Text style={styles.vUser}>{v.user}</Text></View>
          <Text style={styles.vDesc} numberOfLines={2}>{v.desc}</Text>
          {v.prodName && <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Ionicons name="bag-handle-outline" size={13} color={ORANGE} /><Text style={styles.vProd}>{v.prodName}</Text></View>}
        </View>
        <View style={styles.actions}>
          <View style={styles.actionBtn}>
            <Ionicons name="heart" size={24} color={'#fff'} />
            <Text style={styles.actionCnt}>{v.likes || 0}</Text>
          </View>
          <TouchableOpacity style={styles.actionBtn} onPress={() => onComment(v)}>
            <Ionicons name="chatbubble-outline" size={24} color={'#fff'} />
            <Text style={styles.actionCnt}>{v.comments || 0}</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

export default function ProfileVideoViewerScreen({ route, navigation }) {
  const { userEmail, userName, startIndex = 0 } = route.params;
  const { theme } = useTheme();
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeIdx, setActiveIdx] = useState(startIndex);
  const listRef = useRef(null);

  useEffect(() => {
    loadVideos();
  }, [userEmail]);

  async function loadVideos() {
    setLoading(true);
    const { data } = await supabase
      .from('videos').select('*')
      .eq('userEmail', userEmail)
      .order('created_at', { ascending: false });
    setVideos(data || []);
    setLoading(false);
    if (startIndex > 0) {
      setTimeout(() => listRef.current?.scrollToIndex({ index: startIndex, animated: false }), 200);
    }
  }

  if (loading) return (
    <View style={[styles.wrap, { backgroundColor: '#000' }]}>
      <ActivityIndicator color={ORANGE} size="large" />
    </View>
  );

  if (!videos.length) return (
    <View style={[styles.wrap, { backgroundColor: '#000' }]}>
      <TouchableOpacity style={styles.closeBtn} onPress={() => navigation.goBack()}>
        <Ionicons name="close" size={20} color={'#333'} />
      </TouchableOpacity>
      <View style={{ alignItems: 'center', marginTop: 200 }}>
        <Ionicons name="film-outline" size={40} color={'#fff'} style={{ marginBottom: 10 }} />
        <Text style={{ color: '#fff', textAlign: 'center', fontSize: 16 }}>
          {userName} weli video ma soo dhigin
        </Text>
      </View>
    </View>
  );

  return (
    <View style={styles.wrap}>
      <TouchableOpacity style={styles.closeBtn} onPress={() => navigation.goBack()}>
        <Ionicons name="close" size={20} color={'#333'} />
      </TouchableOpacity>
      <FlatList
        ref={listRef}
        data={videos}
        keyExtractor={v => String(v.id)}
        pagingEnabled
        snapToInterval={H}
        decelerationRate="fast"
        showsVerticalScrollIndicator={false}
        onViewableItemsChanged={({ viewableItems }) => {
          if (viewableItems.length > 0) setActiveIdx(viewableItems[0].index);
        }}
        viewabilityConfig={{ itemVisiblePercentThreshold: 80 }}
        renderItem={({ item, index }) => (
          <VideoItem
            item={item}
            isActive={index === activeIdx}
            onComment={v => navigation.navigate('Comments', { videoId: v.id, videoDesc: v.desc })}
          />
        )}
        getItemLayout={(_, index) => ({ length: H, offset: H * index, index })}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#000' },
  closeBtn: { position: 'absolute', top: 52, left: 16, zIndex: 99, backgroundColor: 'rgba(0,0,0,0.5)', width: 36, height: 36, borderRadius: 18, alignItems: 'center', justifyContent: 'center' },
  closeTxt: { color: '#fff', fontSize: 16, fontWeight: '700' },
  videoWrap: { width: W, height: H, position: 'relative' },
  video: { width: '100%', height: '100%' },
  overlay: { position: 'absolute', bottom: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'flex-end', padding: 16, paddingBottom: 90 },
  infoBox: { flex: 1, marginRight: 12 },
  vUser: { color: '#fff', fontWeight: '700', fontSize: 15, marginBottom: 4, textShadowColor: 'rgba(0,0,0,0.5)', textShadowRadius: 4 },
  vDesc: { color: '#eee', fontSize: 13, lineHeight: 18, textShadowColor: 'rgba(0,0,0,0.5)', textShadowRadius: 4 },
  vProd: { color: ORANGE, fontWeight: '700', fontSize: 13, marginTop: 6 },
  actions: { alignItems: 'center', gap: 16 },
  actionBtn: { alignItems: 'center' },
  actionIco: { fontSize: 28 },
  actionCnt: { color: '#fff', fontSize: 11, fontWeight: '600', marginTop: 2 },
});
