import React, { useEffect, useState, useCallback } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { View, Text, ScrollView, StyleSheet, TouchableOpacity, ActivityIndicator, RefreshControl, Dimensions } from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useRealtime } from '../contexts/RealtimeContext';
import { COLORS, SHADOWS, R } from '../constants/Design';
import { toIconName } from '../constants/iconMap';
import { statusColor as sharedStatusColor, statusMeta } from '../constants/orderStatus';
import { useCurrency } from '../contexts/CurrencyContext';

const P = COLORS.primary;
const { width: W } = Dimensions.get('window');
const CHART_W = W - 64;
const CHART_H = 110;
const DAYS = ['Axd','Itn','Tls','Arb','Kms','Jmc','Sbt'];

export default function DashboardScreen({ navigation }) {
  const { profile, signOut } = useAuth();
  const { newOrder, clearNewOrder } = useRealtime();
  const { formatPrice } = useCurrency();
  const [stats, setStats]       = useState({ revenue: 0, orders: 0, products: 0, followers: 0 });
  const [recentOrders, setRecentOrders] = useState([]);
  const [weekly, setWeekly]     = useState([0,0,0,0,0,0,0]);
  const [loading, setLoading]   = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [banner, setBanner]     = useState(null);

  useEffect(() => { loadDash(); }, [profile]);
  useEffect(() => { if (newOrder) { setBanner(newOrder); clearNewOrder(); loadDash(); setTimeout(() => setBanner(null), 5000); } }, [newOrder]);

  async function loadDash() {
    if (!profile?.email) { setLoading(false); return; }
    setLoading(true);
    const [ordRes, prodsRes, storeRes] = await Promise.all([
      supabase.from('orders').select('*').eq('sellerEmail', profile.email).order('created_at', { ascending: false }),
      supabase.from('products').select('id').eq('sellerEmail', profile.email),
      supabase.from('stores').select('followers').eq('sellerEmail', profile.email).maybeSingle(),
    ]);
    const orders = ordRes.data || [];
    const payout = o => (o.sellerPayout != null ? o.sellerPayout : (o.totalPrice || 0)); // fallback for orders placed before commission tracking existed
    const rev = orders.reduce((a, o) => a + payout(o), 0);
    const today = new Date(), w = [0,0,0,0,0,0,0];
    orders.forEach(o => { const diff = Math.floor((today - new Date(o.created_at)) / 86400000); if (diff >= 0 && diff < 7) w[6-diff] += payout(o); });
    setWeekly(w);
    setStats({ revenue: rev, orders: orders.length, products: (prodsRes.data||[]).length, followers: storeRes.data?.followers || 0 });
    setRecentOrders(orders.slice(0, 8));
    setLoading(false);
  }

  const onRefresh = useCallback(async () => { setRefreshing(true); await loadDash(); setRefreshing(false); }, [profile]);

  function RevenueChart() {
    const maxVal = Math.max(...weekly, 1);
    return (
      <View style={[styles.chartCard, SHADOWS.card]}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="trending-up-outline" size={15} color={styles.chartTitle.color} /><Text style={styles.chartTitle}>Dakhliga — 7 Maalmood</Text></View>
        <View style={styles.chartArea}>
          {weekly.map((val, i) => {
            const h = Math.max((val / maxVal) * CHART_H, 3);
            const d = new Date(); d.setDate(d.getDate() - (6 - i));
            return (
              <View key={i} style={styles.barCol}>
                {val > 0 && <Text style={styles.barLabel}>{val >= 1000 ? Math.round(val/1000)+'K' : val}</Text>}
                <View style={[styles.bar, { height: h, backgroundColor: i === 6 ? P : COLORS.primaryPale }]} />
                <Text style={styles.dayLabel}>{DAYS[d.getDay()]}</Text>
              </View>
            );
          })}
        </View>
        <Text style={styles.chartTotal}>Wadarta: {formatPrice(stats.revenue)}</Text>
      </View>
    );
  }

  function StatCard({ emoji, label, value, accent = false }) {
    return (
      <View style={[styles.statCard, accent && styles.statCardAccent, SHADOWS.card]}>
        <Ionicons name={emoji} size={26} color={accent ? '#fff' : P} style={styles.statEmoji} />
        <Text style={[styles.statValue, accent && { color: '#fff' }]}>{value}</Text>
        <Text style={[styles.statLabel, accent && { color: 'rgba(255,255,255,0.8)' }]}>{label}</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.wrap} refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={P} />}>
      {/* Header */}
      <View style={styles.header}>
        <View style={styles.waveBg} />
        <View style={styles.headerTop}>
          <View>
            <Text style={styles.headerSub}>Dashboard-ka</Text>
            <Text style={styles.headerName}>{profile?.name || 'Ganacsade'}</Text>
          </View>
          <View style={styles.headerBtns}>
            <TouchableOpacity style={styles.headerBtn} onPress={() => navigation.navigate('Notifications')}>
              <Ionicons name="notifications-outline" size={20} color={'#333'} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.headerBtn} onPress={() => navigation.navigate('Settings')}>
              <Ionicons name="settings-outline" size={20} color={'#333'} />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      {/* New order banner */}
      {banner && (
        <TouchableOpacity style={styles.orderBanner} onPress={() => setBanner(null)}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1 }}>
            <Ionicons name="notifications-outline" size={15} color={styles.orderBannerTxt.color} />
            <Ionicons name={toIconName(banner.prodEmoji)} size={15} color={styles.orderBannerTxt.color} />
            <Text style={[styles.orderBannerTxt, { flex: 1 }]} numberOfLines={1}>Dalob cusub! {banner.prodName} — {banner.buyerName}</Text>
            <Ionicons name="close" size={16} color={styles.orderBannerTxt.color} />
          </View>
        </TouchableOpacity>
      )}

      {loading ? <ActivityIndicator color={P} style={{ marginTop: 30 }} /> : <>
        {/* Stats */}
        <View style={styles.statsGrid}>
          <StatCard emoji="cash-outline" label="Dakhliga" value={formatPrice(stats.revenue)} accent />
          <StatCard emoji="cube-outline" label="Dalabyada" value={stats.orders} />
          <StatCard emoji="bag-handle-outline" label="Alaabta" value={stats.products} />
          <StatCard emoji="people-outline" label="Raaciyayaasha" value={stats.followers} />
        </View>

        {/* Revenue chart */}
        <RevenueChart />

        {/* Quick actions */}
        <View style={[styles.section, SHADOWS.card]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="flash-outline" size={15} color={styles.sectionTitle.color} /><Text style={styles.sectionTitle}>Ficilada Degdega</Text></View>
          <View style={styles.quickGrid}>
            {[
              { icon: 'add-circle-outline', label: 'Alaab Geli', screen: 'AddProduct', color: COLORS.primaryPale },
              { icon: 'videocam-outline', label: 'Video Dir',  screen: 'UploadVideo', color: '#FFF0F0' },
              { icon: 'cube-outline', label: 'Dalabyada',  screen: 'SellerOrders', color: '#F0FFF4' },
              { icon: 'chatbubble-outline', label: 'Farriimaha', screen: 'Xariir', color: '#F0F4FF' },
            ].map(q => (
              <TouchableOpacity key={q.label} style={[styles.quickBtn, { backgroundColor: q.color }]} onPress={() => navigation.navigate(q.screen)}>
                <Ionicons name={q.icon} size={26} color={P} />
                <Text style={styles.quickLabel}>{q.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Recent orders */}
        <View style={[styles.section, SHADOWS.card]}>
          <View style={styles.secHeader}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="clipboard-outline" size={15} color={styles.sectionTitle.color} /><Text style={styles.sectionTitle}>Dalabyada Dambe</Text></View>
            <TouchableOpacity onPress={() => navigation.navigate('SellerOrders')} style={{ flexDirection: 'row', alignItems: 'center', gap: 3 }}><Text style={styles.seeAll}>Dhammaan</Text><Ionicons name="chevron-forward" size={13} color={styles.seeAll.color} /></TouchableOpacity>
          </View>
          {recentOrders.length === 0
            ? <Text style={styles.empty}>Dalob ma jiro weli</Text>
            : recentOrders.map(o => (
              <View key={o.id} style={styles.orderRow}>
                <Ionicons name={toIconName(o.prodEmoji)} size={28} color={'#333'} style={{ width: 36, textAlign: 'center' }} />
                <View style={{ flex: 1, marginLeft: 10 }}>
                  <Text style={styles.orderName} numberOfLines={1}>{o.prodName}</Text>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                    <Ionicons name="person-outline" size={11} color={styles.orderMeta.color} />
                    <Text style={styles.orderMeta}>{o.buyerName} · </Text>
                    <Ionicons name="call-outline" size={11} color={styles.orderMeta.color} />
                    <Text style={styles.orderMeta}>{o.phone}</Text>
                  </View>
                </View>
                <View>
                  <Text style={styles.orderPrice}>{formatPrice(o.totalPrice||0)}</Text>
                  <View style={[styles.statusBadge, { backgroundColor: sharedStatusColor(o.status || 'La Diray') + '22' }]}>
                    <Text style={[styles.statusTxt, { color: sharedStatusColor(o.status || 'La Diray') }]}>{statusMeta(o.status || 'La Diray').label}</Text>
                  </View>
                </View>
              </View>
            ))
          }
        </View>

        {/* Sign out */}
        <TouchableOpacity style={styles.signOut} onPress={signOut}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="log-out-outline" size={16} color={styles.signOutTxt.color} /><Text style={styles.signOutTxt}>Ka Bixi</Text></View>
        </TouchableOpacity>
        <View style={{ height: 100 }} />
      </>}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  header: { backgroundColor: P, paddingTop: 54, paddingHorizontal: 20, paddingBottom: 24, borderBottomLeftRadius: 28, borderBottomRightRadius: 28, marginBottom: 16, overflow: 'hidden' },
  waveBg: { position: 'absolute', width: 300, height: 300, borderRadius: 150, backgroundColor: 'rgba(255,255,255,0.08)', top: -80, right: -50 },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' },
  headerSub: { color: 'rgba(255,255,255,0.75)', fontSize: 12, marginBottom: 3 },
  headerName: { color: '#fff', fontSize: 22, fontWeight: '900', letterSpacing: -0.3 },
  headerBtns: { flexDirection: 'row', gap: 8 },
  headerBtn: { width: 40, height: 40, borderRadius: 13, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  orderBanner: { backgroundColor: COLORS.success, marginHorizontal: 16, borderRadius: R.xl, padding: 13, marginBottom: 8 },
  orderBannerTxt: { color: '#fff', fontWeight: '700', fontSize: 13 },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', paddingHorizontal: 12, gap: 10, marginBottom: 12 },
  statCard: { width: (W - 44) / 2, backgroundColor: '#fff', borderRadius: R.xl, padding: 16, alignItems: 'center' },
  statCardAccent: { backgroundColor: P },
  statEmoji: { fontSize: 28, marginBottom: 6 },
  statValue: { fontSize: 18, fontWeight: '900', color: COLORS.text, marginBottom: 3 },
  statLabel: { fontSize: 12, color: COLORS.text2 },
  chartCard: { backgroundColor: '#fff', marginHorizontal: 16, borderRadius: R.xl, padding: 18, marginBottom: 12 },
  chartTitle: { fontWeight: '800', fontSize: 15, color: COLORS.text, marginBottom: 14 },
  chartArea: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between', height: CHART_H + 36 },
  barCol: { flex: 1, alignItems: 'center', justifyContent: 'flex-end' },
  bar: { width: '55%', borderRadius: 5 },
  barLabel: { fontSize: 8, color: P, fontWeight: '700', marginBottom: 3 },
  dayLabel: { fontSize: 10, color: COLORS.text3, marginTop: 5, fontWeight: '600' },
  chartTotal: { fontSize: 12, color: COLORS.text2, textAlign: 'center', marginTop: 10 },
  section: { backgroundColor: '#fff', marginHorizontal: 16, borderRadius: R.xl, padding: 16, marginBottom: 12 },
  sectionTitle: { fontWeight: '800', fontSize: 15, color: COLORS.text, marginBottom: 14 },
  secHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 },
  seeAll: { color: P, fontWeight: '700', fontSize: 13 },
  quickGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 10 },
  quickBtn: { width: (W - 72) / 2, alignItems: 'center', padding: 16, borderRadius: R.xl },
  quickLabel: { color: COLORS.text, fontWeight: '700', fontSize: 13, marginTop: 6 },
  orderRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderTopWidth: 1, borderTopColor: COLORS.border },
  orderName: { fontWeight: '700', color: COLORS.text, fontSize: 13, marginBottom: 2 },
  orderMeta: { color: COLORS.text3, fontSize: 11 },
  orderPrice: { color: COLORS.success, fontWeight: '700', fontSize: 13, textAlign: 'right', marginBottom: 3 },
  statusBadge: { paddingHorizontal: 8, paddingVertical: 3, borderRadius: R.full, alignSelf: 'flex-end' },
  statusTxt: { fontSize: 10, fontWeight: '700' },
  empty: { color: COLORS.text3, textAlign: 'center', paddingVertical: 20 },
  signOut: { marginHorizontal: 16, borderRadius: R.xl, padding: 15, alignItems: 'center', borderWidth: 1.5, borderColor: COLORS.error },
  signOutTxt: { color: COLORS.error, fontWeight: '800', fontSize: 15 },
});
