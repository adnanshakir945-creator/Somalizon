import React, { useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, KeyboardAvoidingView, Platform, ActivityIndicator, Alert, ScrollView, Dimensions } from 'react-native';
import { supabase } from '../lib/supabase';
import { COLORS, SHADOWS, R } from '../constants/Design';
import { PrimaryBtn } from '../components/Buttons';
import { useToast } from '../components/Toast';

const { width: W } = Dimensions.get('window');
const P = COLORS.primary;

// Fire-and-forget: ping every admin's phone so approvals don't sit
// unnoticed. Uses the send-push edge function (one call per admin,
// since it only supports a single recipient).
async function notifyAdminsOfNewSeller(shopName, sellerName) {
  try {
    const { data: admins } = await supabase.from('profiles').select('id').eq('is_admin', true);
    (admins || []).forEach(a => {
      supabase.functions.invoke('send-push', {
        body: {
          toUid: a.id,
          title: 'Ganacsade Cusub Sugaya Ogolaansho',
          body: `${shopName} (${sellerName}) ayaa codsaday inuu ganacsade noqdo.`,
          data: { screen: 'Admin' },
        },
      }).catch(() => {});
    });
  } catch (e) { /* non-critical */ }
}

export default function SignupScreen({ navigation }) {
  const [name, setName]   = useState('');
  const [shop, setShop]   = useState('');
  const [email, setEmail] = useState('');
  const [pass, setPass]   = useState('');
  const [loading, setLoading] = useState(false);
  const showToast = useToast();

  async function handleRegister() {
    if (!name || !shop || !email || !pass) { showToast('Dhammaan buuxi', 'error'); return; }
    setLoading(true);
    const { data, error } = await supabase.auth.signUp({ email: email.trim(), password: pass, options: { data: { name, user_type: 'seller', shop_name: shop } } });
    if (error) { showToast(error.message, 'error'); setLoading(false); return; }
    const uid = data.user?.id;
    if (uid) {
      await supabase.from('profiles').upsert({ id: uid, email: email.trim().toLowerCase(), name, user_type: 'seller', shop_name: shop, seller_status: 'pending' });
      await supabase.from('stores').upsert({ id: uid, name: shop, sellerName: name, sellerEmail: email.trim(), sellerUid: uid, emoji: 'storefront-outline', store_desc: 'Kusoo dhawaada ' + shop, rating: 5.0, followers: 0, verified: false });
      notifyAdminsOfNewSeller(shop, name);
    }
    showToast('Codsigaaga waa la diray! Fadlan xaqiiji email-kaaga.', 'success');
    setLoading(false);
    navigation.navigate('VerifyEmail', { email: email.trim() });
  }

  const FIELDS = [
    { label: 'Magacaaga', val: name, set: setName, ph: 'Magaca Dhabta ah', icon: 'person-outline' },
    { label: 'Magaca Dukaanka', val: shop, set: setShop, ph: 'Somali Store...', icon: 'storefront-outline' },
    { label: 'Email', val: email, set: setEmail, ph: 'email@example.com', icon: 'mail-outline', caps: 'none', kb: 'email-address' },
    { label: 'Password', val: pass, set: setPass, ph: '••••••••', icon: 'lock-closed-outline', sec: true },
  ];

  return (
    <KeyboardAvoidingView style={{ flex: 1, backgroundColor: '#fff' }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={{ flexGrow: 1 }} showsVerticalScrollIndicator={false} keyboardShouldPersistTaps="handled">
        {/* Orange top */}
        <View style={styles.topBand}>
          <View style={styles.waveBg} />
          <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
            <Ionicons name="chevron-back" size={20} color={'#333'} />
          </TouchableOpacity>
          <View style={styles.logoBox}><Ionicons name="storefront-outline" size={34} color={'#333'} /></View>
          <Text style={styles.topTitle}>Ganacsade Cusub</Text>
          <Text style={styles.topSub}>Account samee si aad alaab u iibiyo</Text>
        </View>

        <View style={{ padding: 24 }}>
          {FIELDS.map(f => (
            <View key={f.label} style={{ marginBottom: 16 }}>
              <Text style={styles.label}>{f.label}</Text>
              <View style={styles.inputWrap}>
                <Ionicons name={f.icon} size={18} color={'#333'} style={styles.inputIcon} />
                <TextInput
                  style={styles.input} placeholder={f.ph}
                  placeholderTextColor={COLORS.text3}
                  autoCapitalize={f.caps || 'words'} keyboardType={f.kb || 'default'}
                  secureTextEntry={f.sec || false} value={f.val} onChangeText={f.set}
                />
              </View>
            </View>
          ))}

          <PrimaryBtn label="Account Samee" icon="rocket-outline" onPress={handleRegister} loading={loading} style={{ marginTop: 8 }} />

          <TouchableOpacity style={styles.loginRow} onPress={() => navigation.navigate('Login')}>
            <Text style={styles.loginTxt}>Horey account u leedahay? <Text style={{ color: P, fontWeight: '800' }}>Soo gal</Text></Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  topBand: { backgroundColor: P, paddingTop: 54, paddingBottom: 32, alignItems: 'center', borderBottomLeftRadius: 32, borderBottomRightRadius: 32, overflow: 'hidden', marginBottom: 8 },
  waveBg: { position: 'absolute', width: W * 1.2, height: W * 1.2, borderRadius: W * 0.6, backgroundColor: 'rgba(255,255,255,0.08)', top: -W * 0.5, left: -W * 0.1 },
  backBtn: { position: 'absolute', top: 54, left: 20, width: 38, height: 38, borderRadius: 12, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  backTxt: { color: '#fff', fontSize: 22, fontWeight: '700', lineHeight: 26 },
  logoBox: { width: 72, height: 72, borderRadius: 22, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', marginBottom: 12, ...SHADOWS.card },
  topTitle: { fontSize: 26, fontWeight: '900', color: '#fff', letterSpacing: -0.3 },
  topSub: { color: 'rgba(255,255,255,0.75)', fontSize: 13, marginTop: 4 },
  label: { fontSize: 13, fontWeight: '700', color: COLORS.text, marginBottom: 6 },
  inputWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.input, borderRadius: R.lg, borderWidth: 1.5, borderColor: COLORS.inputBorder, paddingHorizontal: 14 },
  inputIcon: { fontSize: 18, marginRight: 10 },
  input: { flex: 1, paddingVertical: 14, fontSize: 15, color: COLORS.text },
  loginRow: { alignItems: 'center', marginTop: 16 },
  loginTxt: { color: COLORS.text2, fontSize: 14 },
});
