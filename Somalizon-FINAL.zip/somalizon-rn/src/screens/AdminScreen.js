import React, { useEffect, useState, useCallback } from 'react';
import { Ionicons } from '@expo/vector-icons';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  ActivityIndicator, RefreshControl, Alert, TextInput,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { useToast } from '../components/Toast';

const ORANGE = '#FF6B00';

const REASON_LABEL = {
  fraud: 'Waa Been (Fraud)',
  wrong_item: 'Alaab Khaldan',
  inappropriate: 'Aan Habboonayn',
};

function timeFmt(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleDateString('so-SO') + ' ' + d.toLocaleTimeString('so-SO', { hour: '2-digit', minute: '2-digit' });
}

export default function AdminScreen({ navigation }) {
  const { profile } = useAuth();
  const { theme } = useTheme();
  const showToast = useToast();
  const [tab, setTab] = useState('sellers'); // 'sellers' | 'reports' | 'users' | 'commissions'
  const [reports, setReports] = useState([]);
  const [users, setUsers] = useState([]);
  const [pendingSellers, setPendingSellers] = useState([]);
  const [commissionOwed, setCommissionOwed] = useState([]); // [{sellerEmail, sellerName, owed, orderIds}]
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { loadAll(); }, []);

  async function loadAll() {
    setLoading(true);
    const [reportsRes, usersRes, unsettledRes] = await Promise.all([
      supabase.from('reports').select('*').order('created_at', { ascending: false }),
      supabase.from('profiles').select('*').order('created_at', { ascending: false }),
      supabase.from('orders').select('id, sellerEmail, sellerName, commissionAmount, created_at')
        .eq('commissionSettled', false).gt('commissionAmount', 0)
        .order('created_at', { ascending: false }),
    ]);
    const bySeller = {};
    (unsettledRes.data || []).forEach(o => {
      const key = o.sellerEmail;
      if (!bySeller[key]) bySeller[key] = { sellerEmail: o.sellerEmail, sellerName: o.sellerName, owed: 0, orderIds: [] };
      bySeller[key].owed += (o.commissionAmount || 0); // seller received buyer's surcharge too, so owes the full 5%, not half
      bySeller[key].orderIds.push(o.id);
    });
    setCommissionOwed(Object.values(bySeller));
    setReports(reportsRes.data || []);
    setUsers(usersRes.data || []);
    setPendingSellers((usersRes.data || []).filter(u => u.user_type === 'seller' && u.seller_status === 'pending'));
    setLoading(false);
  }

  const onRefresh = useCallback(async () => { setRefreshing(true); await loadAll(); setRefreshing(false); }, []);

  // ── Seller approval actions ──────────────────────────────
  async function decideSeller(u, approve) {
    const { error } = await supabase.from('profiles').update({ seller_status: approve ? 'approved' : 'rejected' }).eq('id', u.id);
    if (error) { showToast(error.message, 'error'); return; }
    await supabase.from('stores').update({ verified: approve }).eq('sellerUid', u.id);
    setPendingSellers(prev => prev.filter(x => x.id !== u.id));
    setUsers(prev => prev.map(x => x.id === u.id ? { ...x, seller_status: approve ? 'approved' : 'rejected' } : x));
    showToast(approve ? 'Ganacsadaha waa la ogolaaday' : 'Ganacsadaha waa la diiday', 'success');
  }

  // ── Commission payout tracking ───────────────────────────
  async function markSellerSettled(s) {
    const { error } = await supabase.from('orders').update({ commissionSettled: true }).in('id', s.orderIds);
    if (error) { showToast(error.message, 'error'); return; }
    setCommissionOwed(prev => prev.filter(x => x.sellerEmail !== s.sellerEmail));
    showToast(`${s.sellerName || s.sellerEmail} waa la calaamadeeyay in la bixiyay`, 'success');
  }

  // ── Reports actions ──────────────────────────────────────
  async function dismissReport(r) {
    const { error } = await supabase.from('reports').update({ status: 'dismissed' }).eq('id', r.id);
    if (error) { showToast(error.message, 'error'); return; }
    setReports(prev => prev.map(x => x.id === r.id ? { ...x, status: 'dismissed' } : x));
    showToast('Sheegashada waa la iska indhatiray', 'success');
  }

  function removeReportedProduct(r) {
    Alert.alert('Ka Saar Alaabta', `Ma hubtaa inaad ka saareyso "${r.prodName}" suuqa?`, [
      { text: 'Maya', style: 'cancel' },
      {
        text: 'Haa, Ka Saar', style: 'destructive', onPress: async () => {
          const { error } = await supabase.from('products').delete().eq('id', r.prodId);
          if (error) { showToast(error.message, 'error'); return; }
          await supabase.from('reports').update({ status: 'removed' }).eq('id', r.id);
          setReports(prev => prev.map(x => x.id === r.id ? { ...x, status: 'removed' } : x));
          showToast('Alaabta waa laga saaray suuqa', 'success');
        }
      }
    ]);
  }

  // ── Users actions ────────────────────────────────────────
  function toggleBan(u) {
    const goingToBan = !u.banned;
    Alert.alert(
      goingToBan ? 'Xannib Isticmaale' : 'Ka Saar Xannibaadda',
      goingToBan ? `Ma hubtaa inaad xannibeyso ${u.name || u.email}?` : `Ka saar xannibaadda ${u.name || u.email}?`,
      [
        { text: 'Maya', style: 'cancel' },
        {
          text: 'Haa', style: goingToBan ? 'destructive' : 'default', onPress: async () => {
            const { error } = await supabase.from('profiles').update({ banned: goingToBan }).eq('id', u.id);
            if (error) { showToast(error.message, 'error'); return; }
            setUsers(prev => prev.map(x => x.id === u.id ? { ...x, banned: goingToBan } : x));
            showToast(goingToBan ? 'Isticmaalaha waa la xannibay' : 'Xannibaaddii waa laga saaray', 'success');
          }
        }
      ]
    );
  }

  const pendingReports = reports.filter(r => r.status === 'pending');
  const resolvedReports = reports.filter(r => r.status !== 'pending');
  const filteredUsers = users.filter(u =>
    !search.trim() ||
    (u.name || '').toLowerCase().includes(search.toLowerCase()) ||
    (u.email || '').toLowerCase().includes(search.toLowerCase())
  );

  function renderReport(r) {
    const resolved = r.status !== 'pending';
    return (
      <View key={r.id} style={[styles.card, { backgroundColor: theme.card }, resolved && { opacity: 0.55 }]}>
        <View style={styles.cardHeader}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1 }}>
            <Ionicons name="flag-outline" size={14} color={'#ef4444'} />
            <Text style={[styles.prodName, { color: theme.text }]} numberOfLines={1}>{r.prodName}</Text>
          </View>
          <Text style={[styles.date, { color: theme.text2 }]}>{timeFmt(r.created_at)}</Text>
        </View>
        <Text style={[styles.metaLine, { color: theme.text2 }]}>Ganacsade: {r.sellerName || r.sellerEmail}</Text>
        <Text style={[styles.metaLine, { color: theme.text2 }]}>Sababta: {REASON_LABEL[r.reason] || r.reason}</Text>
        <Text style={[styles.metaLine, { color: theme.text2 }]}>Sheegay: {r.reporterName || r.reporterEmail}</Text>
        {resolved ? (
          <View style={styles.resolvedBadge}>
            <Ionicons name="checkmark-circle-outline" size={13} color="#22c55e" />
            <Text style={styles.resolvedTxt}>
              {r.status === 'removed' ? 'Alaabta waa laga saaray' : 'La iska indhatiray'}
            </Text>
          </View>
        ) : (
          <View style={styles.actionRow}>
            <TouchableOpacity style={[styles.actionBtn, { backgroundColor: '#ef4444' }]} onPress={() => removeReportedProduct(r)}>
              <Ionicons name="trash-outline" size={13} color="#fff" />
              <Text style={styles.actionTxt}>Ka Saar Alaabta</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.actionBtn, { backgroundColor: '#eee' }]} onPress={() => dismissReport(r)}>
              <Ionicons name="close-outline" size={13} color="#555" />
              <Text style={[styles.actionTxt, { color: '#555' }]}>Iska Indhatir</Text>
            </TouchableOpacity>
          </View>
        )}
      </View>
    );
  }

  function renderSeller({ item: u }) {
    return (
      <View style={[styles.card, { backgroundColor: theme.card }]}>
        <View style={styles.cardHeader}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1 }}>
            <Ionicons name="storefront-outline" size={14} color={theme.text} />
            <Text style={[styles.prodName, { color: theme.text }]} numberOfLines={1}>{u.shop_name || u.name}</Text>
          </View>
          <Text style={[styles.date, { color: theme.text2 }]}>{timeFmt(u.created_at)}</Text>
        </View>
        <Text style={[styles.metaLine, { color: theme.text2 }]}>Magaca: {u.name}</Text>
        <Text style={[styles.metaLine, { color: theme.text2 }]}>{u.email}</Text>
        <View style={styles.actionRow}>
          <TouchableOpacity style={[styles.actionBtn, { backgroundColor: '#22c55e' }]} onPress={() => decideSeller(u, true)}>
            <Ionicons name="checkmark-outline" size={13} color="#fff" />
            <Text style={styles.actionTxt}>Ogolow</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.actionBtn, { backgroundColor: '#ef4444' }]} onPress={() => decideSeller(u, false)}>
            <Ionicons name="close-outline" size={13} color="#fff" />
            <Text style={styles.actionTxt}>Diid</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  function renderUser({ item: u }) {
    return (
      <View style={[styles.card, { backgroundColor: theme.card }]}>
        <View style={styles.cardHeader}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1 }}>
            <Ionicons name={u.user_type === 'seller' ? 'storefront-outline' : 'person-outline'} size={14} color={theme.text} />
            <Text style={[styles.prodName, { color: theme.text }]} numberOfLines={1}>{u.name || u.email}</Text>
          </View>
          {u.banned && (
            <View style={styles.bannedBadge}>
              <Text style={styles.bannedTxt}>Xannibban</Text>
            </View>
          )}
        </View>
        <Text style={[styles.metaLine, { color: theme.text2 }]}>{u.email}</Text>
        <Text style={[styles.metaLine, { color: theme.text2 }]}>Nooca: {u.user_type === 'seller' ? 'Ganacsade' : 'Macmiil'}</Text>
        <TouchableOpacity
          style={[styles.actionBtn, { backgroundColor: u.banned ? '#22c55e' : '#ef4444', marginTop: 10, alignSelf: 'flex-start' }]}
          onPress={() => toggleBan(u)}
        >
          <Ionicons name={u.banned ? 'lock-open-outline' : 'lock-closed-outline'} size={13} color="#fff" />
          <Text style={styles.actionTxt}>{u.banned ? 'Ka Saar Xannibaadda' : 'Xannib'}</Text>
        </TouchableOpacity>
      </View>
    );
  }

  if (!profile?.is_admin) {
    return (
      <View style={[styles.wrap, { backgroundColor: theme.bg, alignItems: 'center', justifyContent: 'center' }]}>
        <Ionicons name="lock-closed-outline" size={48} color={'#333'} />
        <Text style={{ color: theme.text, marginTop: 12, fontWeight: '700' }}>Ma haysatid oggolaanshaha halkan</Text>
        <TouchableOpacity style={{ marginTop: 16 }} onPress={() => navigation.goBack()}>
          <Text style={{ color: ORANGE, fontWeight: '700' }}>Ka noqo</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="chevron-back" size={20} color={'#333'} /></TouchableOpacity>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Ionicons name="shield-checkmark-outline" size={18} color={theme.text} />
          <Text style={[styles.title, { color: theme.text }]}>Maamulka</Text>
        </View>
        <View style={{ width: 30 }} />
      </View>

      <View style={[styles.tabs, { borderBottomColor: theme.border }]}>
        <TouchableOpacity style={[styles.tab, tab === 'sellers' && styles.tabOn]} onPress={() => setTab('sellers')}>
          <Ionicons name="storefront-outline" size={14} color={tab === 'sellers' ? ORANGE : theme.text2} />
          <Text style={[styles.tabTxt, { color: tab === 'sellers' ? ORANGE : theme.text2 }]}>
            Ganacsato {pendingSellers.length > 0 ? `(${pendingSellers.length})` : ''}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tab, tab === 'reports' && styles.tabOn]} onPress={() => setTab('reports')}>
          <Ionicons name="flag-outline" size={14} color={tab === 'reports' ? ORANGE : theme.text2} />
          <Text style={[styles.tabTxt, { color: tab === 'reports' ? ORANGE : theme.text2 }]}>
            Sheegashada {pendingReports.length > 0 ? `(${pendingReports.length})` : ''}
          </Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tab, tab === 'users' && styles.tabOn]} onPress={() => setTab('users')}>
          <Ionicons name="people-outline" size={14} color={tab === 'users' ? ORANGE : theme.text2} />
          <Text style={[styles.tabTxt, { color: tab === 'users' ? ORANGE : theme.text2 }]}>Isticmaalayaasha</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tab, tab === 'commissions' && styles.tabOn]} onPress={() => setTab('commissions')}>
          <Ionicons name="cash-outline" size={14} color={tab === 'commissions' ? ORANGE : theme.text2} />
          <Text style={[styles.tabTxt, { color: tab === 'commissions' ? ORANGE : theme.text2 }]}>Lacagta Sugan</Text>
        </TouchableOpacity>
      </View>

      {loading ? <ActivityIndicator color={ORANGE} style={{ marginTop: 40 }} /> : tab === 'sellers' ? (
        <FlatList
          data={pendingSellers}
          keyExtractor={u => String(u.id)}
          contentContainerStyle={{ padding: 14 }}
          renderItem={renderSeller}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={ORANGE} />}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="storefront-outline" size={48} color={'#333'} />
              <Text style={[styles.emptyTxt, { color: theme.text2 }]}>Ganacsato sugaya ogolaansho ma jiraan</Text>
            </View>
          }
        />
      ) : tab === 'reports' ? (
        <FlatList
          data={[...pendingReports, ...resolvedReports]}
          keyExtractor={r => String(r.id)}
          contentContainerStyle={{ padding: 14 }}
          renderItem={({ item }) => renderReport(item)}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={ORANGE} />}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="shield-checkmark-outline" size={48} color={'#333'} />
              <Text style={[styles.emptyTxt, { color: theme.text2 }]}>Sheegasho lama helin</Text>
            </View>
          }
        />
      ) : tab === 'users' ? (
        <FlatList
          data={filteredUsers}
          keyExtractor={u => String(u.id)}
          contentContainerStyle={{ padding: 14 }}
          ListHeaderComponent={
            <TextInput
              style={[styles.search, { backgroundColor: theme.input, color: theme.inputText }]}
              placeholder="Raadi magac ama email..." placeholderTextColor="#999"
              value={search} onChangeText={setSearch}
            />
          }
          renderItem={renderUser}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={ORANGE} />}
          ListEmptyComponent={<Text style={{ color: theme.text2, textAlign: 'center', marginTop: 30 }}>Isticmaale lama helin</Text>}
        />
      ) : (
        <FlatList
          data={commissionOwed}
          keyExtractor={s => s.sellerEmail}
          contentContainerStyle={{ padding: 14 }}
          renderItem={({ item: s }) => (
            <View style={[styles.card, { backgroundColor: theme.card }]}>
              <View style={styles.cardHeader}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6, flex: 1 }}>
                  <Ionicons name="person-outline" size={14} color={theme.text} />
                  <Text style={[styles.prodName, { color: theme.text }]} numberOfLines={1}>{s.sellerName || s.sellerEmail}</Text>
                </View>
              </View>
              <Text style={[styles.metaLine, { color: theme.text2 }]}>{s.sellerEmail}</Text>
              <Text style={[styles.metaLine, { color: theme.text2 }]}>{s.orderIds.length} dalab oo lacagta sugan</Text>
              <Text style={{ color: ORANGE, fontWeight: '800', fontSize: 16, marginTop: 6 }}>Wuxuu ku leeyahay: {s.owed.toLocaleString()} Sh.So</Text>
              <TouchableOpacity
                style={[styles.actionBtn, { backgroundColor: '#22c55e', alignSelf: 'flex-start', marginTop: 10 }]}
                onPress={() => markSellerSettled(s)}
              >
                <Ionicons name="checkmark-outline" size={13} color="#fff" />
                <Text style={styles.actionTxt}>Waa La Bixiyay</Text>
              </TouchableOpacity>
            </View>
          )}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={ORANGE} />}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="cash-outline" size={48} color={'#333'} />
              <Text style={[styles.emptyTxt, { color: theme.text2 }]}>Ganacsato lacag sugan ma leh — dhammaan waa la bixiyay</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52, borderBottomWidth: 1 },
  title: { fontSize: 17, fontWeight: '700' },
  tabs: { flexDirection: 'row', borderBottomWidth: 1 },
  tab: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, paddingVertical: 12 },
  tabOn: { borderBottomWidth: 2, borderBottomColor: ORANGE },
  tabTxt: { fontWeight: '700', fontSize: 13 },
  search: { borderRadius: 12, padding: 12, marginBottom: 12, fontSize: 14 },
  card: { borderRadius: 16, padding: 14, marginBottom: 12, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  prodName: { fontWeight: '700', fontSize: 14 },
  date: { fontSize: 11 },
  metaLine: { fontSize: 12, marginBottom: 3 },
  actionRow: { flexDirection: 'row', gap: 8, marginTop: 8 },
  actionBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10 },
  actionTxt: { color: '#fff', fontWeight: '700', fontSize: 12 },
  resolvedBadge: { flexDirection: 'row', alignItems: 'center', gap: 5, marginTop: 6 },
  resolvedTxt: { color: '#22c55e', fontWeight: '700', fontSize: 12 },
  bannedBadge: { backgroundColor: '#ef444422', paddingHorizontal: 8, paddingVertical: 3, borderRadius: 8 },
  bannedTxt: { color: '#ef4444', fontWeight: '700', fontSize: 10 },
  empty: { alignItems: 'center', marginTop: 80 },
  emptyTxt: { fontSize: 15, marginTop: 10 },
});
