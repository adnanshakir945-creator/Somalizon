import React, { useEffect, useState, useRef } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, Dimensions, ActivityIndicator, Alert, Share } from 'react-native';
import { Video } from 'expo-av';

import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { COLORS } from '../constants/Design';
import { useToast } from '../components/Toast';

const P = COLORS.primary;
const { height: H, width: W } = Dimensions.get('window');

function fmtNum(n) { if (!n) return '0'; if (n >= 1000000) return (n/1000000).toFixed(1)+'M'; if (n >= 1000) return (n/1000).toFixed(1)+'K'; return String(n); }

function VideoItem({ item: v, isActive, profile, onLike, onComment, onProfile, onShare }) {
  const ref = useRef(null);
  const [followed, setFollowed] = useState(false);
  const [paused, setPaused] = useState(false);
  const [showIcon, setShowIcon] = useState(false);

  useEffect(() => {
    if (!ref.current) return;
    if (isActive && !paused) ref.current.playAsync().catch(()=>{});
    else ref.current.pauseAsync().catch(()=>{});
  }, [isActive, paused]);

  // Reset manual pause whenever this item stops being the active one
  useEffect(() => { if (!isActive) setPaused(false); }, [isActive]);

  function togglePlayPause() {
    setPaused(p => !p);
    setShowIcon(true);
    setTimeout(() => setShowIcon(false), 600);
  }

  async function toggleFollow() {
    if (!profile?.email) return;
    if (followed) {
      await supabase.from('follows').delete().eq('user_email', profile.email).eq('seller_email', v.userEmail || '');
      setFollowed(false);
    } else {
      await supabase.from('follows').upsert({ user_email: profile.email, seller_email: v.userEmail || '' });
      setFollowed(true);
    }
  }

  return (
    <View style={styles.videoItem}>
      <TouchableOpacity activeOpacity={1} style={StyleSheet.absoluteFill} onPress={togglePlayPause}>
        <Video ref={ref} source={{ uri: v.url }} style={styles.video} resizeMode="cover" shouldPlay={isActive && !paused} isLooping isMuted={false} />
      </TouchableOpacity>

      {showIcon && (
        <View style={styles.playPauseOverlay} pointerEvents="none">
          <Text style={styles.playPauseIcon}>{paused ? '▶️' : '⏸️'}</Text>
        </View>
      )}

      {/* Gradient overlay */}
      <View style={styles.gradient} />

      {/* Info */}
      <View style={styles.overlay}>
        <View style={styles.leftInfo}>
          {/* Avatar + Name — tappable */}
          <TouchableOpacity style={styles.userRow} onPress={() => onProfile(v)}>
            <View style={styles.userAvatar}><Text style={styles.userAvatarTxt}>{(v.user?.[0]||'?').toUpperCase()}</Text></View>
            <Text style={styles.userName}>@{v.user}</Text>
          </TouchableOpacity>

          {/* Follow button */}
          {profile?.email !== v.userEmail && (
            <TouchableOpacity style={[styles.followBtn, followed && styles.followedBtn]} onPress={toggleFollow}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
              {followed && <Ionicons name="checkmark" size={12} color="#fff" />}
              {!followed && <Ionicons name="add" size={12} color="#fff" />}
              <Text style={styles.followTxt}>{followed ? 'Following' : 'Follow'}</Text>
            </View>
            </TouchableOpacity>
          )}

          {v.desc && <Text style={styles.videoDesc} numberOfLines={2}>{v.desc}</Text>}
          {v.prodName && (
            <View style={styles.prodTag}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
                <Ionicons name="bag-handle-outline" size={12} color="#fff" />
                <Text style={styles.prodTagTxt}>{v.prodName}</Text>
              </View>
            </View>
          )}
        </View>

        {/* Right actions */}
        <View style={styles.rightActions}>
          <TouchableOpacity style={styles.actionBtn} onPress={() => onLike(v)}>
            <Ionicons name="heart" size={26} color={'#fff'} />
            <Text style={styles.actionCnt}>{fmtNum(v.likes)}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionBtn} onPress={() => onComment(v)}>
            <Ionicons name="chatbubble-outline" size={26} color={'#fff'} />
            <Text style={styles.actionCnt}>{fmtNum(v.comments)}</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.actionBtn} onPress={() => onShare(v)}>
            <Ionicons name="arrow-redo-outline" size={26} color={'#fff'} />
            <Text style={styles.actionCnt}>Share</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

export default function WatchScreen({ navigation }) {
  const { profile } = useAuth();
  const showToast = useToast();
  const [videos, setVideos]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeIdx, setActiveIdx] = useState(0);
  const [isScreenFocused, setIsScreenFocused] = useState(true);

  useEffect(() => {
    loadVideos();
    const unsubFocus   = navigation.addListener('focus',  () => setIsScreenFocused(true));
    const unsubBlur    = navigation.addListener('blur',   () => setIsScreenFocused(false));

    const ch = supabase.channel('watch-feed')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'videos' }, payload => {
        if (payload.eventType === 'INSERT') setVideos(prev => [payload.new, ...prev]);
        if (payload.eventType === 'UPDATE') setVideos(prev => prev.map(v => v.id === payload.new.id ? { ...v, ...payload.new } : v));
        if (payload.eventType === 'DELETE') setVideos(prev => prev.filter(v => v.id !== payload.old.id));
      })
      .subscribe();

    return () => {
      unsubFocus();
      unsubBlur();
      supabase.removeChannel(ch);
    };
  }, []);

  async function loadVideos() {
    const { data } = await supabase.from('videos').select('*').order('created_at', { ascending: false });
    setVideos(data || []); setLoading(false);
  }

  async function handleLike(v) {
    if (!profile) { showToast('Marka hore soo gal', 'error'); return; }
    const newLikes = (v.likes || 0) + 1;
    setVideos(prev => prev.map(vid => vid.id === v.id ? { ...vid, likes: newLikes } : vid));
    await supabase.from('videos').update({ likes: newLikes }).eq('id', v.id);
    await supabase.from('video_interactions').upsert({ video_id: v.id, user_email: profile.email, type: 'like' });
  }

  if (loading) return (
    <View style={styles.center}>
      <ActivityIndicator color={P} size="large" />
    </View>
  );

  if (!videos.length) return (
    <View style={styles.center}>
      <Ionicons name="film-outline" size={56} color={'#fff'} />
      <Text style={{ color: '#fff', fontSize: 16, fontWeight: '700' }}>Video ma jiro weli</Text>
    </View>
  );

  return (
    <View style={styles.wrap}>
      {/* Header overlay */}
      <View style={styles.header}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Ionicons name="film-outline" size={20} color="#fff" />
          <Text style={styles.headerTitle}>Watch</Text>
        </View>
        <View style={styles.headerRight}>
          <TouchableOpacity style={styles.headerBtn} onPress={() => navigation.navigate('WatchSearch')}>
            <Ionicons name="search-outline" size={18} color={'#fff'} />
          </TouchableOpacity>
          {profile?.user_type === 'seller' && (
            <TouchableOpacity style={[styles.headerBtn, styles.headerBtnOrange]} onPress={() => navigation.navigate('UploadVideo')}>
              <Ionicons name="add" size={22} color={'#fff'} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      <FlatList
        data={videos} keyExtractor={v => String(v.id)}
        pagingEnabled snapToInterval={H} decelerationRate="fast"
        showsVerticalScrollIndicator={false}
        onViewableItemsChanged={({ viewableItems }) => { if (viewableItems.length > 0) setActiveIdx(viewableItems[0].index); }}
        viewabilityConfig={{ itemVisiblePercentThreshold: 80 }}
        renderItem={({ item, index }) => (
          <VideoItem
            item={item} isActive={index === activeIdx && isScreenFocused} profile={profile}
            onLike={handleLike}
            onShare={v => Share.share({ message: `${v.desc || 'Fiiri video-kan'} — ${v.url}`, url: v.url })}
            onComment={v => navigation.navigate('Comments', { videoId: v.id, videoDesc: v.desc })}
            onProfile={v => navigation.navigate('UserProfile', { email: v.userEmail || '', name: v.user || '' })}
          />
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#000' },
  center: { flex: 1, backgroundColor: '#000', alignItems: 'center', justifyContent: 'center' },
  header: { position: 'absolute', top: 0, left: 0, right: 0, zIndex: 99, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 52, paddingBottom: 12 },
  headerTitle: { color: '#fff', fontSize: 20, fontWeight: '900', letterSpacing: -0.3, textShadowColor: 'rgba(0,0,0,0.5)', textShadowRadius: 8 },
  headerRight: { flexDirection: 'row', gap: 8 },
  headerBtn: { width: 38, height: 38, borderRadius: 12, backgroundColor: 'rgba(0,0,0,0.4)', alignItems: 'center', justifyContent: 'center' },
  headerBtnOrange: { backgroundColor: P },
  videoItem: { width: W, height: H, position: 'relative' },
  video: { width: '100%', height: '100%' },
  playPauseOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center' },
  playPauseIcon: { fontSize: 64, textShadowColor: 'rgba(0,0,0,0.5)', textShadowRadius: 12 },
  gradient: { position: 'absolute', bottom: 0, left: 0, right: 0, height: H * 0.55, backgroundColor: 'transparent',
    // Simple gradient-like using shadow
  },
  overlay: { position: 'absolute', bottom: 0, left: 0, right: 0, flexDirection: 'row', alignItems: 'flex-end', padding: 16, paddingBottom: 100 },
  leftInfo: { flex: 1, marginRight: 12 },
  userRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 8 },
  followBtn: { backgroundColor: 'rgba(255,255,255,0.25)', borderWidth: 1, borderColor: '#fff', paddingHorizontal: 14, paddingVertical: 5, borderRadius: 20, alignSelf: 'flex-start', marginBottom: 8 },
  followedBtn: { backgroundColor: COLORS.primary, borderColor: COLORS.primary },
  followTxt: { color: '#fff', fontWeight: '700', fontSize: 12 },
  userAvatar: { width: 36, height: 36, borderRadius: 18, backgroundColor: P, alignItems: 'center', justifyContent: 'center', borderWidth: 2, borderColor: '#fff' },
  userAvatarTxt: { color: '#fff', fontWeight: '800', fontSize: 14 },
  userName: { color: '#fff', fontWeight: '800', fontSize: 15, textShadowColor: 'rgba(0,0,0,0.6)', textShadowRadius: 6 },
  videoDesc: { color: '#eee', fontSize: 13, lineHeight: 18, marginBottom: 8, textShadowColor: 'rgba(0,0,0,0.6)', textShadowRadius: 6 },
  prodTag: { backgroundColor: P, paddingHorizontal: 12, paddingVertical: 5, borderRadius: 20, alignSelf: 'flex-start' },
  prodTagTxt: { color: '#fff', fontWeight: '700', fontSize: 12 },
  rightActions: { alignItems: 'center', gap: 20 },
  actionBtn: { alignItems: 'center' },
  actionIco: { fontSize: 30 },
  actionCnt: { color: '#fff', fontSize: 11, fontWeight: '700', marginTop: 3, textShadowColor: 'rgba(0,0,0,0.6)', textShadowRadius: 6 },
});
