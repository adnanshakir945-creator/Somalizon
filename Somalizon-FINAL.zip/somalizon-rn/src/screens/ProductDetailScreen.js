import React, { useEffect, useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet, Image, ActivityIndicator, Alert, TextInput, Share } from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { COLORS, SHADOWS, R } from '../constants/Design';
import { PrimaryBtn, SecondaryBtn } from '../components/Buttons';
import ImageViewer from '../components/ImageViewer';
import { useToast } from '../components/Toast';
import { toIconName } from '../constants/iconMap';
import { useCurrency } from '../contexts/CurrencyContext';

const P = COLORS.primary;

export default function ProductDetailScreen({ route, navigation }) {
  const { product: p } = route.params;
  const { profile }    = useAuth();
  const { addToCart }  = useCart();
  const { formatPrice } = useCurrency();
  const showToast = useToast();
  const [reviews, setReviews]       = useState([]);
  const [loadingRevs, setLoadingRevs] = useState(true);
  const [myRating, setMyRating]     = useState(5);
  const [myReview, setMyReview]     = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [ordering, setOrdering]     = useState(false);
  const [showOrder, setShowOrder]   = useState(false);
  const [phone, setPhone]           = useState('');
  const [address, setAddress]       = useState('');
  const [qty, setQty]               = useState(1);
  const [imgViewer, setImgViewer]   = useState(false);

  useEffect(() => { loadReviews(); }, []);

  async function loadReviews() {
    const { data } = await supabase.from('reviews').select('*').eq('prodId', p.id).order('created_at', { ascending: false });
    setReviews(data || []); setLoadingRevs(false);
  }

  async function submitReview() {
    if (!profile) { showToast('Marka hore soo gal', 'error'); return; }
    if (!myReview.trim()) { showToast('Qiimaynta qor', 'error'); return; }
    setSubmitting(true);
    await supabase.from('reviews').insert({ prodId: p.id, storeId: p.storeId, prod: p.name, buyerName: profile.name, buyerEmail: profile.email, stars: myRating, text: myReview.trim() });
    setMyReview(''); await loadReviews(); setSubmitting(false);
    showToast('Qiimayntii la keydiyay!', 'success');
  }

  async function placeOrder() {
    if (!profile) { showToast('Marka hore soo gal', 'error'); return; }
    if (!phone.trim() || !address.trim()) { showToast('Dhammaan buuxi', 'error'); return; }
    setOrdering(true);
    await supabase.from('orders').insert({ prodId: p.id, prodName: p.name, prodEmoji: toIconName(p.emoji), qty, totalPrice: p.price * qty, buyerName: profile.name, buyerEmail: profile.email, sellerEmail: p.sellerEmail, sellerName: p.seller, phone: phone.trim(), address: address.trim(), status: 'La Diray' });
    setOrdering(false); setShowOrder(false);
    showToast(`Codsiga La Diray! ${qty}x ${p.name} — ${formatPrice(p.price*qty)}`, 'success');
  }

  async function shareProduct() {
    try {
      await Share.share({
        message: `${p.name} — Sh.So ${(p.price || 0).toLocaleString()}\nKa hel Somalizon: ${p.seller ? 'Ganacsade: ' + p.seller : ''}`,
      });
    } catch (e) {
      showToast('Wax lama wadaagi karin', 'error');
    }
  }

  async function reportProduct() {
    if (!profile) { showToast('Marka hore soo gal', 'error'); return; }
    Alert.alert('Sheeg Alaabtan', 'Waa maxay sababta?', [
      { text: 'Waa Been (Fraud)', onPress: () => sendReport('fraud') },
      { text: 'Alaab Xarrago Badan/Khaldan', onPress: () => sendReport('wrong_item') },
      { text: 'Waa Xun/Aan Habboonayn', onPress: () => sendReport('inappropriate') },
      { text: 'Ka Noqo', style: 'cancel' },
    ]);
  }

  async function sendReport(reason) {
    const { error } = await supabase.from('reports').insert({
      prodId: p.id, prodName: p.name, sellerEmail: p.sellerEmail, sellerName: p.seller,
      reporterEmail: profile.email, reporterName: profile.name, reason, status: 'pending',
    });
    if (error) showToast(error.message, 'error');
    else showToast('Waad ku mahadsan tahay — waan eegi doonaa.', 'success');
  }

  const totalStr = formatPrice(p.price * qty);

  return (
    <View style={{ flex: 1, backgroundColor: COLORS.bg }}>
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Image hero */}
        <TouchableOpacity onPress={() => p.img && setImgViewer(true)} activeOpacity={p.img ? 0.9 : 1}>
          <View style={styles.imgHero}>
            {p.img
              ? <Image source={{ uri: p.img }} style={styles.img} resizeMode="cover" />
              : <View style={styles.imgPlaceholder}><Ionicons name={toIconName(p.emoji)} size={80} color={'#333'} /></View>
            }
            <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
              <Ionicons name="chevron-back" size={20} color={'#333'} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.reportBtn} onPress={reportProduct}>
              <Ionicons name="flag-outline" size={18} color={'#333'} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.shareBtn} onPress={shareProduct}>
              <Ionicons name="share-social-outline" size={18} color={'#333'} />
            </TouchableOpacity>
            {p.img && <View style={styles.zoomHint}><View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}><Ionicons name="search-outline" size={12} color={styles.zoomTxt.color} /><Text style={styles.zoomTxt}>Dheeri</Text></View></View>}
            {p.badge && <View style={styles.badge}><Text style={styles.badgeTxt}>{p.badge}</Text></View>}
          </View>
        </TouchableOpacity>

        <View style={styles.body}>
          {/* Title + price */}
          <View style={styles.titleRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.prodName}>{p.name}</Text>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Ionicons name="storefront-outline" size={13} color={styles.seller.color} /><Text style={styles.seller}>{p.seller}</Text></View>
            </View>
            <View style={styles.priceBox}>
              <Text style={styles.priceNum}>{formatPrice(p.price || 0)}</Text>
            </View>
          </View>

          <View style={styles.ratingRow}>
            <View style={{ flexDirection: 'row' }}>{Array.from({ length: Math.round(p.rating || 0) }).map((_, i) => <Ionicons key={i} name="star" size={14} color="#FFB800" />)}</View>
            <Text style={styles.ratingTxt}>{p.rating} ({p.revs || 0} qiimayn)</Text>
          </View>

          {p.desc && <Text style={styles.desc}>{p.desc}</Text>}

          {/* Qty */}
          <View style={styles.qtyCard}>
            <Text style={styles.qtyLabel}>Tirada</Text>
            <View style={styles.qtyControls}>
              <TouchableOpacity style={styles.qtyBtn} onPress={() => setQty(q => Math.max(1,q-1))}>
                <Text style={styles.qtyBtnTxt}>−</Text>
              </TouchableOpacity>
              <Text style={styles.qtyNum}>{qty}</Text>
              <TouchableOpacity style={[styles.qtyBtn, styles.qtyBtnAdd]} onPress={() => setQty(q => q+1)}>
                <Text style={[styles.qtyBtnTxt, { color: '#fff' }]}>+</Text>
              </TouchableOpacity>
            </View>
            <Text style={styles.qtyTotal}>Wadarta: <Text style={{ color: P, fontWeight: '800' }}>{totalStr}</Text></Text>
          </View>

          {/* Buttons */}
          <PrimaryBtn label={`Dalbo — ${totalStr}`} icon="cart-outline" onPress={() => setShowOrder(!showOrder)} style={{ marginBottom: 10 }} />
          <SecondaryBtn label="Basket Ku Dar" icon="bag-handle-outline" onPress={() => { addToCart({ ...p, qty: 1 }); showToast('Kaydiyaha lagu daray!', 'success'); }} style={{ marginBottom: 16 }} />

          {/* Order form */}
          {showOrder && (
            <View style={styles.orderForm}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="clipboard-outline" size={15} color={styles.orderFormTitle.color} /><Text style={styles.orderFormTitle}>Macluumaadka Dalabka</Text></View>
              <View style={styles.inputWrap}>
                <Ionicons name="call-outline" size={20} color={'#333'} />
                <TextInput style={styles.input} placeholder="Telefoonka" placeholderTextColor={COLORS.text3} keyboardType="phone-pad" value={phone} onChangeText={setPhone} />
              </View>
              <View style={styles.inputWrap}>
                <Ionicons name="location-outline" size={20} color={'#333'} />
                <TextInput style={styles.input} placeholder="Cinwaanka (Xaafad, Guri)" placeholderTextColor={COLORS.text3} value={address} onChangeText={setAddress} />
              </View>
              <TouchableOpacity style={styles.confirmBtn} onPress={placeOrder} disabled={ordering}>
                {ordering ? <ActivityIndicator color="#fff" /> : <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="checkmark-circle-outline" size={16} color={styles.confirmTxt.color} /><Text style={styles.confirmTxt}>Xaqiiji Dalabka</Text></View>}
              </TouchableOpacity>
            </View>
          )}

          {/* Divider */}
          <View style={styles.divider} />

          {/* Reviews */}
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="chatbubble-outline" size={15} color={styles.secTitle.color} /><Text style={styles.secTitle}>Qiimaynta ({reviews.length})</Text></View>
          <View style={styles.starsRow}>
            {[1,2,3,4,5].map(s => (
              <TouchableOpacity key={s} onPress={() => setMyRating(s)}>
                <Ionicons name="star" size={20} color={'#333'} />
              </TouchableOpacity>
            ))}
          </View>
          <View style={styles.inputWrap}>
            <TextInput style={[styles.input, { height: 80 }]} multiline placeholder="Soo qor qiimayntaada..." placeholderTextColor={COLORS.text3} value={myReview} onChangeText={setMyReview} />
          </View>
          <TouchableOpacity style={styles.revBtn} onPress={submitReview} disabled={submitting}>
            {submitting ? <ActivityIndicator color="#fff" /> : <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Text style={styles.revBtnTxt}>Dir Qiimaynta</Text><Ionicons name="chevron-forward" size={13} color={styles.revBtnTxt.color} /></View>}
          </TouchableOpacity>

          {loadingRevs
            ? <ActivityIndicator color={P} style={{ marginTop: 20 }} />
            : reviews.map(r => (
              <View key={r.id} style={styles.revCard}>
                <View style={styles.revTop}>
                  <View style={styles.revAvatar}><Text style={styles.revAvatarTxt}>{(r.buyerName?.[0]||'?').toUpperCase()}</Text></View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.revName}>{r.buyerName}</Text>
                    <View style={{ flexDirection: 'row' }}>{Array.from({ length: r.stars || 0 }).map((_, i) => <Ionicons key={i} name="star" size={12} color="#FFB800" />)}</View>
                  </View>
                </View>
                <Text style={styles.revText}>{r.text}</Text>
              </View>
            ))
          }
          <View style={{ height: 20 }} />
        </View>
      </ScrollView>
      <ImageViewer uri={p.img} visible={imgViewer} onClose={() => setImgViewer(false)} />
    </View>
  );
}

const styles = StyleSheet.create({
  imgHero: { height: 320, backgroundColor: COLORS.input, position: 'relative' },
  img: { width: '100%', height: '100%' },
  imgPlaceholder: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  backBtn: { position: 'absolute', top: 52, left: 16, width: 38, height: 38, borderRadius: 13, backgroundColor: 'rgba(255,255,255,0.9)', alignItems: 'center', justifyContent: 'center', ...SHADOWS.sm },
  reportBtn: { position: 'absolute', top: 52, right: 16, width: 38, height: 38, borderRadius: 13, backgroundColor: 'rgba(255,255,255,0.9)', alignItems: 'center', justifyContent: 'center', ...SHADOWS.sm },
  shareBtn: { position: 'absolute', top: 52, right: 62, width: 38, height: 38, borderRadius: 13, backgroundColor: 'rgba(255,255,255,0.9)', alignItems: 'center', justifyContent: 'center', ...SHADOWS.sm },
  backTxt: { color: P, fontSize: 22, fontWeight: '700', lineHeight: 26 },
  zoomHint: { position: 'absolute', bottom: 12, right: 12, backgroundColor: 'rgba(0,0,0,0.4)', paddingHorizontal: 10, paddingVertical: 4, borderRadius: R.full },
  zoomTxt: { color: '#fff', fontSize: 11, fontWeight: '600' },
  badge: { position: 'absolute', top: 52, right: 16, backgroundColor: P, paddingHorizontal: 12, paddingVertical: 5, borderRadius: R.full },
  badgeTxt: { color: '#fff', fontWeight: '800', fontSize: 12 },
  body: { backgroundColor: '#fff', borderTopLeftRadius: 28, borderTopRightRadius: 28, marginTop: -24, padding: 20 },
  titleRow: { flexDirection: 'row', alignItems: 'flex-start', marginBottom: 8 },
  prodName: { fontSize: 20, fontWeight: '900', color: COLORS.text, letterSpacing: -0.3, lineHeight: 26, marginBottom: 4 },
  seller: { color: COLORS.text2, fontSize: 13 },
  priceBox: { alignItems: 'flex-end', marginLeft: 10 },
  priceSub: { fontSize: 11, color: COLORS.text3 },
  priceNum: { fontSize: 22, fontWeight: '900', color: P },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 12 },
  stars: { fontSize: 14 },
  ratingTxt: { color: COLORS.text2, fontSize: 13 },
  desc: { color: COLORS.text2, fontSize: 14, lineHeight: 21, marginBottom: 16 },
  qtyCard: { backgroundColor: COLORS.bg, borderRadius: R.xl, padding: 14, marginBottom: 16, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  qtyLabel: { fontWeight: '700', color: COLORS.text, fontSize: 14 },
  qtyControls: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  qtyBtn: { width: 34, height: 34, borderRadius: 11, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', borderWidth: 1.5, borderColor: COLORS.border },
  qtyBtnAdd: { backgroundColor: P, borderColor: P },
  qtyBtnTxt: { fontSize: 20, fontWeight: '700', color: COLORS.text },
  qtyNum: { fontSize: 18, fontWeight: '800', color: COLORS.text, minWidth: 24, textAlign: 'center' },
  qtyTotal: { fontSize: 13, color: COLORS.text2, fontWeight: '600' },
  orderForm: { backgroundColor: COLORS.bg, borderRadius: R.xl, padding: 16, marginBottom: 16 },
  orderFormTitle: { fontWeight: '800', fontSize: 15, color: COLORS.text, marginBottom: 12 },
  inputWrap: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff', borderRadius: R.lg, borderWidth: 1.5, borderColor: COLORS.inputBorder, paddingHorizontal: 12, marginBottom: 10 },
  inputIcon: { fontSize: 18, marginRight: 8 },
  input: { flex: 1, paddingVertical: 12, fontSize: 14, color: COLORS.text },
  confirmBtn: { backgroundColor: COLORS.success, padding: 14, borderRadius: R.xl, alignItems: 'center' },
  confirmTxt: { color: '#fff', fontWeight: '800', fontSize: 14 },
  divider: { height: 1, backgroundColor: COLORS.border, marginVertical: 20 },
  secTitle: { fontSize: 17, fontWeight: '800', color: COLORS.text, marginBottom: 14 },
  starsRow: { flexDirection: 'row', gap: 4, marginBottom: 12 },
  starBtn: { fontSize: 28 },
  revBtn: { backgroundColor: P, padding: 13, borderRadius: R.xl, alignItems: 'center', marginBottom: 20 },
  revBtnTxt: { color: '#fff', fontWeight: '800', fontSize: 14 },
  revCard: { backgroundColor: COLORS.bg, borderRadius: R.xl, padding: 14, marginBottom: 10 },
  revTop: { flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 8 },
  revAvatar: { width: 36, height: 36, borderRadius: 12, backgroundColor: COLORS.primaryPale, alignItems: 'center', justifyContent: 'center' },
  revAvatarTxt: { color: P, fontWeight: '800', fontSize: 14 },
  revName: { fontWeight: '700', fontSize: 13, color: COLORS.text, marginBottom: 2 },
  revStars: { fontSize: 11 },
  revText: { color: COLORS.text2, fontSize: 13, lineHeight: 18 },
});
