import React, { useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import {
  View, Text, TextInput, TouchableOpacity, StyleSheet,
  ScrollView, Image, ActivityIndicator, Alert, KeyboardAvoidingView, Platform,
} from 'react-native';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { useToast } from '../components/Toast';
import { CATEGORY_ICONS } from '../constants/iconMap';

const ORANGE = '#FF6B00';
const CATS = ['food', 'fashion', 'electronics', 'beauty', 'home', 'sports', 'other'];
const EMOJIS = CATEGORY_ICONS;

export default function AddProductScreen({ navigation }) {
  const { profile } = useAuth();
  const { theme } = useTheme();
  const showToast = useToast();
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [desc, setDesc] = useState('');
  const [cat, setCat] = useState('other');
  const [emoji, setEmoji] = useState(CATEGORY_ICONS[0]);
  const [imgUri, setImgUri] = useState(null);
  const [imgBase64, setImgBase64] = useState(null);
  const [submitting, setSubmitting] = useState(false);

  async function pickImage() {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== 'granted') { showToast('Fasax sawir library', 'error'); return; }
    const res = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, quality: 0.7, base64: true });
    if (!res.canceled && res.assets?.length) {
      setImgUri(res.assets[0].uri);
      setImgBase64(res.assets[0].base64);
    }
  }

  async function submit() {
    if (!name.trim()) { showToast('Magaca alaabta gali', 'error'); return; }
    if (!price || isNaN(Number(price))) { showToast('Qiimaha sax ah gali', 'error'); return; }
    if (!profile) return;
    setSubmitting(true);

    let imgUrl = null;
    if (imgBase64 && imgUri) {
      const ext = imgUri.split('.').pop() || 'jpg';
      const path = `products/${profile.id}_${Date.now()}.${ext}`;
      const byteArr = Uint8Array.from(atob(imgBase64), c => c.charCodeAt(0));
      const { error: upErr } = await supabase.storage.from('product-images').upload(path, byteArr, { contentType: `image/${ext}`, upsert: false });
      if (!upErr) {
        const { data: urlData } = supabase.storage.from('product-images').getPublicUrl(path);
        imgUrl = urlData.publicUrl;
      }
    }

    const { error } = await supabase.from('products').insert({
      name: name.trim(),
      price: Number(price),
      desc: desc.trim(),
      cat,
      emoji,
      img: imgUrl,
      seller: profile.name || profile.email.split('@')[0],
      sellerEmail: profile.email,
      storeId: profile.id,
      rating: 5.0,
      revs: 0,
      badge: '🆕',
    });

    setSubmitting(false);
    if (error) { showToast(error.message, 'error'); return; }
    showToast(`${name} waa lagu daray suuqa`, 'success');
    navigation.goBack();
  }

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView style={[styles.wrap, { backgroundColor: theme.bg }]} keyboardShouldPersistTaps="handled">
        <View style={[styles.header, { backgroundColor: theme.header }]}>
          <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="chevron-back" size={20} color={'#333'} /></TouchableOpacity>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Ionicons name="add-circle-outline" size={18} color={theme.text} />
          <Text style={[styles.title, { color: theme.text }]}>Alaab Cusub Geli</Text>
        </View>
          <View style={{ width: 30 }} />
        </View>

        {/* Image picker */}
        <TouchableOpacity style={styles.imgPicker} onPress={pickImage}>
          {imgUri
            ? <Image source={{ uri: imgUri }} style={styles.imgPreview} />
            : <View style={styles.imgPlaceholder}>
                <Ionicons name="camera-outline" size={40} color={'#333'} />
                <Text style={{ color: '#aaa', marginTop: 8 }}>Sawir dooro</Text>
              </View>
          }
        </TouchableOpacity>

        <View style={styles.form}>
          {/* Emoji picker */}
          <Text style={[styles.label, { color: theme.text }]}>Sumadda (Icon)</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 16 }}>
            {EMOJIS.map(e => (
              <TouchableOpacity key={e} style={[styles.emojiBtn, emoji === e && styles.emojiBtnOn]} onPress={() => setEmoji(e)}>
                <Ionicons name={e} size={24} color={emoji === e ? ORANGE : '#666'} />
              </TouchableOpacity>
            ))}
          </ScrollView>

          <Text style={[styles.label, { color: theme.text }]}>Magaca Alaabta *</Text>
          <TextInput style={[styles.input, { backgroundColor: theme.input, color: theme.inputText }]} placeholder="Tusaale: iPhone 14 Pro" placeholderTextColor="#999" value={name} onChangeText={setName} />

          <Text style={[styles.label, { color: theme.text }]}>Qiimaha (Sh.So) *</Text>
          <TextInput style={[styles.input, { backgroundColor: theme.input, color: theme.inputText }]} placeholder="Tusaale: 500000" placeholderTextColor="#999" keyboardType="numeric" value={price} onChangeText={setPrice} />

          <Text style={[styles.label, { color: theme.text }]}>Faahfaahinta</Text>
          <TextInput style={[styles.input, { backgroundColor: theme.input, color: theme.inputText, height: 90 }]} placeholder="Sharax alaabta..." placeholderTextColor="#999" multiline value={desc} onChangeText={setDesc} />

          <Text style={[styles.label, { color: theme.text }]}>Nooca Alaabta</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 20 }}>
            {CATS.map(c => (
              <TouchableOpacity key={c} style={[styles.catChip, cat === c && styles.catChipOn]} onPress={() => setCat(c)}>
                <Text style={[styles.catTxt, cat === c && { color: '#fff' }]}>{c}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>

          <TouchableOpacity style={styles.submitBtn} onPress={submit} disabled={submitting}>
            {submitting ? <ActivityIndicator color="#fff" /> : <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="rocket-outline" size={16} color={styles.submitTxt.color} /><Text style={styles.submitTxt}>Ku Dar Suuqa Somalizon</Text></View>}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52 },
  back: { fontSize: 24, color: ORANGE },
  title: { fontSize: 17, fontWeight: '700' },
  imgPicker: { margin: 16, borderRadius: 16, overflow: 'hidden', height: 180, backgroundColor: '#f0f0f0' },
  imgPreview: { width: '100%', height: '100%' },
  imgPlaceholder: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  form: { padding: 16 },
  label: { fontWeight: '700', marginBottom: 6, fontSize: 13 },
  input: { borderRadius: 12, padding: 12, marginBottom: 16, fontSize: 14 },
  emojiBtn: { width: 48, height: 48, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: '#f0f0f0', marginRight: 8 },
  emojiBtnOn: { backgroundColor: ORANGE + '33', borderWidth: 2, borderColor: ORANGE },
  catChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20, backgroundColor: '#f0f0f0', marginRight: 8 },
  catChipOn: { backgroundColor: ORANGE },
  catTxt: { fontSize: 12, fontWeight: '600', color: '#666' },
  submitBtn: { backgroundColor: ORANGE, padding: 16, borderRadius: 14, alignItems: 'center' },
  submitTxt: { color: '#fff', fontWeight: '800', fontSize: 15 },
});
