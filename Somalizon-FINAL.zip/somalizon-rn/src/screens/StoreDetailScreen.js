import React, { useEffect, useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import {
  View, Text, ScrollView, TouchableOpacity, StyleSheet,
  ActivityIndicator, Linking, Image,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { toIconName } from '../constants/iconMap';
import { useAuth } from '../contexts/AuthContext';
import { useToast } from '../components/Toast';
import { COLORS, SHADOWS, R } from '../constants/Design';

const P = COLORS.primary;

function fmtCount(n) {
  n = n || 0;
  if (n >= 1000000) return (n / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
  if (n >= 1000) return (n / 1000).toFixed(1).replace(/\.0$/, '') + 'k';
  return String(n);
}

export default function StoreDetailScreen({ route, navigation }) {
  const { store } = route.params;
  const { profile } = useAuth();
  const showToast = useToast();
  const [products, setProducts] = useState([]);
  const [videos, setVideos] = useState([]);
  const [followerCount, setFollowerCount] = useState(store.followers || 0);
  const [followed, setFollowed] = useState(false);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('products');

  useEffect(() => { loadData(); }, []);

  async function loadData() {
    setLoading(true);
    const [prodsRes, videosRes, followRes, followerCountRes] = await Promise.all([
      supabase.from('products').select('*').eq('storeId', store.id).order('created_at', { ascending: false }),
      supabase.from('videos').select('*').eq('userEmail', store.sellerEmail).order('created_at', { ascending: false }),
      profile?.email
        ? supabase.from('follows').select('id').eq('user_email', profile.email).eq('seller_email', store.sellerEmail).maybeSingle()
        : Promise.resolve({ data: null }),
      supabase.from('follows').select('id', { count: 'exact', head: true }).eq('seller_email', store.sellerEmail),
    ]);
    setProducts(prodsRes.data || []);
    setVideos(videosRes.data || []);
    setFollowed(!!followRes.data);
    setFollowerCount(followerCountRes.count || 0);
    setTab((prodsRes.data || []).length > 0 ? 'products' : 'videos');
    setLoading(false);
  }

  async function toggleFollow() {
    if (!profile?.email) return;
    if (followed) {
      await supabase.from('follows').delete().eq('user_email', profile.email).eq('seller_email', store.sellerEmail);
      setFollowed(false);
      setFollowerCount(c => Math.max(0, c - 1));
    } else {
      await supabase.from('follows').upsert({ user_email: profile.email, seller_email: store.sellerEmail });
      setFollowed(true);
      setFollowerCount(c => c + 1);
    }
  }

  function openChat() {
    if (!profile?.email) return;
    const chatId = [profile.email.toLowerCase(), store.sellerEmail.toLowerCase()].sort().join('__');
    navigation.navigate('ChatRoom', {
      chat: { id: chatId, participantEmails: [profile.email, store.sellerEmail] },
      otherName: store.sellerName || store.name,
      otherEmail: store.sellerEmail,
    });
  }

  function openWA() {
    const num = store.whatsapp || store.phone;
    if (!num) { showToast('Ganacsadahan WhatsApp lambar ma laha', 'error'); return; }
    const clean = num.replace(/\D/g, '');
    const url = `whatsapp://send?phone=${clean}&text=Salaan%2C%20alaabyadaaga%20ayaan%20weydiiyay`;
    Linking.openURL(url).catch(() => showToast('WhatsApp lama furi karin', 'error'));
  }

  function openPhone() {
    const num = store.phone || store.sellerPhone;
    if (!num) { showToast('Ganacsadahan lambarka telefoonka ma laha', 'error'); return; }
    Linking.openURL(`tel:${num}`).catch(() => showToast('Telefoon lama furi karin', 'error'));
  }

  const isMe = profile?.email?.toLowerCase() === store.sellerEmail?.toLowerCase();

  if (!store.verified && !isMe) {
    return (
      <View style={[styles.wrap, { alignItems: 'center', justifyContent: 'center', padding: 32 }]}>
        <Ionicons name="time-outline" size={48} color={'#999'} />
        <Text style={{ marginTop: 14, fontWeight: '800', color: COLORS.text, textAlign: 'center' }}>
          Dukaankan weli lama ansixin
        </Text>
        <TouchableOpacity style={{ marginTop: 18 }} onPress={() => navigation.goBack()}>
          <Text style={{ color: P, fontWeight: '700' }}>Ka noqo</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <ScrollView style={styles.wrap} showsVerticalScrollIndicator={false}>
      {/* Orange header band — same layout as UserProfileScreen */}
      <View style={styles.headerBand}>
        <View style={styles.waveBg} />
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <Ionicons name="chevron-back" size={20} color={'#333'} />
        </TouchableOpacity>

        <View style={styles.avatarDefault}>
          <Ionicons name={toIconName(store.emoji, 'storefront-outline')} size={36} color={'#fff'} />
        </View>

        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
          <Text style={styles.userName}>{store.name}</Text>
          {store.verified && <Ionicons name="checkmark-circle" size={16} color={'#fff'} />}
        </View>
        {store.sellerName && <Text style={styles.shopName}>{store.sellerName}</Text>}
        {(store.store_desc || store.desc) && <Text style={styles.storeDesc}>{store.store_desc || store.desc}</Text>}

        <View style={styles.typeBadge}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
            <Ionicons name="star" size={12} color={'#fff'} />
            <Text style={styles.typeTxt}>{store.rating || 5} rating</Text>
          </View>
        </View>

        {/* Stats row */}
        <View style={styles.statsRow}>
          <View style={styles.statItem}><Text style={styles.statNum}>{fmtCount(products.length + videos.length)}</Text><Text style={styles.statLbl}>Wax lagu daray</Text></View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}><Text style={styles.statNum}>{fmtCount(followerCount)}</Text><Text style={styles.statLbl}>Raaciyayaal</Text></View>
          <View style={styles.statDivider} />
          <View style={styles.statItem}><Text style={styles.statNum}>{fmtCount(videos.reduce((s, v) => s + (v.likes || 0), 0))}</Text><Text style={styles.statLbl}>Jecel</Text></View>
        </View>
      </View>

      {/* Action buttons */}
      {!isMe && (
        <View style={styles.actionRow}>
          <TouchableOpacity style={[styles.followBtn, followed && styles.followedBtn, SHADOWS.orange]} onPress={toggleFollow}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}><Ionicons name={followed ? 'checkmark' : 'add'} size={13} color={styles.followTxt.color} /><Text style={styles.followTxt}>{followed ? 'Following' : 'Follow'}</Text></View>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.msgBtn, SHADOWS.sm]} onPress={openChat}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Ionicons name="chatbubble-outline" size={14} color={styles.msgTxt.color} /><Text style={styles.msgTxt}>Xariir</Text></View>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.iconBtn, { backgroundColor: '#25D366' }]} onPress={openWA}>
            <Ionicons name="logo-whatsapp" size={19} color={'#fff'} />
          </TouchableOpacity>
          <TouchableOpacity style={[styles.iconBtn, { backgroundColor: '#3b82f6' }]} onPress={openPhone}>
            <Ionicons name="call-outline" size={18} color={'#fff'} />
          </TouchableOpacity>
        </View>
      )}

      {loading ? <ActivityIndicator color={P} style={{ marginTop: 30 }} /> : (
        <>
          {/* Tab bar: Alaabta (grid) / Muuqaallo (play) */}
          {(products.length > 0 || videos.length > 0) && (
            <>
              <View style={styles.tabBar}>
                <TouchableOpacity style={[styles.tabBtn, tab === 'products' && styles.tabBtnOn]} onPress={() => setTab('products')}>
                  <Ionicons name="grid-outline" size={20} color={tab === 'products' ? P : COLORS.text3} />
                </TouchableOpacity>
                <TouchableOpacity style={[styles.tabBtn, tab === 'videos' && styles.tabBtnOn]} onPress={() => setTab('videos')}>
                  <Ionicons name="play-outline" size={20} color={tab === 'videos' ? P : COLORS.text3} />
                </TouchableOpacity>
              </View>

              {tab === 'products' && (
                <View style={styles.gridWrap}>
                  {products.length === 0
                    ? <Text style={styles.emptyTxt}>Alaab lama gelin weli</Text>
                    : (
                      <View style={styles.postsGrid}>
                        {products.map((p) => (
                          <TouchableOpacity
                            key={p.id} style={styles.gridCell}
                            onPress={() => navigation.navigate('ProductDetail', { product: p })}
                          >
                            {p.img
                              ? <Image source={{ uri: p.img }} style={styles.gridImg} />
                              : <View style={[styles.gridImg, styles.gridImgFallback]}><Ionicons name={toIconName(p.emoji)} size={30} color={'#666'} /></View>
                            }
                            <View style={styles.gridPriceTag}>
                              <Text style={styles.gridPriceTxt}>Sh.So {(p.price || 0).toLocaleString()}</Text>
                            </View>
                          </TouchableOpacity>
                        ))}
                      </View>
                    )
                  }
                </View>
              )}

              {tab === 'videos' && (
                <View style={styles.gridWrap}>
                  {videos.length === 0
                    ? <Text style={styles.emptyTxt}>Video lama soo dejin weli</Text>
                    : (
                      <View style={styles.postsGrid}>
                        {videos.map((v, i) => (
                          <TouchableOpacity
                            key={v.id} style={styles.gridCell}
                            onPress={() => navigation.navigate('ProfileVideoViewer', { userEmail: store.sellerEmail, userName: store.sellerName || store.name, startIndex: i })}
                          >
                            <View style={[styles.gridImg, styles.videoDark]}>
                              <Ionicons name="play" size={22} color="#fff" style={{ position: 'absolute', top: 8, right: 8 }} />
                              <View style={styles.videoLikesTag}>
                                <Ionicons name="heart" size={11} color="#fff" />
                                <Text style={styles.videoLikesTxt}>{fmtCount(v.likes || 0)}</Text>
                              </View>
                            </View>
                          </TouchableOpacity>
                        ))}
                      </View>
                    )
                  }
                </View>
              )}
            </>
          )}
        </>
      )}
      <View style={{ height: 24 }} />
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  headerBand: { backgroundColor: P, paddingTop: 54, paddingBottom: 28, alignItems: 'center', borderBottomLeftRadius: 32, borderBottomRightRadius: 32, overflow: 'hidden', marginBottom: 16 },
  waveBg: { position: 'absolute', width: 320, height: 320, borderRadius: 160, backgroundColor: 'rgba(255,255,255,0.08)', top: -80, right: -40 },
  backBtn: { position: 'absolute', top: 54, left: 16, width: 38, height: 38, borderRadius: 13, backgroundColor: 'rgba(255,255,255,0.2)', alignItems: 'center', justifyContent: 'center' },
  avatarDefault: { width: 88, height: 88, borderRadius: 28, backgroundColor: 'rgba(255,255,255,0.25)', alignItems: 'center', justifyContent: 'center', marginBottom: 12, borderWidth: 3, borderColor: 'rgba(255,255,255,0.4)' },
  userName: { fontSize: 22, fontWeight: '900', color: '#fff', letterSpacing: -0.3 },
  shopName: { color: 'rgba(255,255,255,0.8)', fontSize: 13, marginTop: 4 },
  storeDesc: { color: 'rgba(255,255,255,0.7)', fontSize: 12, marginTop: 6, textAlign: 'center', paddingHorizontal: 30 },
  typeBadge: { paddingHorizontal: 14, paddingVertical: 6, borderRadius: R.full, backgroundColor: 'rgba(255,255,255,0.2)', marginTop: 10 },
  typeTxt: { color: '#fff', fontWeight: '700', fontSize: 13 },

  statsRow: { flexDirection: 'row', alignItems: 'center', marginTop: 16, backgroundColor: 'rgba(255,255,255,0.14)', borderRadius: R.xl, paddingVertical: 12, paddingHorizontal: 10, width: '86%' },
  statItem: { flex: 1, alignItems: 'center' },
  statNum: { color: '#fff', fontWeight: '900', fontSize: 17 },
  statLbl: { color: 'rgba(255,255,255,0.75)', fontSize: 11, marginTop: 2 },
  statDivider: { width: 1, height: 26, backgroundColor: 'rgba(255,255,255,0.25)' },

  actionRow: { flexDirection: 'row', gap: 10, paddingHorizontal: 16, marginBottom: 16 },
  followBtn: { flex: 1, backgroundColor: P, padding: 14, borderRadius: R.xl, alignItems: 'center' },
  followedBtn: { backgroundColor: COLORS.success },
  followTxt: { color: '#fff', fontWeight: '800', fontSize: 14 },
  msgBtn: { flex: 1, backgroundColor: '#fff', padding: 14, borderRadius: R.xl, alignItems: 'center', ...SHADOWS.card },
  msgTxt: { fontWeight: '700', color: COLORS.text, fontSize: 14 },
  iconBtn: { width: 48, height: 48, borderRadius: R.xl, alignItems: 'center', justifyContent: 'center' },

  tabBar: { flexDirection: 'row', backgroundColor: '#fff', marginHorizontal: 16, borderRadius: R.xl, marginBottom: 2, ...SHADOWS.card },
  tabBtn: { flex: 1, alignItems: 'center', paddingVertical: 12, borderBottomWidth: 2, borderBottomColor: 'transparent' },
  tabBtnOn: { borderBottomColor: P },

  gridWrap: { paddingHorizontal: 16, paddingTop: 10 },
  postsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 8 },
  gridCell: { width: '31.5%' },
  gridImg: { width: '100%', aspectRatio: 0.8, borderRadius: R.md, backgroundColor: COLORS.primaryPale },
  gridImgFallback: { alignItems: 'center', justifyContent: 'center' },
  gridPriceTag: { position: 'absolute', bottom: 6, left: 6, right: 6, backgroundColor: 'rgba(0,0,0,0.55)', borderRadius: 6, paddingVertical: 3, paddingHorizontal: 6 },
  gridPriceTxt: { color: '#fff', fontSize: 10, fontWeight: '700' },
  videoDark: { backgroundColor: '#1a1a1a', justifyContent: 'flex-end' },
  videoLikesTag: { flexDirection: 'row', alignItems: 'center', gap: 3, position: 'absolute', bottom: 6, left: 6 },
  videoLikesTxt: { color: '#fff', fontSize: 10, fontWeight: '700' },
  emptyTxt: { textAlign: 'center', color: COLORS.text3, fontSize: 13, paddingVertical: 30 },
});
