import React, { useEffect, useState, useCallback } from 'react';
import { Ionicons } from '@expo/vector-icons';
import { View, Text, FlatList, TouchableOpacity, StyleSheet, TextInput, ActivityIndicator, RefreshControl } from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useRealtime } from '../contexts/RealtimeContext';
import { COLORS, SHADOWS, R } from '../constants/Design';
import { toIconName } from '../constants/iconMap';
import RetryView from '../components/RetryView';

const P = COLORS.primary;

export default function ShopsScreen({ navigation }) {
  const { profile } = useAuth();
  const { stores: rtStores, storesError, retryStores } = useRealtime();
  const [followedEmails, setFollowedEmails] = useState(new Set());
  const [search, setSearch] = useState('');
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => { loadFollows(); }, [profile]);

  async function loadFollows() {
    if (!profile?.email) return;
    const { data } = await supabase.from('follows').select('seller_email').eq('user_email', profile.email);
    setFollowedEmails(new Set((data || []).map(r => r.seller_email)));
  }

  async function toggleFollow(store) {
    if (!profile?.email) return;
    const isNowFollowing = !followedEmails.has(store.sellerEmail);
    const updated = new Set(followedEmails);
    if (isNowFollowing) {
      updated.add(store.sellerEmail);
      await supabase.from('follows').upsert({ user_email: profile.email, seller_email: store.sellerEmail });
    } else {
      updated.delete(store.sellerEmail);
      await supabase.from('follows').delete().eq('user_email', profile.email).eq('seller_email', store.sellerEmail);
    }
    setFollowedEmails(updated);
  }

  const filtered = (rtStores || []).filter(s => !search || (s.name || '').toLowerCase().includes(search.toLowerCase()));

  function StoreCard({ s }) {
    const followed = followedEmails.has(s.sellerEmail);
    return (
      <TouchableOpacity style={[styles.card, SHADOWS.card]} onPress={() => navigation.navigate('StoreDetail', { store: s })} activeOpacity={0.92}>
        <View style={[styles.cardLeft, { backgroundColor: s.color || COLORS.primaryPale }]}>
          <Ionicons name={toIconName(s.emoji, 'storefront-outline')} size={26} color={COLORS.primary} />
        </View>
        <View style={styles.cardBody}>
          <View style={styles.cardTop}>
            <View style={{ flexDirection: 'row', alignItems: 'center', flex: 1 }}>
              <Text style={styles.storeName} numberOfLines={1}>{s.name}</Text>
              {s.verified && <Ionicons name="checkmark-circle" size={14} color={COLORS.primary} style={{ marginLeft: 4 }} />}
            </View>
            <TouchableOpacity
              style={[styles.followBtn, followed && styles.followedBtn]}
              onPress={() => toggleFollow(s)}
            >
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3 }}>
                <Ionicons name={followed ? 'checkmark' : 'add'} size={12} color={followed ? '#fff' : '#fff'} />
                {!followed && <Text style={[styles.followTxt, followed && styles.followedTxt]}>Raac</Text>}
              </View>
            </TouchableOpacity>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
            <Ionicons name="person-outline" size={11} color={COLORS.text2} />
            <Text style={styles.sellerName}>{s.sellerName}</Text>
          </View>
          <View style={styles.metaRow}>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3 }}>
              <Ionicons name="star" size={11} color="#FFB800" />
              <Text style={styles.meta}>{s.rating || 5}</Text>
            </View>
            <View style={styles.metaDot} />
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 3 }}>
              <Ionicons name="people-outline" size={11} color={COLORS.text3} />
              <Text style={styles.meta}>{(s.followers || 0).toLocaleString()}</Text>
            </View>
          </View>
          {(s.store_desc || s.desc) && <Text style={styles.desc} numberOfLines={1}>{s.store_desc || s.desc}</Text>}
        </View>
      </TouchableOpacity>
    );
  }

  return (
    <View style={styles.wrap}>
      {/* Header */}
      <View style={styles.header}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Ionicons name="storefront-outline" size={19} color={COLORS.text} />
          <Text style={styles.title}>Dukaannada</Text>
        </View>
        <Text style={styles.count}>{(rtStores || []).length} dukaan</Text>
      </View>

      {/* Search */}
      <View style={styles.searchWrap}>
        <View style={styles.searchBox}>
          <Ionicons name="search-outline" size={20} color={'#333'} />
          <TextInput
            style={styles.searchInput} placeholder="Dukaan raadi..."
            placeholderTextColor={COLORS.text3} value={search} onChangeText={setSearch}
          />
          {search.length > 0 && (
            <TouchableOpacity onPress={() => setSearch('')}>
              <Ionicons name="close" size={16} color={COLORS.text3} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      <FlatList
        data={filtered} keyExtractor={s => String(s.id)}
        contentContainerStyle={{ padding: 16, paddingBottom: 100, gap: 12 }}
        renderItem={({ item }) => <StoreCard s={item} />}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={async () => { setRefreshing(true); await loadFollows(); setRefreshing(false); }} tintColor={P} />}
        ListEmptyComponent={
          storesError && rtStores.length === 0
            ? <RetryView onRetry={retryStores} />
            : <View style={styles.empty}><Ionicons name="storefront-outline" size={46} color={'#333'} /><Text style={styles.emptyTxt}>Dukaan lama helin</Text></View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: COLORS.bg },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', paddingHorizontal: 16, paddingTop: 54, paddingBottom: 12, backgroundColor: '#fff', borderBottomWidth: 1, borderBottomColor: COLORS.border },
  title: { fontSize: 22, fontWeight: '900', color: COLORS.text, letterSpacing: -0.3 },
  count: { color: COLORS.text3, fontSize: 13, fontWeight: '600' },
  searchWrap: { backgroundColor: '#fff', paddingHorizontal: 16, paddingBottom: 12, paddingTop: 8 },
  searchBox: { flexDirection: 'row', alignItems: 'center', backgroundColor: COLORS.input, borderRadius: R.lg, paddingHorizontal: 14, height: 44, gap: 8, borderWidth: 1, borderColor: COLORS.inputBorder },
  searchIco: { fontSize: 16 },
  searchInput: { flex: 1, fontSize: 14, color: COLORS.text },
  card: { backgroundColor: '#fff', borderRadius: R.xl, flexDirection: 'row', overflow: 'hidden' },
  cardLeft: { width: 72, alignItems: 'center', justifyContent: 'center' },
  storeEmoji: { fontSize: 32 },
  cardBody: { flex: 1, padding: 14 },
  cardTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 },
  storeName: { fontWeight: '800', fontSize: 15, color: COLORS.text, flex: 1, marginRight: 8 },
  followBtn: { backgroundColor: P, paddingHorizontal: 14, paddingVertical: 6, borderRadius: R.full },
  followedBtn: { backgroundColor: COLORS.success },
  followTxt: { color: '#fff', fontWeight: '700', fontSize: 12 },
  followedTxt: { color: '#fff' },
  sellerName: { color: COLORS.text2, fontSize: 12, marginBottom: 6 },
  metaRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  meta: { color: COLORS.text3, fontSize: 12 },
  metaDot: { width: 3, height: 3, borderRadius: 1.5, backgroundColor: COLORS.text3 },
  desc: { color: COLORS.text3, fontSize: 11, marginTop: 4 },
  empty: { alignItems: 'center', marginTop: 60 },
  emptyTxt: { color: COLORS.text3, fontSize: 15, fontWeight: '600' },
});
