import React, { useEffect, useRef, useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import {
  View, Text, FlatList, TextInput, TouchableOpacity, StyleSheet,
  KeyboardAvoidingView, Platform, ActivityIndicator,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';

const ORANGE = '#FF6B00';

function timeSince(iso) {
  if (!iso) return '';
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Hadda';
  if (mins < 60) return mins + 'dq';
  if (mins < 1440) return Math.floor(mins / 60) + 'swr';
  return Math.floor(mins / 1440) + 'ml';
}

export default function CommentsScreen({ route, navigation }) {
  const { videoId, videoDesc } = route.params;
  const { profile } = useAuth();
  const { theme } = useTheme();
  const [comments, setComments] = useState([]);
  const [text, setText] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const listRef = useRef(null);
  const channelRef = useRef(null);

  useEffect(() => {
    loadComments();
    channelRef.current = supabase.channel('comments-' + videoId)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'comments', filter: 'videoId=eq.' + videoId }, () => loadComments())
      .subscribe();
    return () => { if (channelRef.current) supabase.removeChannel(channelRef.current); };
  }, [videoId]);

  async function loadComments() {
    const { data } = await supabase.from('comments').select('*').eq('videoId', videoId).order('created_at', { ascending: true });
    setComments(data || []);
    setLoading(false);
    setTimeout(() => listRef.current?.scrollToEnd({ animated: true }), 100);
  }

  async function sendComment() {
    if (!text.trim() || !profile) return;
    setSending(true);
    const msg = text.trim();
    setText('');
    await supabase.from('comments').insert({ videoId, userName: profile.name || profile.email.split('@')[0], userEmail: profile.email, text: msg });
    await supabase.from('videos').update({ comments: (comments.length + 1) }).eq('id', videoId);
    setSending(false);
  }

  return (
    <KeyboardAvoidingView style={[styles.wrap, { backgroundColor: theme.bg }]} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
      <View style={[styles.header, { backgroundColor: theme.header }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="chevron-down" size={20} color={'#333'} /></TouchableOpacity>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Ionicons name="chatbubble-outline" size={18} color={theme.text} />
          <Text style={[styles.title, { color: theme.text }]}>Faallooyinka</Text>
        </View>
        <View style={{ width: 30 }} />
      </View>

      {videoDesc ? <Text style={[styles.videoDesc, { color: theme.text2, borderBottomColor: theme.border }]} numberOfLines={2}>{videoDesc}</Text> : null}

      {loading ? <ActivityIndicator color={ORANGE} style={{ marginTop: 30 }} /> : (
        <FlatList
          ref={listRef}
          data={comments}
          keyExtractor={c => String(c.id)}
          contentContainerStyle={{ padding: 14 }}
          renderItem={({ item: c }) => (
            <View style={[styles.commentCard, { backgroundColor: theme.card }]}>
              <View style={styles.commentAvatar}>
                <Text style={styles.commentAvatarTxt}>{(c.userName?.[0] || '?').toUpperCase()}</Text>
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.commentUser, { color: theme.text }]}>{c.userName} <Text style={styles.commentTime}>{timeSince(c.created_at)}</Text></Text>
                <Text style={[styles.commentText, { color: theme.text2 }]}>{c.text}</Text>
              </View>
            </View>
          )}
          ListEmptyComponent={<View style={styles.empty}><Text style={{ color: theme.text2 }}>Wax faallo ah ma jiraan weli. Adiga ugu horreeya!</Text></View>}
        />
      )}

      <View style={[styles.inputRow, { backgroundColor: theme.card, borderTopColor: theme.border }]}>
        <TextInput
          style={[styles.input, { backgroundColor: theme.input, color: theme.inputText }]}
          placeholder="Faallo qor..." placeholderTextColor="#999"
          value={text} onChangeText={setText} multiline
        />
        <TouchableOpacity
          style={[styles.sendBtn, (!text.trim() || sending) && { backgroundColor: '#ccc' }]}
          onPress={sendComment} disabled={!text.trim() || sending}
        >
          {sending ? <ActivityIndicator color="#fff" size="small" /> : <Ionicons name="send" size={18} color={'#fff'} />}
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 14, paddingTop: 52 },
  back: { fontSize: 26, color: ORANGE },
  title: { fontSize: 17, fontWeight: '700' },
  videoDesc: { padding: 12, paddingHorizontal: 16, fontSize: 13, lineHeight: 18, borderBottomWidth: 1 },
  commentCard: { flexDirection: 'row', borderRadius: 12, padding: 10, marginBottom: 8, alignItems: 'flex-start' },
  commentAvatar: { width: 34, height: 34, borderRadius: 17, backgroundColor: ORANGE, alignItems: 'center', justifyContent: 'center', marginRight: 10 },
  commentAvatarTxt: { color: '#fff', fontWeight: '700', fontSize: 14 },
  commentUser: { fontWeight: '700', fontSize: 13, marginBottom: 3 },
  commentTime: { fontWeight: '400', color: '#aaa', fontSize: 11 },
  commentText: { fontSize: 13, lineHeight: 18 },
  empty: { alignItems: 'center', padding: 30 },
  inputRow: { flexDirection: 'row', alignItems: 'flex-end', padding: 10, borderTopWidth: 1 },
  input: { flex: 1, borderRadius: 20, paddingHorizontal: 14, paddingVertical: 9, fontSize: 14, marginRight: 8, maxHeight: 100 },
  sendBtn: { backgroundColor: ORANGE, width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
});
