import React, { useState } from 'react';
import { Ionicons } from '@expo/vector-icons';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  TextInput, Alert, ActivityIndicator, ScrollView,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useCart } from '../contexts/CartContext';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import LocationModal from '../components/LocationModal';
import { useToast } from '../components/Toast';
import { toIconName } from '../constants/iconMap';
import { useCurrency } from '../contexts/CurrencyContext';

const ORANGE = '#FF6B00';
const COMMISSION_RATE = 0.05; // 5% platform fee, split evenly between buyer and seller
const PAY_METHODS = [
  { id: 'evc', label: 'EVC Plus', emoji: 'card-outline', placeholder: '063XXXXXXX' },
  { id: 'zaad', label: 'Zaad', emoji: 'phone-portrait-outline', placeholder: '063XXXXXXX' },
  { id: 'edahab', label: 'eDahab', emoji: 'cash-outline', placeholder: '09XXXXXXXX' },
  { id: 'kash', label: 'Kash', emoji: 'cash-outline', placeholder: '' },
];

function HeaderTitle({ icon, text, color }) {
  return (
    <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
      <Ionicons name={icon} size={17} color={color} />
      <Text style={[{ fontSize: 17, fontWeight: '700' }, { color }]}>{text}</Text>
    </View>
  );
}

export default function CartScreen({ navigation }) {
  const { cart, changeQty, removeFromCart, clearCart, totalPrice } = useCart();
  const { formatPrice } = useCurrency();
  const { profile } = useAuth();
  const { theme } = useTheme();
  const showToast = useToast();
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const [payMethod, setPayMethod] = useState('evc');
  const [payNumber, setPayNumber] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [step, setStep] = useState('cart'); // 'cart' | 'checkout'
  const [showLocationModal, setShowLocationModal] = useState(false);
  const [savedAddress, setSavedAddress] = useState(null);

  async function placeOrder() {
    const addr = savedAddress;
    if (!addr?.phone || !addr?.city) { setShowLocationModal(true); return; }
    if (!profile) { showToast('Marka hore soo gal', 'error'); return; }
    setSubmitting(true);

    const deliveryFee = addr.deliveryFee || 0;
    const promises = cart.map(item => {
      const itemTotal = item.price * item.qty;
      const commission = itemTotal * COMMISSION_RATE;
      const buyerSurcharge = commission / 2;   // buyer pays half the fee, on top
      const sellerDeduction = commission / 2;  // seller absorbs the other half
      return supabase.from('orders').insert({
        prodId: item.id, prodName: item.name, prodEmoji: toIconName(item.emoji),
        qty: item.qty, totalPrice: itemTotal + buyerSurcharge, deliveryFee,
        commissionAmount: commission, sellerPayout: itemTotal - sellerDeduction,
        buyerName: profile.name, buyerEmail: profile.email,
        sellerEmail: item.sellerEmail, sellerName: item.seller,
        phone: addr.phone, address: `${addr.city}, ${addr.district || ''} ${addr.details || ''}`.trim(),
        payMethod, payNumber: payNumber.trim(),
        status: 'La Diray',
      });
    });

    const results = await Promise.all(promises);
    const anyError = results.find(r => r.error);
    setSubmitting(false);

    if (anyError) { showToast(anyError.error.message, 'error'); return; }
    const orderedCount = cart.length;
    const commissionTotal = totalPrice * COMMISSION_RATE;
    const orderedTotal = totalPrice + deliveryFee + (commissionTotal / 2);
    clearCart();
    showToast(`Codsiga La Diray! ${orderedCount} alaab — ${formatPrice(orderedTotal)}`, 'success');
    navigation.goBack();
  }

  if (cart.length === 0) return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="chevron-back" size={20} color={'#333'} /></TouchableOpacity>
        <HeaderTitle icon="cart-outline" text="Kaydiyaha" color={theme.text} />
        <View style={{ width: 30 }} />
      </View>
      <View style={styles.empty}>
        <Ionicons name="cart-outline" size={60} color={'#333'} />
        <Text style={[styles.emptyTxt, { color: theme.text2 }]}>Kaydiyaha waa madhan yahay</Text>
        <TouchableOpacity style={styles.shopBtn} onPress={() => navigation.navigate('Home')}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="bag-handle-outline" size={15} color={styles.shopBtnTxt.color} /><Text style={styles.shopBtnTxt}>Alaab Raadi</Text></View>
        </TouchableOpacity>
      </View>
    </View>
  );

  return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header }]}>
        <TouchableOpacity onPress={() => step === 'checkout' ? setStep('cart') : navigation.goBack()}>
          <Ionicons name="chevron-back" size={20} color={'#333'} />
        </TouchableOpacity>
        <HeaderTitle icon={step === 'cart' ? 'cart-outline' : 'card-outline'} text={step === 'cart' ? 'Kaydiyaha' : 'Bixi'} color={theme.text} />
        <View style={{ width: 30 }} />
      </View>

      {step === 'cart' ? (
        <>
          <FlatList
            data={cart} keyExtractor={c => String(c.id)}
            contentContainerStyle={{ padding: 14 }}
            renderItem={({ item: c }) => (
              <View style={[styles.cartItem, { backgroundColor: theme.card }]}>
                <Ionicons name={toIconName(c.emoji)} size={36} color={'#333'} style={{ marginRight: 12 }} />
                <View style={{ flex: 1 }}>
                  <Text style={[styles.itemName, { color: theme.text }]} numberOfLines={1}>{c.name}</Text>
                  <Text style={styles.itemPrice}>{formatPrice(c.price * c.qty)}</Text>
                </View>
                <View style={styles.qtyRow}>
                  <TouchableOpacity style={styles.qtyBtn} onPress={() => changeQty(c.id, -1)}><Text style={styles.qtyTxt}>−</Text></TouchableOpacity>
                  <Text style={[styles.qtyNum, { color: theme.text }]}>{c.qty}</Text>
                  <TouchableOpacity style={styles.qtyBtn} onPress={() => changeQty(c.id, 1)}><Text style={styles.qtyTxt}>+</Text></TouchableOpacity>
                </View>
                <TouchableOpacity onPress={() => removeFromCart(c.id)} style={{ marginLeft: 8 }}><Ionicons name="trash-outline" size={18} color={'#333'} /></TouchableOpacity>
              </View>
            )}
          />
          <View style={[styles.footer, { backgroundColor: theme.card }]}>
            <Text style={[styles.total, { color: theme.text }]}>Wadarta: <Text style={{ color: ORANGE }}>{formatPrice(totalPrice)}</Text></Text>
            <TouchableOpacity style={styles.checkoutBtn} onPress={() => setStep('checkout')}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Text style={styles.checkoutBtnTxt}>Bixi Hadda</Text><Ionicons name="chevron-forward" size={16} color={styles.checkoutBtnTxt.color} /></View>
            </TouchableOpacity>
          </View>
        </>
      ) : (
        <ScrollView contentContainerStyle={{ padding: 16 }}>
          {/* Address section */}
          <TouchableOpacity
            style={[styles.addrBox, { backgroundColor: theme.card, borderColor: savedAddress ? '#22c55e' : ORANGE }]}
            onPress={() => setShowLocationModal(true)}
          >
            {savedAddress ? (
              <View>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Ionicons name="location-outline" size={14} color={theme.text} /><Text style={[styles.addrTitle, { color: theme.text }]}>{savedAddress.city}, {savedAddress.district}</Text></View>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Ionicons name="call-outline" size={12} color={theme.text2} /><Text style={[styles.addrSub, { color: theme.text2 }]}>{savedAddress.phone} · {savedAddress.details}</Text></View>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}><Text style={styles.addrChange}>Beddel</Text><Ionicons name="create-outline" size={12} color={styles.addrChange.color} /></View>
              </View>
            ) : (
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="location-outline" size={14} color={styles.addrPlaceholder.color} /><Text style={styles.addrPlaceholder}>Cinwaanka Geli (riix halkan)</Text></View>
            )}
          </TouchableOpacity>

          <LocationModal
            visible={showLocationModal}
            onClose={() => setShowLocationModal(false)}
            onSave={addr => setSavedAddress(addr)}
            initialData={savedAddress || {}}
          />
          <Text style={[styles.label, { color: theme.text }]}>Habka Lacag Bixinta</Text>
          <View style={styles.payRow}>
            {PAY_METHODS.map(p => (
              <TouchableOpacity key={p.id} style={[styles.payChip, payMethod === p.id && styles.payChipOn]} onPress={() => setPayMethod(p.id)}>
                <Ionicons name={p.emoji} size={20} color={payMethod === p.id ? ORANGE : '#666'} />
                <Text style={[styles.payChipTxt, payMethod === p.id && { color: '#fff' }]}>{p.label}</Text>
              </TouchableOpacity>
            ))}
          </View>

          {payMethod !== 'kash' && (
            <>
              <Text style={[styles.label, { color: theme.text }]}>Lambarka {PAY_METHODS.find(p => p.id === payMethod)?.label}</Text>
              <TextInput
                style={[styles.input, { backgroundColor: theme.input, color: theme.inputText }]}
                placeholder={PAY_METHODS.find(p => p.id === payMethod)?.placeholder}
                placeholderTextColor="#999" keyboardType="phone-pad"
                value={payNumber} onChangeText={setPayNumber}
              />
            </>
          )}

          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Ionicons name="call-outline" size={14} color={theme.text} /><Text style={[styles.label, { color: theme.text }]}>Lambarka Lacag Bixinta</Text></View>
          <View style={[styles.summary, { backgroundColor: theme.card }]}>
            <Text style={[styles.summaryTitle, { color: theme.text }]}>Koobidda Dalabka</Text>
            {cart.map(c => (
              <View key={c.id} style={styles.summaryRow}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}><Ionicons name={toIconName(c.emoji)} size={14} color={theme.text2} /><Text style={{ color: theme.text2 }}>{c.name} x{c.qty}</Text></View>
                <Text style={{ color: theme.text, fontWeight: '600' }}>{formatPrice(c.price * c.qty)}</Text>
              </View>
            ))}
            <View style={[styles.summaryRow, { borderTopWidth: 1, borderTopColor: theme.border, marginTop: 8, paddingTop: 8 }]}>
              <Text style={{ color: theme.text2 }}>Wadarta Alaabta</Text>
              <Text style={{ color: theme.text, fontWeight: '600' }}>{formatPrice(totalPrice)}</Text>
            </View>
            <View style={styles.summaryRow}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
                <Ionicons name="bicycle-outline" size={13} color={theme.text2} />
                <Text style={{ color: theme.text2 }}>Kharashka Gaarsiinta{savedAddress?.city ? ` (${savedAddress.city})` : ''}</Text>
              </View>
              <Text style={{ color: theme.text, fontWeight: '600' }}>{formatPrice(savedAddress?.deliveryFee || 0)}</Text>
            </View>
            <View style={styles.summaryRow}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
                <Ionicons name="receipt-outline" size={13} color={theme.text2} />
                <Text style={{ color: theme.text2 }}>Adeegga</Text>
              </View>
              <Text style={{ color: theme.text, fontWeight: '600' }}>{formatPrice((totalPrice * COMMISSION_RATE) / 2)}</Text>
            </View>
            <View style={[styles.summaryRow, { borderTopWidth: 1, borderTopColor: theme.border, marginTop: 8, paddingTop: 8 }]}>
              <Text style={{ color: theme.text, fontWeight: '700' }}>Wadarta Guud</Text>
              <Text style={{ color: ORANGE, fontWeight: '800', fontSize: 16 }}>{formatPrice(totalPrice + (savedAddress?.deliveryFee || 0) + (totalPrice * COMMISSION_RATE) / 2)}</Text>
            </View>
          </View>

          <TouchableOpacity style={styles.orderBtn} onPress={placeOrder} disabled={submitting}>
            {submitting ? <ActivityIndicator color="#fff" /> : <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}><Ionicons name="checkmark-circle-outline" size={16} color={styles.orderBtnTxt.color} /><Text style={styles.orderBtnTxt}>Xaqiiji Dalabka — {formatPrice(totalPrice + (savedAddress?.deliveryFee || 0) + (totalPrice * COMMISSION_RATE) / 2)}</Text></View>}
          </TouchableOpacity>
        </ScrollView>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52 },
  back: { fontSize: 24, color: ORANGE },
  title: { fontSize: 17, fontWeight: '700' },
  empty: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  emptyTxt: { fontSize: 15, marginBottom: 20 },
  shopBtn: { backgroundColor: ORANGE, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 14 },
  shopBtnTxt: { color: '#fff', fontWeight: '700' },
  addrBox: { borderWidth: 2, borderRadius: 14, padding: 14, marginBottom: 14 },
  addrTitle: { fontWeight: '700', fontSize: 14, marginBottom: 3 },
  addrSub: { fontSize: 12, marginBottom: 3 },
  addrChange: { color: ORANGE, fontSize: 12, fontWeight: '600' },
  addrPlaceholder: { color: ORANGE, fontWeight: '600', fontSize: 14, textAlign: 'center' },
  cartItem: { flexDirection: 'row', alignItems: 'center', borderRadius: 14, padding: 12, marginBottom: 10 },
  itemName: { fontWeight: '700', fontSize: 14, marginBottom: 3 },
  itemPrice: { color: ORANGE, fontWeight: '600' },
  qtyRow: { flexDirection: 'row', alignItems: 'center' },
  qtyBtn: { backgroundColor: '#f0f0f0', width: 30, height: 30, borderRadius: 8, alignItems: 'center', justifyContent: 'center' },
  qtyTxt: { fontSize: 18, fontWeight: '600', color: '#333' },
  qtyNum: { marginHorizontal: 10, fontSize: 15, fontWeight: '700' },
  footer: { padding: 16, borderTopWidth: 1, borderTopColor: '#f0f0f0' },
  total: { fontWeight: '700', fontSize: 15, marginBottom: 12 },
  checkoutBtn: { backgroundColor: ORANGE, padding: 16, borderRadius: 14, alignItems: 'center' },
  checkoutBtnTxt: { color: '#fff', fontWeight: '800', fontSize: 15 },
  label: { fontWeight: '700', fontSize: 13, marginBottom: 8, marginTop: 4 },
  input: { borderRadius: 12, padding: 13, marginBottom: 14, fontSize: 14 },
  payRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginBottom: 14 },
  payChip: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 14, paddingVertical: 9, borderRadius: 12, backgroundColor: '#f0f0f0' },
  payChipOn: { backgroundColor: ORANGE },
  payChipTxt: { fontWeight: '600', color: '#555', fontSize: 13 },
  summary: { borderRadius: 14, padding: 14, marginBottom: 16 },
  summaryTitle: { fontWeight: '700', fontSize: 14, marginBottom: 10 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4 },
  orderBtn: { backgroundColor: '#22c55e', padding: 16, borderRadius: 14, alignItems: 'center', marginBottom: 30 },
  orderBtnTxt: { color: '#fff', fontWeight: '800', fontSize: 15 },
});
