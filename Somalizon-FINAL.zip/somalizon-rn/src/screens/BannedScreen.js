import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../contexts/AuthContext';

export default function BannedScreen() {
  const { signOut } = useAuth();
  return (
    <View style={styles.wrap}>
      <Ionicons name="lock-closed-outline" size={64} color="#ef4444" />
      <Text style={styles.title}>Account-kaaga waa la xannibay</Text>
      <Text style={styles.sub}>
        Haddii aad aaminsan tahay in tani khalad tahay, nala soo xiriir taageerada Somalizon.
      </Text>
      <TouchableOpacity style={styles.btn} onPress={signOut}>
        <Ionicons name="log-out-outline" size={16} color="#fff" />
        <Text style={styles.btnTxt}>Ka Bixi</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1, backgroundColor: '#fff', alignItems: 'center', justifyContent: 'center', padding: 32 },
  title: { fontSize: 18, fontWeight: '800', color: '#222', marginTop: 18, textAlign: 'center' },
  sub: { fontSize: 13, color: '#666', marginTop: 10, textAlign: 'center', lineHeight: 20 },
  btn: { flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: '#ef4444', paddingHorizontal: 20, paddingVertical: 12, borderRadius: 14, marginTop: 28 },
  btnTxt: { color: '#fff', fontWeight: '700', fontSize: 14 },
});
