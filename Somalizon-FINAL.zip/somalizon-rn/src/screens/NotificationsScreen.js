import React, { useEffect } from 'react';
import { Ionicons } from '@expo/vector-icons';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet, ActivityIndicator,
} from 'react-native';
import { useAuth } from '../contexts/AuthContext';
import { useNotifs } from '../contexts/NotifContext';
import { useTheme } from '../contexts/ThemeContext';

const ORANGE = '#FF6B00';

function timeSince(iso) {
  if (!iso) return '';
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'Hadda';
  if (mins < 60) return mins + ' dq';
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return hrs + ' swr';
  return Math.floor(hrs / 24) + ' ml';
}

export default function NotificationsScreen({ navigation }) {
  const { profile } = useAuth();
  const { notifs, unread, loadNotifs, markRead, markAll } = useNotifs();
  const { theme } = useTheme();

  useEffect(() => {
    if (profile?.id) loadNotifs(profile.id);
  }, [profile]);

  function notifIcon(type) {
    const icons = { order: 'cube-outline', follow: 'people-outline', message: 'chatbubble-outline', review: 'star', call: 'call-outline', payment: 'card-outline' };
    return icons[type] || 'notifications-outline';
  }

  return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Ionicons name="notifications-outline" size={18} color={theme.text} />
          <Text style={[styles.title, { color: theme.text }]}>Ogeysiisyada</Text>
        </View>
        {unread > 0 && (
          <TouchableOpacity onPress={() => markAll(profile?.id)}>
            <Text style={styles.markAll}>Dhami akhri</Text>
          </TouchableOpacity>
        )}
      </View>
      <FlatList
        data={notifs}
        keyExtractor={n => String(n.id)}
        renderItem={({ item: n }) => (
          <TouchableOpacity
            style={[styles.notifCard, { backgroundColor: n.read ? theme.card : '#fff3e8', borderLeftColor: n.read ? 'transparent' : ORANGE }]}
            onPress={() => { markRead(n.id, profile?.id); if (n.link) navigation.navigate(n.link); }}
          >
            <Ionicons name={notifIcon(n.type)} size={24} color={ORANGE} style={styles.notifIcon} />
            <View style={{ flex: 1 }}>
              <Text style={[styles.notifTitle, { color: theme.text }]}>{n.title}</Text>
              {n.body ? <Text style={[styles.notifBody, { color: theme.text2 }]} numberOfLines={2}>{n.body}</Text> : null}
              <Text style={styles.notifTime}>{timeSince(n.created_at)}</Text>
            </View>
            {!n.read && <View style={styles.unreadDot} />}
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="notifications-outline" size={52} color={'#333'} />
            <Text style={[styles.emptyTxt, { color: theme.text2 }]}>Wax ogeysiis ah ma jiro weli</Text>
          </View>
        }
      />
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52, borderBottomWidth: 1 },
  title: { fontSize: 20, fontWeight: '800' },
  markAll: { color: ORANGE, fontSize: 13, fontWeight: '600' },
  notifCard: { flexDirection: 'row', alignItems: 'flex-start', padding: 14, borderBottomWidth: 1, borderBottomColor: '#f5f5f5', borderLeftWidth: 3 },
  notifIcon: { fontSize: 24, marginRight: 12, marginTop: 2 },
  notifTitle: { fontWeight: '700', fontSize: 14, marginBottom: 3 },
  notifBody: { fontSize: 12, lineHeight: 17, marginBottom: 4 },
  notifTime: { fontSize: 11, color: '#aaa' },
  unreadDot: { width: 8, height: 8, borderRadius: 4, backgroundColor: ORANGE, marginTop: 6, marginLeft: 8 },
  empty: { alignItems: 'center', marginTop: 80 },
  emptyIcon: { fontSize: 52, marginBottom: 14 },
  emptyTxt: { fontSize: 15 },
});
