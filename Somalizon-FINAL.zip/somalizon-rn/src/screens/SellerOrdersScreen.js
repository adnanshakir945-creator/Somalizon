import React, { useEffect, useState, useCallback } from 'react';
import { Ionicons } from '@expo/vector-icons';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  ActivityIndicator, RefreshControl, Alert,
} from 'react-native';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { useToast } from '../components/Toast';
import { toIconName } from '../constants/iconMap';
import OrderStatusTracker from '../components/OrderStatusTracker';
import { nextStatuses, statusMeta, CANCELLED_STATUS } from '../constants/orderStatus';
import { useCurrency } from '../contexts/CurrencyContext';

const ORANGE = '#FF6B00';

function timeFmt(iso) {
  if (!iso) return '';
  const d = new Date(iso);
  return d.toLocaleDateString('so-SO') + ' ' + d.toLocaleTimeString('so-SO', { hour: '2-digit', minute: '2-digit' });
}

export default function SellerOrdersScreen({ navigation }) {
  const { profile } = useAuth();
  const { theme } = useTheme();
  const { formatPrice } = useCurrency();
  const showToast = useToast();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [updatingId, setUpdatingId] = useState(null);

  useEffect(() => { loadOrders(); }, [profile]);

  // Live updates so a second device (or the buyer placing a new order)
  // shows up here without needing to pull-to-refresh.
  useEffect(() => {
    if (!profile?.email) return;
    const ch = supabase.channel('seller-orders-list-' + profile.email)
      .on('postgres_changes', {
        event: '*', schema: 'public', table: 'orders',
        filter: `sellerEmail=eq.${profile.email}`,
      }, () => loadOrders())
      .subscribe();
    return () => supabase.removeChannel(ch);
  }, [profile?.email]);

  async function loadOrders() {
    if (!profile?.email) { setLoading(false); return; }
    setLoading(true);
    const { data } = await supabase
      .from('orders')
      .select('*')
      .eq('sellerEmail', profile.email)
      .order('created_at', { ascending: false });
    setOrders(data || []);
    setLoading(false);
  }

  const onRefresh = useCallback(async () => {
    setRefreshing(true); await loadOrders(); setRefreshing(false);
  }, [profile]);

  async function advanceStatus(order, newStatus) {
    if (newStatus.key === CANCELLED_STATUS.key) {
      Alert.alert('Jooji Dalabka', 'Ma hubtaa inaad joojineyso dalabkan?', [
        { text: 'Maya', style: 'cancel' },
        { text: 'Haa, Jooji', style: 'destructive', onPress: () => doUpdate(order, newStatus.key) },
      ]);
      return;
    }
    doUpdate(order, newStatus.key);
  }

  async function doUpdate(order, statusKey) {
    setUpdatingId(order.id);
    const { error } = await supabase.from('orders').update({ status: statusKey }).eq('id', order.id);
    setUpdatingId(null);
    if (error) { showToast(error.message, 'error'); return; }
    setOrders(prev => prev.map(o => o.id === order.id ? { ...o, status: statusKey } : o));
    showToast(`Dalabka waxaa loo beddelay: ${statusMeta(statusKey).label}`, 'success');
  }

  function renderOrder({ item: o }) {
    const options = nextStatuses(o.status || 'La Diray');
    return (
      <View style={[styles.card, { backgroundColor: theme.card }]}>
        <View style={styles.cardHeader}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 5 }}>
            <Ionicons name="clipboard-outline" size={13} color={theme.text} />
            <Text style={[styles.orderNum, { color: theme.text }]}>#{String(o.id).slice(-4).toUpperCase()}</Text>
          </View>
          <Text style={[styles.orderDate, { color: theme.text2 }]}>{timeFmt(o.created_at)}</Text>
        </View>

        <View style={styles.prodRow}>
          <Ionicons name={toIconName(o.prodEmoji)} size={32} color={'#333'} style={{ width: 42, textAlign: 'center' }} />
          <View style={{ flex: 1 }}>
            <Text style={[styles.prodName, { color: theme.text }]} numberOfLines={1}>{o.prodName}</Text>
            <Text style={[styles.prodMeta, { color: theme.text2 }]}>Tirada: {o.qty} · {formatPrice(o.totalPrice || 0)}</Text>
            <View style={{ flexDirection: 'row', alignItems: 'center', gap: 4 }}>
              <Ionicons name="person-outline" size={11} color={theme.text2} />
              <Text style={[styles.prodMeta, { color: theme.text2 }]}>{o.buyerName} · {o.phone}</Text>
            </View>
          </View>
        </View>

        <OrderStatusTracker status={o.status || 'La Diray'} textColor={theme.text} mutedColor={theme.text2} />

        {options.length > 0 && (
          <View style={styles.actionRow}>
            {updatingId === o.id ? (
              <ActivityIndicator color={ORANGE} />
            ) : options.map(opt => (
              <TouchableOpacity
                key={opt.key}
                style={[styles.actionBtn, { backgroundColor: opt.key === CANCELLED_STATUS.key ? '#fff' : opt.color, borderWidth: opt.key === CANCELLED_STATUS.key ? 1.5 : 0, borderColor: CANCELLED_STATUS.color }]}
                onPress={() => advanceStatus(o, opt)}
              >
                <Ionicons name={opt.icon} size={14} color={opt.key === CANCELLED_STATUS.key ? CANCELLED_STATUS.color : '#fff'} />
                <Text style={[styles.actionTxt, { color: opt.key === CANCELLED_STATUS.key ? CANCELLED_STATUS.color : '#fff' }]}>
                  {opt.key === CANCELLED_STATUS.key ? 'Jooji' : `U dhig: ${opt.label}`}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </View>
    );
  }

  return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="chevron-back" size={20} color={'#333'} /></TouchableOpacity>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Ionicons name="cube-outline" size={18} color={theme.text} />
          <Text style={[styles.title, { color: theme.text }]}>Dalabyada ({orders.length})</Text>
        </View>
        <View style={{ width: 30 }} />
      </View>

      {loading ? <ActivityIndicator color={ORANGE} style={{ marginTop: 40 }} /> : (
        <FlatList
          data={orders} keyExtractor={o => String(o.id)}
          contentContainerStyle={{ padding: 14 }}
          renderItem={renderOrder}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={ORANGE} />}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="cube-outline" size={52} color={'#333'} />
              <Text style={[styles.emptyTxt, { color: theme.text2 }]}>Dalab lama helin weli</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52, borderBottomWidth: 1 },
  title: { fontSize: 17, fontWeight: '700' },
  card: { borderRadius: 16, padding: 14, marginBottom: 12, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 },
  cardHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 10 },
  orderNum: { fontWeight: '800', fontSize: 14 },
  orderDate: { fontSize: 11 },
  prodRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 10, marginBottom: 6 },
  prodName: { fontWeight: '700', fontSize: 14, marginBottom: 3 },
  prodMeta: { fontSize: 12, marginBottom: 2 },
  actionRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 10 },
  actionBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, paddingHorizontal: 12, paddingVertical: 9, borderRadius: 10 },
  actionTxt: { fontWeight: '700', fontSize: 12 },
  empty: { alignItems: 'center', marginTop: 80 },
  emptyTxt: { fontSize: 15 },
});
