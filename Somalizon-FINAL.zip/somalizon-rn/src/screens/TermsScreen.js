import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useTheme } from '../contexts/ThemeContext';

const ORANGE = '#FF6B00';
const LAST_UPDATED = '8 Luulyo 2026';

const TERMS = `
1. Aqbalidda Shuruudaha
Adigoo isticmaalaya Somalizon, waxaad ogolaanaysaa shuruudahan. Haddii aadan ogolayn, fadlan ha isticmaalin app-ka.

2. Isticmaalka App-ka
Somalizon waa suuq dijitaal ah oo isku xira macaamiisha iyo ganacsatada Soomaaliyeed. Waa inaad haysataa ugu yaraan 18 sano si aad account u samaysato.

3. Ganacsatada iyo Alaabta
Ganacsatadu waa iyaga oo keliya masuul ka ah sax-nimada faahfaahinta alaabtooda, qiimaha, iyo gaarsiinta wakhtiga ku habboon. Somalizon ma aha mid iibiya alaabta si toos ah — waa kaliya goob macaamiisha iyo ganacsatada isku xirta.

4. Lacag Bixinta
Lacag bixinta waxaa lagu sameeyaa habab sida EVC Plus, Zaad, eDahab, ama Kash marka la gaarsiiyo. Somalizon ma haysto xisaabaadka lacagta ee macaamiisha.

5. Diidmada ama Celinta Alaabta
Siyaasadda celinta waxay ku xiran tahay ganacsadaha gaarka ah. Fadlan kala hadal ganacsadaha ka hor inta aadan iibsan haddii aad su'aalo qabto.

6. Xilka Isticmaalaha
Waa inaad bixisaa macluumaad sax ah (magaca, telefoonka, cinwaanka) si loo gaarsiiyo dalabkaaga. Been-abuur ama khiyaano waxaa lagu xannibi karaa account-kaaga.

7. Beddelka Shuruudaha
Somalizon waxay xaq u leedahay inay beddesho shuruudahan wakhti kasta. Isticmaalka sii wadan ka dib beddelka waxay la macno tahay ogolaansho.

8. Xiriirka
Su'aalo la xiriira shuruudahan, nagala soo xiriir taageerada gudaha app-ka.
`.trim();

const PRIVACY = `
1. Macluumaadka Aan Ururino
Waxaan ururinaa magacaaga, email-ka, lambarka telefoonka, cinwaanka gaarsiinta, iyo taariikhda dalabyada si aan app-ka kuugu adeegno.

2. Sida Loo Isticmaalo Macluumaadka
Macluumaadkan waxaa loo isticmaalaa: dalabyada gaarsiinta, xiriirka macaamiisha/ganacsatada, ogeysiisyada, iyo hagaajinta app-ka.

3. Wadaagida Macluumaadka
Ma iibinno macluumaadkaaga shirkado dhinac saddexaad ah. Macluumaadka gaarsiinta (magaca, telefoonka, cinwaanka) waxaa la wadaagaa kaliya ganacsadaha aad ka dalbatay si loo gaarsiiyo alaabta.

4. Amniga Macluumaadka
Waxaan isticmaalnaa qaab-dhismeedka Supabase (encrypted database) si loo ilaaliyo macluumaadkaaga. Password-kaaga si toos ah looma kaydiyo — waxaa la kaydiyaa qaab hash ah.

5. Sawirada iyo Fiidiyowyada
Sawirada/fiidiyowyada aad soo gelisid (alaabta, profile-ka, Watch) waxay noqonayaan kuwo la arki karo dadka kale ee app-ka isticmaala.

6. Xuquuqdaada
Waad codsan kartaa in la tirtiro account-kaaga iyo macluumaadkaaga wakhti kasta adigoo la xiriiraya taageerada.

7. Cookies iyo Local Storage
App-ku wuxuu isticmaalaa local storage (taleefankaaga) si loo kaydiyo settings-kaaga iyo session-ka, ma jiraan cookies dhinac saddexaad ah.

8. Beddelka Siyaasaddan
Waxaan beddeli karnaa siyaasaddan xilliyaal kala duwan. Isticmaalka sii wadan waxay la macno tahay ogolaansho.
`.trim();

export default function TermsScreen({ navigation }) {
  const { theme } = useTheme();
  const [tab, setTab] = useState('terms');
  const content = tab === 'terms' ? TERMS : PRIVACY;

  return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Ionicons name="chevron-back" size={20} color={'#333'} /></TouchableOpacity>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <Ionicons name="document-text-outline" size={18} color={theme.text} />
          <Text style={[styles.title, { color: theme.text }]}>Shuruudaha & Sirta</Text>
        </View>
        <View style={{ width: 30 }} />
      </View>

      <View style={[styles.tabs, { borderBottomColor: theme.border }]}>
        <TouchableOpacity style={[styles.tab, tab === 'terms' && styles.tabOn]} onPress={() => setTab('terms')}>
          <Text style={[styles.tabTxt, { color: tab === 'terms' ? ORANGE : theme.text2 }]}>Shuruudaha Adeegga</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tab, tab === 'privacy' && styles.tabOn]} onPress={() => setTab('privacy')}>
          <Text style={[styles.tabTxt, { color: tab === 'privacy' ? ORANGE : theme.text2 }]}>Siyaasadda Sirta</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={{ padding: 20 }}>
        <Text style={[styles.updated, { color: theme.text2 }]}>La cusboonaysiiyay: {LAST_UPDATED}</Text>
        <Text style={[styles.body, { color: theme.text }]}>{content}</Text>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52, borderBottomWidth: 1 },
  title: { fontSize: 17, fontWeight: '700' },
  tabs: { flexDirection: 'row', borderBottomWidth: 1 },
  tab: { flex: 1, alignItems: 'center', paddingVertical: 12 },
  tabOn: { borderBottomWidth: 2, borderBottomColor: ORANGE },
  tabTxt: { fontWeight: '700', fontSize: 13 },
  updated: { fontSize: 12, marginBottom: 14, fontStyle: 'italic' },
  body: { fontSize: 14, lineHeight: 23 },
});
