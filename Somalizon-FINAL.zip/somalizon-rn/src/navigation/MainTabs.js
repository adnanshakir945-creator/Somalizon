import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useAuth } from '../contexts/AuthContext';
import { useCart } from '../contexts/CartContext';
import { useRealtime } from '../contexts/RealtimeContext';
import { COLORS, SHADOWS, R } from '../constants/Design';

import HomeScreen      from '../screens/HomeScreen';
import ShopsScreen     from '../screens/ShopsScreen';
import WatchScreen     from '../screens/WatchScreen';
import XariirScreen    from '../screens/XariirScreen';
import ProfileScreen   from '../screens/ProfileScreen';
import DashboardScreen from '../screens/DashboardScreen';

const Tab = createBottomTabNavigator();
const P = COLORS.primary;

const TAB_ICONS = {
  Home:      { icon: 'home-outline',           activeIcon: 'home',           label: 'Guriga' },
  Shops:     { icon: 'storefront-outline',      activeIcon: 'storefront',     label: 'Dukaannada' },
  Watch:     { icon: 'play-circle-outline',     activeIcon: 'play-circle',    label: 'Daawasho' },
  Xariir:    { icon: 'chatbubble-outline',      activeIcon: 'chatbubble',     label: 'Xariir' },
  Profile:   { icon: 'person-outline',          activeIcon: 'person',         label: 'Profile' },
  Dashboard: { icon: 'stats-chart-outline',     activeIcon: 'stats-chart',    label: 'Dashboard' },
};

function TabBar({ state, descriptors, navigation }) {
  return (
    <View style={styles.tabBarOuter}>
      <View style={styles.tabBar}>
        {state.routes.map((route, index) => {
          const { options } = descriptors[route.key];
          const isFocused = state.index === index;
          const icon = TAB_ICONS[route.name];
          const badge = options.tabBarBadge;

          return (
            <TouchableOpacity
              key={route.key}
              style={[styles.tabItem, isFocused && styles.tabItemActive]}
              onPress={() => { if (!isFocused) navigation.navigate(route.name); }}
              activeOpacity={0.8}
            >
              <View style={styles.tabIconWrap}>
                <Ionicons
                  name={isFocused ? (icon?.activeIcon || 'ellipse') : (icon?.icon || 'ellipse-outline')}
                  size={20}
                  color={isFocused ? '#fff' : 'rgba(255,255,255,0.55)'}
                />
                {badge > 0 && (
                  <View style={styles.badge}>
                    <Text style={styles.badgeTxt}>{badge > 99 ? '99+' : badge}</Text>
                  </View>
                )}
              </View>
              {isFocused && (
                <Text style={styles.tabLabelActive} numberOfLines={1}>{icon?.label || route.name}</Text>
              )}
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
}

export default function MainTabs() {
  const { profile } = useAuth();
  const { totalQty } = useCart();
  const { chatUnread } = useRealtime();
  const isSeller = profile?.user_type === 'seller';

  return (
    <Tab.Navigator
      tabBar={props => <TabBar {...props} />}
      screenOptions={{ headerShown: false }}
    >
      <Tab.Screen name="Home"   component={HomeScreen}   options={{ tabBarBadge: totalQty > 0 ? totalQty : 0 }} />
      <Tab.Screen name="Shops"  component={ShopsScreen}  options={{ tabBarBadge: 0 }} />
      <Tab.Screen name="Watch"  component={WatchScreen}  options={{ tabBarBadge: 0 }} />
      <Tab.Screen name="Xariir" component={XariirScreen} options={{ tabBarBadge: chatUnread > 0 ? chatUnread : 0 }} />
      {isSeller
        ? <Tab.Screen name="Dashboard" component={DashboardScreen} options={{ tabBarBadge: 0 }} />
        : <Tab.Screen name="Profile"   component={ProfileScreen}   options={{ tabBarBadge: 0 }} />
      }
    </Tab.Navigator>
  );
}

const styles = StyleSheet.create({
  // True floating overlay — sits above screen content with a gap from the bottom edge.
  tabBarOuter: {
    position: 'absolute',
    left: 14, right: 14, bottom: 22,
  },
  tabBar: {
    flexDirection: 'row',
    backgroundColor: 'rgba(20,20,20,0.85)',
    borderRadius: R.full,
    paddingVertical: 8,
    paddingHorizontal: 8,
    shadowColor: '#000', shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.25, shadowRadius: 16, elevation: 12,
  },
  tabItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    borderRadius: R.full,
    gap: 6,
  },
  tabItemActive: {
    backgroundColor: P,
    flex: 1.7,
  },
  tabIconWrap: { alignItems: 'center', justifyContent: 'center', position: 'relative' },
  tabLabelActive: { fontSize: 12, fontWeight: '800', color: '#fff' },
  badge: {
    position: 'absolute', top: -6, right: -8,
    backgroundColor: COLORS.error, borderRadius: R.full,
    minWidth: 16, height: 16, alignItems: 'center', justifyContent: 'center',
    paddingHorizontal: 3, borderWidth: 1.5, borderColor: '#141414',
  },
  badgeTxt: { color: '#fff', fontSize: 8, fontWeight: '900' },
});

// Bottom inset every scrollable screen needs so its last item can scroll
// fully clear of the floating bar instead of staying trapped underneath it.
export const TAB_BAR_CLEARANCE = 100;
