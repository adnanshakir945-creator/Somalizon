-- Somalizon: seller approval workflow
-- Run this in Supabase SQL Editor.

-- 1. Add the approval-status column to profiles
alter table profiles
  add column if not exists seller_status text default null;
  -- values: null (buyers), 'pending', 'approved', 'rejected'

-- 2. Grandfather in existing sellers so this change doesn't lock out
--    people who were already selling before this feature existed.
update profiles
  set seller_status = 'approved'
  where user_type = 'seller' and seller_status is null;

update stores
  set verified = true
  where verified is distinct from true
    and "sellerUid" in (
      select id from profiles where user_type = 'seller' and seller_status = 'approved'
    );

-- 3. (Recommended) Make yourself admin so you can see the "Ganacsato" tab
--    in AdminScreen. Replace with your own email.
-- update profiles set is_admin = true where email = 'YOUR-EMAIL@example.com';
