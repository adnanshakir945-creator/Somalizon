-- Somalizon: commission / platform-fee tracking
-- Run in Supabase SQL Editor.

alter table orders
  add column if not exists "commissionAmount" numeric default 0,
  add column if not exists "sellerPayout" numeric;

comment on column orders."commissionAmount" is '5% platform fee on the item total, split evenly between buyer and seller';
comment on column orders."sellerPayout" is 'What the seller actually receives: item total minus their half of the commission';
