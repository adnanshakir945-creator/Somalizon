# WaafiPay (ama Aggregator kale) — Checklist Xiriirka

## 1. Sida loo helo
- Website: waafi.com (raadi "WaafiPay Merchant" ama "WaafiPay Business")
- Ama raadi Facebook/LinkedIn-ka WaafiPay, ka codso "Business Account" / "Merchant API access"
- Kuwa kale ee la eegi karo: Premier Wallet, ama la xiriir Hormuud/Telesom/Somtel si toos ah haddii aggregator lagu waayo

## 2. Waxa aad u baahan tahay inaad la aado (documents)
- [ ] Business registration (haddii aad haysato) — haddii aadan haysan, weydii "individual/sole proprietor" ma la aqbali karaa
- [ ] ID-gaaga (National ID/Passport)
- [ ] Bank account ama lambar EVC/Zaad ah oo aad ku qaadan doonto lacagta

## 3. Su'aalaha aad weydiin lahayd WaafiPay
1. Ma taageertaan **split payment** ama **multi-party disbursement** (hal transaction, laba qaybood — seller iyo platform)?
2. Haddii aan taageerin split otomaatig ah — ma bixiyaan **API** aan isticmaali karo si aan naftayda u qaybiyo lacagta (collect → auto-disburse via API)?
3. Fees-kiinu waa immisa % transaction kasta?
4. Ma jira **sandbox/test environment** aan ku tijaabin karo App-ka ka hor inta aan live-ka la aadin?
5. Muddadee ayay qaadataa in la helo approval + API keys (integration timeline)?
6. Ma taageertaan EVC Plus, Zaad, iyo eDahab labadaba (saddexda oo dhan)?
7. Waa maxay xadka ugu yar/badan ee transaction-ka (min/max amount)?
8. Documentation (API docs) ma i siin kartaan si developer-kayga (Claude) uu u eego?

## 4. Marka aad hesho jawaabaha
Soo celi jawaabahan halkan (chat-ka), gaar ahaan:
- API documentation link/PDF (haddii la siiyo)
- Sample API request/response (haddii la siiyo)
- Fee structure-ka
- Ma jira split-payment feature dhab ah mise waa in la dhiso naftayda (collect-then-disburse)

Kadib waan kuu dhisi karnaa integration-ka gudaha `CartScreen.js` + Supabase Edge Function (webhook handler) si transaction-yadu si otomaatig ah ugu qaybsamaan.
