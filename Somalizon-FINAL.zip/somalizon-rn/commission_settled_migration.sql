-- Somalizon: track whether the seller has sent back their half of
-- the commission for a given order (Option 1 manual flow).
alter table orders
  add column if not exists "commissionSettled" boolean default false;

comment on column orders."commissionSettled" is 'True once the seller has manually remitted their 2.5% commission share for this order to the platform owner.';
