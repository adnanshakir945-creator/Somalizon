-- ============================================================
-- SOMALIZON — FULL SUPABASE SCHEMA
-- Run this once, top to bottom, in a fresh Supabase project's
-- SQL Editor. Safe to re-run (uses IF NOT EXISTS everywhere).
-- ============================================================

create extension if not exists "uuid-ossp";

-- ─────────────────────────────────────────────────────────
-- 1. PROFILES  (one row per auth.users row)
-- ─────────────────────────────────────────────────────────
create table if not exists profiles (
  id              uuid primary key references auth.users(id) on delete cascade,
  email           text unique not null,
  name            text,
  user_type       text default 'buyer' check (user_type in ('buyer','seller')),
  shop_name       text,
  seller_status   text check (seller_status in ('pending','approved','rejected')),
  profile_image   text,
  push_token      text,
  is_admin        boolean default false,
  banned          boolean default false,
  blocked_users   jsonb default '[]'::jsonb,
  wishlist        jsonb default '[]'::jsonb,
  saved_address   jsonb,
  created_at      timestamptz default now()
);

-- ─────────────────────────────────────────────────────────
-- 2. STORES  (one per seller)
-- ─────────────────────────────────────────────────────────
create table if not exists stores (
  id            uuid primary key default uuid_generate_v4(),
  name          text not null,
  "sellerName"  text,
  "sellerEmail" text not null,
  "sellerUid"   uuid references profiles(id) on delete cascade,
  emoji         text default 'storefront-outline',
  store_desc    text,
  rating        numeric default 5.0,
  followers     integer default 0,
  verified      boolean default false,
  created_at    timestamptz default now()
);

-- ─────────────────────────────────────────────────────────
-- 3. PRODUCTS
-- ─────────────────────────────────────────────────────────
create table if not exists products (
  id            uuid primary key default uuid_generate_v4(),
  name          text not null,
  price         numeric not null,
  "desc"        text,
  cat           text,
  emoji         text,
  img           text,
  seller        text,
  "sellerEmail" text not null,
  "storeId"     uuid references stores(id) on delete cascade,
  rating        numeric default 5.0,
  created_at    timestamptz default now()
);

-- ─────────────────────────────────────────────────────────
-- 4. ORDERS
-- ─────────────────────────────────────────────────────────
create table if not exists orders (
  id            uuid primary key default uuid_generate_v4(),
  "prodId"      uuid references products(id) on delete set null,
  "prodName"    text,
  "prodEmoji"   text,
  qty           integer default 1,
  "totalPrice"  numeric,
  "deliveryFee" numeric default 0,
  "buyerName"   text,
  "buyerEmail"  text not null,
  "sellerEmail" text not null,
  "sellerName"  text,
  phone         text,
  address       text,
  "payMethod"   text,
  "payNumber"   text,
  status        text default 'La Diray',
  created_at    timestamptz default now()
);

-- ─────────────────────────────────────────────────────────
-- 5. REVIEWS
-- ─────────────────────────────────────────────────────────
create table if not exists reviews (
  id            uuid primary key default uuid_generate_v4(),
  "prodId"      uuid references products(id) on delete cascade,
  "storeId"     uuid references stores(id) on delete cascade,
  prod          text,
  "buyerName"   text,
  "buyerEmail"  text not null,
  stars         integer check (stars between 1 and 5),
  text          text,
  created_at    timestamptz default now()
);

-- ─────────────────────────────────────────────────────────
-- 6. CHATS  (id is a deterministic "email1__email2" string, not a uuid)
-- ─────────────────────────────────────────────────────────
create table if not exists chats (
  id                  text primary key,
  "participantEmails" jsonb not null,
  participants        jsonb,
  "lastMessage"        text,
  "lastSenderEmail"    text,
  "lastTime"           timestamptz default now()
);

-- ─────────────────────────────────────────────────────────
-- 7. MESSAGES
-- ─────────────────────────────────────────────────────────
create table if not exists messages (
  id            uuid primary key default uuid_generate_v4(),
  chat_id       text references chats(id) on delete cascade,
  "senderEmail" text not null,
  "senderName"  text,
  type          text default 'text',   -- 'text' | 'image' | 'voice'
  t             text,                  -- message body / caption
  img           text,                  -- image or voice-note URL, when type != 'text'
  time          text,
  created_at    timestamptz default now()
);

-- ─────────────────────────────────────────────────────────
-- 8. FOLLOWS  (buyer follows a seller's store)
-- ─────────────────────────────────────────────────────────
create table if not exists follows (
  id            uuid primary key default uuid_generate_v4(),
  user_email    text not null,
  seller_email  text not null,
  created_at    timestamptz default now(),
  unique (user_email, seller_email)
);

-- ─────────────────────────────────────────────────────────
-- 9. VIDEOS  (Watch feed)
-- ─────────────────────────────────────────────────────────
create table if not exists videos (
  id            uuid primary key default uuid_generate_v4(),
  url           text not null,
  "user"        text,
  "userEmail"   text not null,
  "desc"        text,
  "prodName"    text,
  likes         integer default 0,
  comments      integer default 0,
  created_at    timestamptz default now()
);

-- ─────────────────────────────────────────────────────────
-- 10. VIDEO_INTERACTIONS  (likes)
-- ─────────────────────────────────────────────────────────
create table if not exists video_interactions (
  id          uuid primary key default uuid_generate_v4(),
  video_id    uuid references videos(id) on delete cascade,
  user_email  text not null,
  type        text default 'like',
  created_at  timestamptz default now(),
  unique (video_id, user_email, type)
);

-- ─────────────────────────────────────────────────────────
-- 11. COMMENTS  (on videos)
-- ─────────────────────────────────────────────────────────
create table if not exists comments (
  id          uuid primary key default uuid_generate_v4(),
  "videoId"   uuid references videos(id) on delete cascade,
  "userName"  text,
  "userEmail" text not null,
  text        text not null,
  created_at  timestamptz default now()
);

-- ─────────────────────────────────────────────────────────
-- 12. NOTIFICATIONS
-- ─────────────────────────────────────────────────────────
create table if not exists notifications (
  id          uuid primary key default uuid_generate_v4(),
  "toUid"     uuid references profiles(id) on delete cascade,
  title       text,
  body        text,
  data        jsonb,
  read        boolean default false,
  created_at  timestamptz default now()
);

-- ─────────────────────────────────────────────────────────
-- 13. CALLS  (WebRTC signaling)
-- ─────────────────────────────────────────────────────────
create table if not exists calls (
  id            text primary key,
  "callerEmail" text not null,
  "calleeEmail" text not null,
  offer         jsonb,
  answer        jsonb,
  status        text default 'ringing',
  created_at    timestamptz default now()
);

-- ─────────────────────────────────────────────────────────
-- 14. CALL_CANDIDATES  (WebRTC ICE candidates)
-- ─────────────────────────────────────────────────────────
create table if not exists call_candidates (
  id          uuid primary key default uuid_generate_v4(),
  call_id     text references calls(id) on delete cascade,
  role        text check (role in ('caller','callee')),
  candidate   jsonb,
  created_at  timestamptz default now()
);

-- ─────────────────────────────────────────────────────────
-- 15. REPORTS  (both product reports and user reports live here)
-- ─────────────────────────────────────────────────────────
create table if not exists reports (
  id                  uuid primary key default uuid_generate_v4(),
  "prodId"            uuid references products(id) on delete cascade,
  "prodName"          text,
  "sellerEmail"       text,
  "sellerName"        text,
  "reportedUserEmail" text,
  "reportedUserName"  text,
  "reporterEmail"     text not null,
  "reporterName"      text,
  reason              text,
  status              text default 'pending',
  created_at          timestamptz default now()
);

-- ============================================================
-- INDEXES  (the columns everything filters/sorts by)
-- ============================================================
create index if not exists idx_products_seller   on products("sellerEmail");
create index if not exists idx_products_store     on products("storeId");
create index if not exists idx_orders_buyer       on orders("buyerEmail");
create index if not exists idx_orders_seller      on orders("sellerEmail");
create index if not exists idx_reviews_product     on reviews("prodId");
create index if not exists idx_messages_chat       on messages(chat_id);
create index if not exists idx_follows_seller      on follows(seller_email);
create index if not exists idx_videos_user         on videos("userEmail");
create index if not exists idx_video_interactions  on video_interactions(video_id, user_email);
create index if not exists idx_comments_video       on comments("videoId");
create index if not exists idx_notifications_touid  on notifications("toUid");
create index if not exists idx_call_candidates_call on call_candidates(call_id);

-- ============================================================
-- ROW LEVEL SECURITY
-- ============================================================
alter table profiles           enable row level security;
alter table stores             enable row level security;
alter table products           enable row level security;
alter table orders             enable row level security;
alter table reviews            enable row level security;
alter table chats              enable row level security;
alter table messages           enable row level security;
alter table follows            enable row level security;
alter table videos             enable row level security;
alter table video_interactions enable row level security;
alter table comments           enable row level security;
alter table notifications      enable row level security;
alter table calls              enable row level security;
alter table call_candidates    enable row level security;
alter table reports            enable row level security;

-- Helper: is the current user an admin?
create or replace function is_admin() returns boolean as $$
  select coalesce((select is_admin from profiles where id = auth.uid()), false);
$$ language sql stable security definer;

-- profiles: everyone can read (names/avatars need to show in UI),
-- only the owner (or an admin) can write.
create policy "profiles_read_all"   on profiles for select using (true);
create policy "profiles_write_own"  on profiles for update using (auth.uid() = id or is_admin());
create policy "profiles_insert_own" on profiles for insert with check (auth.uid() = id);

-- stores: public read; only the owning seller (or admin) can write.
create policy "stores_read_all"  on stores for select using (true);
create policy "stores_write_own" on stores for insert with check (auth.uid() = "sellerUid");
create policy "stores_update_own" on stores for update using (auth.uid() = "sellerUid" or is_admin());

-- products: public read; only the owning seller can write.
create policy "products_read_all"   on products for select using (true);
create policy "products_write_own"  on products for insert with check (auth.uid()::text = (select id::text from profiles where email = "sellerEmail"));
create policy "products_update_own" on products for update using (auth.uid()::text = (select id::text from profiles where email = "sellerEmail") or is_admin());
create policy "products_delete_own" on products for delete using (auth.uid()::text = (select id::text from profiles where email = "sellerEmail") or is_admin());

-- orders: only the buyer or the seller involved (or admin) can see/touch a row.
create policy "orders_read_own" on orders for select using (
  auth.jwt() ->> 'email' = "buyerEmail" or auth.jwt() ->> 'email' = "sellerEmail" or is_admin()
);
create policy "orders_insert_own" on orders for insert with check (auth.jwt() ->> 'email' = "buyerEmail");
create policy "orders_update_own" on orders for update using (
  auth.jwt() ->> 'email' = "buyerEmail" or auth.jwt() ->> 'email' = "sellerEmail" or is_admin()
);

-- reviews: public read; only the reviewing buyer can write.
create policy "reviews_read_all"  on reviews for select using (true);
create policy "reviews_write_own" on reviews for insert with check (auth.jwt() ->> 'email' = "buyerEmail");

-- chats/messages: only the two participants can read/write.
create policy "chats_read_own" on chats for select using (
  "participantEmails" ? (auth.jwt() ->> 'email')
);
create policy "chats_write_own" on chats for insert with check (
  "participantEmails" ? (auth.jwt() ->> 'email')
);
create policy "chats_update_own" on chats for update using (
  "participantEmails" ? (auth.jwt() ->> 'email')
);
create policy "messages_read_own" on messages for select using (
  exists (select 1 from chats c where c.id = chat_id and c."participantEmails" ? (auth.jwt() ->> 'email'))
);
create policy "messages_write_own" on messages for insert with check (auth.jwt() ->> 'email' = "senderEmail");

-- follows: public read (follower counts); users manage their own follow rows.
create policy "follows_read_all"  on follows for select using (true);
create policy "follows_write_own" on follows for insert with check (auth.jwt() ->> 'email' = user_email);
create policy "follows_delete_own" on follows for delete using (auth.jwt() ->> 'email' = user_email);

-- videos: public read; only the uploader can write/delete.
create policy "videos_read_all"   on videos for select using (true);
create policy "videos_write_own"  on videos for insert with check (auth.jwt() ->> 'email' = "userEmail");
create policy "videos_update_all" on videos for update using (true); -- needed so anyone's like/comment can bump counters
create policy "videos_delete_own" on videos for delete using (auth.jwt() ->> 'email' = "userEmail" or is_admin());

-- video_interactions: public read (like counts); users manage their own.
create policy "video_int_read_all"  on video_interactions for select using (true);
create policy "video_int_write_own" on video_interactions for insert with check (auth.jwt() ->> 'email' = user_email);
create policy "video_int_delete_own" on video_interactions for delete using (auth.jwt() ->> 'email' = user_email);

-- comments: public read; only the author can write.
create policy "comments_read_all"  on comments for select using (true);
create policy "comments_write_own" on comments for insert with check (auth.jwt() ->> 'email' = "userEmail");

-- notifications: only the recipient can read/update their own.
create policy "notif_read_own"   on notifications for select using (auth.uid() = "toUid");
create policy "notif_update_own" on notifications for update using (auth.uid() = "toUid");

-- calls / call_candidates: only the two people on the call can touch it.
create policy "calls_read_own" on calls for select using (
  auth.jwt() ->> 'email' in ("callerEmail", "calleeEmail")
);
create policy "calls_write_own" on calls for insert with check (auth.jwt() ->> 'email' = "callerEmail");
create policy "calls_update_own" on calls for update using (
  auth.jwt() ->> 'email' in ("callerEmail", "calleeEmail")
);
create policy "call_candidates_read_own" on call_candidates for select using (
  exists (select 1 from calls c where c.id = call_id and auth.jwt() ->> 'email' in (c."callerEmail", c."calleeEmail"))
);
create policy "call_candidates_write_own" on call_candidates for insert with check (
  exists (select 1 from calls c where c.id = call_id and auth.jwt() ->> 'email' in (c."callerEmail", c."calleeEmail"))
);

-- reports: anyone signed in can file one; only admins can read the list.
create policy "reports_insert_any" on reports for insert with check (auth.jwt() ->> 'email' = "reporterEmail");
create policy "reports_read_admin" on reports for select using (is_admin());
create policy "reports_update_admin" on reports for update using (is_admin());

-- ============================================================
-- Done. Next: run seller_approval_migration.sql, then create the
-- storage buckets listed in README.md (product-images, chat-images,
-- voice-messages, videos, profile-images) with public read access.
-- ============================================================
