-- ============================================================
-- SOMALIZON — STORAGE BUCKETS
-- Run this AFTER somalizon_full_schema.sql.
-- Creates the 5 buckets the app uploads to, all public-read
-- (so images/videos display without a signed URL) but
-- upload-restricted to signed-in users.
-- ============================================================

insert into storage.buckets (id, name, public)
values
  ('product-images',  'product-images',  true),
  ('chat-images',      'chat-images',      true),
  ('voice-messages',   'voice-messages',   true),
  ('videos',           'videos',           true),
  ('profile-images',   'profile-images',   true)
on conflict (id) do nothing;

-- Public read for all 5 buckets
create policy "public_read_product_images" on storage.objects for select using (bucket_id = 'product-images');
create policy "public_read_chat_images"    on storage.objects for select using (bucket_id = 'chat-images');
create policy "public_read_voice_messages" on storage.objects for select using (bucket_id = 'voice-messages');
create policy "public_read_videos"         on storage.objects for select using (bucket_id = 'videos');
create policy "public_read_profile_images" on storage.objects for select using (bucket_id = 'profile-images');

-- Only signed-in users can upload, and only into their own folder
-- (the app should upload to `${bucket}/${user.id}/filename.ext`)
create policy "auth_upload_product_images" on storage.objects for insert
  with check (bucket_id = 'product-images' and auth.role() = 'authenticated');
create policy "auth_upload_chat_images" on storage.objects for insert
  with check (bucket_id = 'chat-images' and auth.role() = 'authenticated');
create policy "auth_upload_voice_messages" on storage.objects for insert
  with check (bucket_id = 'voice-messages' and auth.role() = 'authenticated');
create policy "auth_upload_videos" on storage.objects for insert
  with check (bucket_id = 'videos' and auth.role() = 'authenticated');
create policy "auth_upload_profile_images" on storage.objects for insert
  with check (bucket_id = 'profile-images' and auth.role() = 'authenticated');

-- Owners can delete/replace their own uploads
create policy "owner_delete_own_files" on storage.objects for delete
  using (auth.uid()::text = (storage.foldername(name))[1]);
