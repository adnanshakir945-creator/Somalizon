# Somalizon — Privacy Policy

**Taariikhda cusboonaysiinta ugu dambeysay:** [buuxi taariikhda markaad daabacdo]

Somalizon ("annaga", "app-ka") waa mid isku daray suuq (marketplace) iyo bogag muuqaal bulsheed (social video) oo loogu talagalay bulshada Soomaaliyeed. Sharciyadan asturnaanta waxay sharraxayaan sida aan u ururino, u isticmaalno, oo u ilaalino xogtaada marka aad isticmaasho app-ka Somalizon.

## 1. Xogta aan ururino

- **Xogta account-ka:** magaca, email-ka, sawirka profile-ka, nooca isticmaale (macmiil/ganacsade)
- **Xogta ganacsiga (ganacsatada):** magaca dukaanka, faahfaahinta alaabta, sawirada, lambarrada telefoonka/WhatsApp
- **Xogta dalabka:** taariikhda dalabyada, cinwaanka gaarsiinta, habka lacag-bixinta (EVC Plus/Zaad/eDahab/Kash — annagu ma kaydinno lambarrada koontada, kaliya nooca habka)
- **Content la soo dhigay:** muuqaallo (videos), sawirro, faallooyin, fariimo (chat)
- **Xogta farsamada:** nooca device-ka, push notification token, xogta isticmaalka app-ka (analytics)

## 2. Sida aan xogta u isticmaalno

- Si aan u shaqaynayno oo aan u dhamaystirno app-ka (dalabyada, chat-ka, muuqaallada)
- Si aan u xaqiijino ganacsatada (approval process)
- Si aan u dirno ogaysiisyo (push notifications) — dalabyo, fariimo, iwm
- Si aan u ilaalino badbaadada isticmaalayaasha (reports, xannibaad)

## 3. La wadaagista xogta

Xogtaada **lama iibiyo** cid saddexaad. Waxaa la wadaagi kara kaliya:
- Ganacsadaha aad dalabka ka dalbatay (magaca, cinwaanka gaarsiinta)
- Bixiyeyaasha adeegga farsamada (tusaale: Supabase — server-ka backend-ka)
- Marka sharci ku qaso (baaris rasmi ah)

## 4. Ilaalinta xogta

Waxaan isticmaalnaa qaab-dhismeedka amniga ee Supabase (Row Level Security) si loo hubiyo in isticmaale kastaa uu arki karo kaliya xogtiisa gaarka ah.

## 5. Xuquuqdaada

Waad codsan kartaa:
- Inaad aragto xogtaada
- Inaad wax ka beddesho xogtaada (Profile settings)
- Inaad account-kaaga tirtirto — nagala soo xiriir: [email-ka taageerada]

## 6. Carruurta

Somalizon ma loogu talagalin carruurta ka yar 13 sano. Ma ururino si ula kac ah xog ka timaada carruur.

## 7. Isbeddellada sharcigan

Waxaan mar mar cusboonaysiin karnaa sharcigan asturnaanta. Isbeddel kasta oo weyn waxaan idinku ogaysiin doonaa app-ka gudihiisa.

## 8. Nala Soo Xiriir

Haddii aad su'aalo qabto sharcigan asturnaanta, nala soo xiriir:
**Email:** [geli email-ka taageerada]
**WhatsApp:** [geli lambarka]

---
*Fiiro: Qoraalkan waa qabyo-qoraal (draft) aan sameeyay si aan kuu caawiyo — kama ihi qareen, marka waxaa la talinayaa inaad qareen ku hubiso ka hor inta aadan daabicin App Store/Play Store, gaar ahaan xeerarka lacag-bixinta EVC/Zaad/eDahab.*
