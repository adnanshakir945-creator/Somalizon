import React, { useEffect, useState, useCallback } from 'react';
import { Video } from 'expo-av';
import {
  View, Text, FlatList, TouchableOpacity, StyleSheet,
  ActivityIndicator, RefreshControl, Alert,
} from 'react-native';

import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';

const ORANGE = '#FF6B00';

export default function VideoManagerScreen({ navigation }) {
  const { profile } = useAuth();
  const { theme } = useTheme();
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [playingId, setPlayingId] = useState(null);

  useEffect(() => { loadVideos(); }, [profile]);

  async function loadVideos() {
    if (!profile?.email) { setLoading(false); return; }
    setLoading(true);
    const { data } = await supabase.from('videos').select('*').eq('userEmail', profile.email).order('created_at', { ascending: false });
    setVideos(data || []);
    setLoading(false);
  }

  async function deleteVideo(video) {
    console.log('Tirtir Video', `"${video.desc?.slice(0, 30)}..." ma tirtirtaa?`, [
      { text: 'Maya', style: 'cancel' },
      {
        text: 'Haa, Tirtir', style: 'destructive', onPress: async () => {
          const { error } = await supabase.from('videos').delete().eq('id', video.id);
          if (!error) {
            setVideos(prev => prev.filter(v => v.id !== video.id));
            // Delete from storage too
            const path = video.url.split('/videos/')[1];
            if (path) await supabase.storage.from('videos').remove([`videos/${path}`]);
          } else {
            console.log('⚠️ Khalad', error.message);
          }
        }
      }
    ]);
  }

  const onRefresh = useCallback(async () => { setRefreshing(true); await loadVideos(); setRefreshing(false); }, [profile]);

  function renderVideo({ item: v }) {
    const isPlaying = playingId === v.id;
    return (
      <View style={[styles.card, { backgroundColor: theme.card }]}>
        <TouchableOpacity onPress={() => setPlayingId(isPlaying ? null : v.id)}>
          <Video
            source={{ uri: v.url }}
            style={styles.videoThumb}
            resizeMode="cover"
            shouldPlay={isPlaying}
            isLooping={false}
            isMuted={!isPlaying}
          />
          {!isPlaying && (
            <View style={styles.playOverlay}>
              <Text style={{ fontSize: 36 }}>▶️</Text>
            </View>
          )}
        </TouchableOpacity>
        <View style={styles.cardBody}>
          <Text style={[styles.desc, { color: theme.text }]} numberOfLines={2}>{v.desc}</Text>
          {v.prodName && <Text style={[styles.prodTag, { color: ORANGE }]}>🛍️ {v.prodName}</Text>}
          <View style={styles.stats}>
            <Text style={[styles.stat, { color: theme.text2 }]}>❤️ {v.likes || 0}</Text>
            <Text style={[styles.stat, { color: theme.text2 }]}>💬 {v.comments || 0}</Text>
          </View>
          <View style={styles.actions}>
            <TouchableOpacity
              style={styles.editBtn}
              onPress={() => navigation.navigate('Comments', { videoId: v.id, videoDesc: v.desc })}
            >
              <Text style={styles.editBtnTxt}>💬 Faallooyinka</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.deleteBtn} onPress={() => deleteVideo(v)}>
              <Text style={styles.deleteBtnTxt}>🗑️ Tirtir</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  }

  return (
    <View style={[styles.wrap, { backgroundColor: theme.bg }]}>
      <View style={[styles.header, { backgroundColor: theme.header, borderBottomColor: theme.border }]}>
        <TouchableOpacity onPress={() => navigation.goBack()}><Text style={styles.back}>←</Text></TouchableOpacity>
        <Text style={[styles.title, { color: theme.text }]}>📹 Videohayga ({videos.length})</Text>
        <TouchableOpacity onPress={() => navigation.navigate('UploadVideo')}>
          <Text style={{ color: ORANGE, fontWeight: '700', fontSize: 24 }}>+</Text>
        </TouchableOpacity>
      </View>

      {loading ? <ActivityIndicator color={ORANGE} style={{ marginTop: 40 }} /> : (
        <FlatList
          data={videos}
          keyExtractor={v => String(v.id)}
          contentContainerStyle={{ padding: 14 }}
          renderItem={renderVideo}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={ORANGE} />}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Text style={{ fontSize: 50, marginBottom: 14 }}>🎬</Text>
              <Text style={[styles.emptyTxt, { color: theme.text2 }]}>Video ma gelisid weli</Text>
              <TouchableOpacity style={styles.uploadBtn} onPress={() => navigation.navigate('UploadVideo')}>
                <Text style={styles.uploadBtnTxt}>📹 Video Soo Dhig</Text>
              </TouchableOpacity>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 16, paddingTop: 52, borderBottomWidth: 1 },
  back: { fontSize: 24, color: ORANGE },
  title: { fontSize: 17, fontWeight: '700' },
  card: { borderRadius: 16, overflow: 'hidden', marginBottom: 14, shadowColor: '#000', shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 },
  videoThumb: { width: '100%', height: 200 },
  playOverlay: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(0,0,0,0.3)' },
  cardBody: { padding: 14 },
  desc: { fontSize: 14, fontWeight: '600', marginBottom: 4 },
  prodTag: { fontSize: 12, fontWeight: '700', marginBottom: 8 },
  stats: { flexDirection: 'row', gap: 16, marginBottom: 12 },
  stat: { fontSize: 13 },
  actions: { flexDirection: 'row', gap: 10 },
  editBtn: { flex: 1, backgroundColor: '#f0f0f0', padding: 10, borderRadius: 10, alignItems: 'center' },
  editBtnTxt: { fontWeight: '600', fontSize: 13, color: '#333' },
  deleteBtn: { flex: 1, backgroundColor: '#fee2e2', padding: 10, borderRadius: 10, alignItems: 'center' },
  deleteBtnTxt: { fontWeight: '600', fontSize: 13, color: '#ef4444' },
  empty: { alignItems: 'center', marginTop: 60 },
  emptyTxt: { fontSize: 15, marginBottom: 20 },
  uploadBtn: { backgroundColor: ORANGE, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 14 },
  uploadBtnTxt: { color: '#fff', fontWeight: '700' },
});
