import React, { useEffect } from 'react';
import { StatusBar } from 'expo-status-bar';
import { Audio } from 'expo-av';
import { AuthProvider } from './src/contexts/AuthContext';
import { CartProvider } from './src/contexts/CartContext';
import { ThemeProvider, useTheme } from './src/contexts/ThemeContext';
import { NotifProvider } from './src/contexts/NotifContext';
import { RealtimeProvider } from './src/contexts/RealtimeContext';
import { ToastProvider } from './src/components/Toast';
import RootNavigator from './src/navigation/RootNavigator';

function AppInner() {
  const { isDark } = useTheme();
  useEffect(() => {
    Audio.setAudioModeAsync({ playsInSilentModeIOS: true }).catch(() => {});
  }, []);
  return (
    <ToastProvider>
      <StatusBar style={isDark ? 'light' : 'dark'} />
      <RootNavigator />
    </ToastProvider>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <CartProvider>
          <NotifProvider>
            <RealtimeProvider>
              <AppInner />
            </RealtimeProvider>
          </NotifProvider>
        </CartProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
